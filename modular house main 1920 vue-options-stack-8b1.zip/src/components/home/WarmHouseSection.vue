<script setup lang="ts">
import GradientHeading from '@/components/ui/GradientHeading.vue'

const layers = [
  { title: 'Зовнішнє оздоблення', text: 'Композитні панелі' },
  { title: 'Гідробар’єр', text: '' },
  { title: 'Панель OSB-3 Egger 10 мм', text: '' },
  { title: 'Базальтовий утеплювач Rotys 200 мм', text: '' },
  { title: 'Панель OSB-3 Egger 10 мм', text: '' },
  { title: 'Внутрішня обшивка', text: '' },
]

const perks = [
  { title: 'Зберігає тепло взимку', color: 'text-brand', ring: 'stroke-brand' },
  { title: 'Екологічно та безпечно', color: 'text-emerald-700', ring: 'stroke-emerald-700' },
  { title: 'Швидке будівництво', color: 'text-amber-800', ring: 'stroke-amber-800' },
]
</script>

<template>
  <section class="mx-auto max-w-page px-4 py-16 sm:px-8 lg:px-12 lg:py-24">
    <div class="mx-auto max-w-3xl text-center">
      <GradientHeading as="h2" class="text-4xl sm:text-6xl lg:text-7xl">Супертеплий будинок</GradientHeading>
      <p class="mx-auto mt-6 max-w-xl text-lg tracking-tight text-ink/80 sm:text-2xl">
        Використовуємо виключно сертифіковані матеріали провідних європейських виробників
      </p>
    </div>

    <div class="relative mt-14 overflow-hidden rounded-[50px] bg-ink sm:rounded-[80px]">
      <img
        src="https://api.builder.io/api/v1/image/assets/TEMP/5747358882770cc0ef2327a514edaaa2f4c5b0ef?width=3242"
        alt="Дім в розрізі"
        class="h-full w-full object-cover opacity-90"
      />
      <div
        class="absolute inset-y-0 right-0 w-full bg-ink/60 backdrop-blur-md sm:w-1/2 lg:w-2/5"
      ></div>
      <div class="absolute inset-y-0 right-0 flex w-full flex-col justify-center gap-6 p-6 text-white sm:w-1/2 sm:p-10 lg:w-2/5">
        <div v-for="layer in layers" :key="layer.title">
          <p class="text-lg font-semibold tracking-tight sm:text-2xl">{{ layer.title }}</p>
          <p v-if="layer.text" class="text-lg tracking-tight sm:text-2xl">{{ layer.text }}</p>
        </div>
      </div>
    </div>

    <div class="mt-16 flex flex-col items-center gap-10">
      <div class="grid w-full max-w-4xl grid-cols-1 gap-6 sm:grid-cols-2">
        <div class="flex flex-col items-center gap-4 rounded-[40px] bg-white px-8 py-10 shadow-[9px_4px_4px_0_rgba(0,0,0,0.25)]">
          <svg width="56" height="56" viewBox="0 0 68 68" fill="none">
            <path
              d="M25.4997 34.0001L31.1663 39.6668L42.4997 28.3335M56.6663 36.8335C56.6663 51.0001 46.7497 58.0835 34.963 62.1918C34.3458 62.401 33.6754 62.3909 33.0647 62.1635C21.2497 58.0835 11.333 51.0001 11.333 36.8335V17.0001C11.333 16.2487 11.6315 15.528 12.1629 14.9967C12.6942 14.4653 13.4149 14.1668 14.1663 14.1668C19.833 14.1668 26.9163 10.7668 31.8463 6.46013C32.4466 5.9473 33.2102 5.66553 33.9997 5.66553C34.7892 5.66553 35.5528 5.9473 36.153 6.46013C41.1113 10.7951 48.1663 14.1668 53.833 14.1668C54.5845 14.1668 55.3051 14.4653 55.8365 14.9967C56.3678 15.528 56.6663 16.2487 56.6663 17.0001V36.8335Z"
              stroke="#273947"
              stroke-width="6"
              stroke-linecap="round"
              stroke-linejoin="round"
            />
          </svg>
          <p class="bg-brand-gradient bg-clip-text text-4xl font-semibold tracking-tight text-transparent sm:text-5xl">
            220 мм
          </p>
          <p class="text-xl tracking-tight text-ink">Товщина панелі</p>
        </div>
        <div class="flex flex-col items-center gap-4 rounded-[40px] bg-white px-8 py-10 shadow-[9px_4px_4px_0_rgba(0,0,0,0.25)]">
          <svg width="56" height="56" viewBox="0 0 68 68" fill="none">
            <path
              d="M25.4997 34.0001L31.1663 39.6668L42.4997 28.3335M56.6663 36.8335C56.6663 51.0001 46.7497 58.0835 34.963 62.1918C34.3458 62.401 33.6754 62.3909 33.0647 62.1635C21.2497 58.0835 11.333 51.0001 11.333 36.8335V17.0001C11.333 16.2487 11.6315 15.528 12.1629 14.9967C12.6942 14.4653 13.4149 14.1668 14.1663 14.1668C19.833 14.1668 26.9163 10.7668 31.8463 6.46013C32.4466 5.9473 33.2102 5.66553 33.9997 5.66553C34.7892 5.66553 35.5528 5.9473 36.153 6.46013C41.1113 10.7951 48.1663 14.1668 53.833 14.1668C54.5845 14.1668 55.3051 14.4653 55.8365 14.9967C56.3678 15.528 56.6663 16.2487 56.6663 17.0001V36.8335Z"
              stroke="#67351A"
              stroke-width="6"
              stroke-linecap="round"
              stroke-linejoin="round"
            />
          </svg>
          <p class="bg-gradient-to-b from-[#67351A] to-[#DD8248] bg-clip-text text-4xl font-semibold tracking-tight text-transparent sm:text-5xl">
            1540 мм
          </p>
          <p class="text-xl tracking-tight text-ink">Товщина цегляної стіни</p>
        </div>
      </div>

      <p class="max-w-xl text-center text-lg tracking-tight text-ink/80 sm:text-2xl">
        По тепловтраті дорівнює 1,5 м цегляної стіни
      </p>

      <div class="grid w-full max-w-4xl grid-cols-1 gap-8 sm:grid-cols-3">
        <div v-for="perk in perks" :key="perk.title" class="flex items-center gap-4">
          <svg width="56" height="56" viewBox="0 0 106 106" fill="none" class="shrink-0">
            <circle cx="53" cy="53" r="52" :class="perk.ring" stroke-width="2" />
          </svg>
          <p class="text-xl tracking-tight text-ink sm:text-2xl">{{ perk.title }}</p>
        </div>
      </div>
    </div>
  </section>
</template>
