<script setup lang="ts">
import PillButton from '@/components/ui/PillButton.vue'
</script>

<template>
  <section id="home" class="relative overflow-hidden bg-ink">
    <img
      src="https://api.builder.io/api/v1/image/assets/TEMP/ab37457e3ec974169b58fb057d13711231d2c42c?width=4088"
      alt="Будинок-конструктор"
      class="absolute inset-0 h-full w-full object-cover"
    />
    <div class="absolute inset-0 bg-gradient-to-t from-ink/70 via-transparent to-ink/30"></div>

    <div class="relative mx-auto flex max-w-page flex-col gap-10 px-4 pb-16 pt-10 sm:px-8 lg:px-12 lg:pb-24 lg:pt-16">
      <h1
        class="mx-auto max-w-4xl text-center font-display text-5xl uppercase leading-[0.95] tracking-tight text-white sm:text-7xl lg:text-8xl"
      >
        Будинок-конструктор
      </h1>

      <div class="flex flex-col items-center gap-8 lg:flex-row lg:items-end lg:justify-between">
        <PillButton variant="light" class="mx-auto lg:mx-0">Отримати консультацію</PillButton>

        <div class="w-56 shrink-0 rounded-[52px] bg-surface-soft p-2.5 text-center sm:w-64">
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/31496a65acd54d1e17f93d9869034147772cf370?width=414"
            alt="Модуль 62,5 м²"
            class="w-full rounded-[42px] object-cover"
          />
          <p class="mt-3 text-3xl font-normal tracking-tight text-ink-soft sm:text-4xl">62,5 м2</p>
          <p class="mt-2 text-sm tracking-tight text-neutral-500">стартовий розмір будинку</p>
        </div>
      </div>
    </div>
  </section>
</template>
