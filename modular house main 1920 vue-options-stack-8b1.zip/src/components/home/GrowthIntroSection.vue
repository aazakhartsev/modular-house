<script setup lang="ts">
import GradientHeading from '@/components/ui/GradientHeading.vue'
</script>

<template>
  <section class="mx-auto max-w-4xl px-4 py-20 text-center sm:px-8 lg:py-28">
    <GradientHeading as="h2" class="text-4xl sm:text-6xl lg:text-7xl">
      Будинок, який зростає разом з Вами
    </GradientHeading>
    <p class="mx-auto mt-8 max-w-2xl text-lg leading-relaxed tracking-tight text-ink/80 sm:text-2xl">
      Наші будинки — це не просто квадратні метри, а розумна екосистема, яка забезпечує повну автономність.
    </p>
  </section>
</template>
