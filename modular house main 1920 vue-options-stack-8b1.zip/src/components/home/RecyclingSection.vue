<script setup lang="ts">
import PillButton from '@/components/ui/PillButton.vue'

const bullets = [
  'Генерують електроенергію та біогаз',
  'Збирають та очищують воду',
  'Перероблюють сміття та відходи',
  'Легко добудовувати',
  'Монтаж та демонтаж за 3 дні',
]

const modules = [
  { value: '+ 27 м²', label: 'кожен наступний модуль', bg: 'bg-surface-sky' },
  { value: '40 кВт-г', label: 'акумуляторні батареї', bg: 'bg-surface-grey' },
  { value: '15 кВт', label: 'гібридний інвертор', bg: 'bg-surface-sky' },
  { value: '12 кВт', label: 'сонячні панелі', bg: 'bg-surface-grey' },
  { value: '100%', label: 'енергонезалежність', bg: 'bg-surface-sky' },
]
</script>

<template>
  <section id="recycling" class="px-4 py-10 sm:px-8 lg:px-12">
    <div class="relative mx-auto max-w-page overflow-hidden rounded-[40px] sm:rounded-[60px]">
      <img
        src="https://api.builder.io/api/v1/image/assets/TEMP/b5432efab8e84bdcd6fba295562af991a4c8084e?width=3908"
        alt="Модульні енергонезалежні будинки"
        class="h-full w-full object-cover"
      />
      <div class="absolute inset-0 bg-gradient-to-r from-ink/70 via-ink/20 to-transparent"></div>
      <div class="absolute inset-0 flex flex-col justify-between p-6 sm:p-12 lg:p-16">
        <PillButton variant="light" class="max-w-[320px]">Отримати консультацію</PillButton>
        <div class="max-w-xl">
          <h2 class="text-3xl font-normal leading-[0.95] tracking-tight text-white sm:text-5xl">
            Модульні енергонезалежні будинки
          </h2>
          <ul class="mt-6 flex flex-col gap-2 text-base tracking-tight text-white sm:text-2xl">
            <li v-for="bullet in bullets" :key="bullet" class="flex items-start gap-2">
              <span>✓</span>
              <span>{{ bullet }}</span>
            </li>
          </ul>
        </div>
      </div>
    </div>

    <div class="mx-auto mt-6 grid max-w-page grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
      <div
        v-for="mod in modules"
        :key="mod.label"
        class="flex flex-col justify-end gap-2 rounded-[32px] border border-ink/80 px-6 py-8"
        :class="mod.bg"
      >
        <span class="text-3xl font-medium tracking-tight text-ink sm:text-4xl">{{ mod.value }}</span>
        <span class="text-lg tracking-tight text-ink sm:text-xl">{{ mod.label }}</span>
      </div>
    </div>
  </section>
</template>
