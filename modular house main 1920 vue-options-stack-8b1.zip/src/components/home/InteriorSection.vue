<script setup lang="ts">
import GradientHeading from '@/components/ui/GradientHeading.vue'
import PillButton from '@/components/ui/PillButton.vue'

const pillFeatures = ['Сучасні матеріали', 'Естетичний вигляд', 'Відкрите планування', 'Світло й мінімалізм']
</script>

<template>
  <section class="mx-auto max-w-page px-4 py-16 sm:px-8 lg:px-12 lg:py-24">
    <div class="mx-auto flex max-w-4xl flex-col items-center gap-6 text-center">
      <PillButton variant="dark" class="max-w-[320px]">Отримати консультацію</PillButton>
      <GradientHeading as="h2" class="text-4xl sm:text-6xl lg:text-7xl">
        Затишний та продуманий інтер'єр
      </GradientHeading>
      <p class="max-w-2xl text-lg leading-relaxed tracking-tight text-ink/80 sm:text-2xl">
        Наші інженери продумали все: від розташування розеток та вимикачів до напрямку відкриття шаф. Ми
        поєднали функціональність і естетику, щоб кожна кімната відчувалась як продовження Вас
      </p>
    </div>

    <div class="mt-14 grid gap-10 lg:grid-cols-[1fr_1.6fr] lg:items-center">
      <div class="flex flex-col gap-4">
        <div
          v-for="feature in pillFeatures.slice(0, 1)"
          :key="feature"
          class="flex items-center gap-4 rounded-full border border-ink px-7 py-5"
        >
          <span class="flex h-9 w-9 items-center justify-center rounded-full border border-ink">
            <span class="block h-0.5 w-3 rounded bg-ink"></span>
          </span>
          <span class="text-xl tracking-tight text-ink sm:text-2xl">{{ feature }}</span>
        </div>

        <div class="rounded-[46px] border border-ink p-7">
          <h3 class="text-xl font-semibold tracking-tight text-ink sm:text-2xl">Широкий вибір фасадів</h3>
          <p class="mt-4 text-lg tracking-tight text-ink/80 sm:text-xl">
            Кожен інтер'єр проектується індивідуально під замовника.
          </p>
        </div>

        <div
          v-for="feature in pillFeatures.slice(1)"
          :key="feature"
          class="flex items-center gap-4 rounded-full border border-ink px-7 py-5"
        >
          <span class="flex h-9 w-9 items-center justify-center rounded-full border border-ink">
            <span class="block h-0.5 w-3 rounded bg-ink"></span>
          </span>
          <span class="text-xl tracking-tight text-ink sm:text-2xl">{{ feature }}</span>
        </div>
      </div>

      <img
        src="https://api.builder.io/api/v1/image/assets/TEMP/8f1cdd3b401174464c654f4a04e76bc2f661edca?width=2283"
        alt="Інтер'єр вітальні"
        class="w-full rounded-[40px] object-cover sm:rounded-[54px]"
      />
    </div>
  </section>
</template>
