<script setup lang="ts">
import GradientHeading from '@/components/ui/GradientHeading.vue'

const callouts = [
  { title: 'Профіль Rehau Synego 86мм', text: '7-камерна система з терморозривом' },
  { title: 'Склопакет Glas Trösch 50мм', text: 'Швейцарська якість' },
  { title: 'Система аргонопостачання', text: 'Постійне наповнення склопакетів аргоном.' },
  { title: 'Економія тепла вдвічі', text: 'Зменшує тепловтрати, робить будинок теплішим.' },
]
</script>

<template>
  <section class="mx-auto max-w-page px-4 py-16 sm:px-8 lg:px-12 lg:py-24">
    <div class="mx-auto max-w-3xl text-center">
      <GradientHeading as="h2" class="text-4xl sm:text-6xl lg:text-7xl">
        Преміальні енергоефективні вікна
      </GradientHeading>
      <p class="mx-auto mt-6 max-w-sm text-lg tracking-tight text-ink/80 sm:text-2xl">
        Технологія Rehau та Glas Trösch для затишку та економії.
      </p>
    </div>

    <div class="relative mt-14 overflow-hidden rounded-[50px] bg-ink sm:rounded-[60px]">
      <img
        src="https://api.builder.io/api/v1/image/assets/TEMP/6b453b5ce84447ce0578bb23fe3ef2c6d1f39046?width=1947"
        alt="Преміальні вікна"
        class="h-full w-full object-cover"
      />
      <div class="absolute inset-x-0 bottom-0 flex items-end justify-center gap-10 bg-gradient-to-t from-black/50 to-transparent p-6">
        <img
          src="https://api.builder.io/api/v1/image/assets/TEMP/6f9ee588c18bac4094dcaf270e40643fed6a32bf?width=179"
          alt="REHAU"
          class="h-6 w-auto brightness-0 invert sm:h-8"
        />
        <img
          src="https://api.builder.io/api/v1/image/assets/TEMP/be133837eb8a3ff25a3b7be3d396f3fd34ef71f1?width=188"
          alt="Glas Trösch"
          class="h-6 w-auto brightness-0 invert sm:h-8"
        />
      </div>
    </div>

    <div class="mt-14 grid gap-x-10 gap-y-8 sm:grid-cols-2">
      <div v-for="callout in callouts" :key="callout.title" class="flex items-start gap-5">
        <svg width="56" height="56" viewBox="0 0 94 94" fill="none" class="shrink-0">
          <circle cx="47" cy="47" r="46" stroke="url(#wg)" stroke-width="2" />
          <defs>
            <linearGradient id="wg" x1="47" y1="0" x2="47" y2="94" gradientUnits="userSpaceOnUse">
              <stop stop-color="#273947" />
              <stop offset="1" stop-color="#476587" />
            </linearGradient>
          </defs>
        </svg>
        <div>
          <p class="text-lg font-normal leading-snug tracking-tight text-ink sm:text-2xl">{{ callout.title }}</p>
          <p class="mt-1 text-lg leading-snug tracking-tight text-ink sm:text-2xl">{{ callout.text }}</p>
        </div>
      </div>
    </div>
  </section>
</template>
