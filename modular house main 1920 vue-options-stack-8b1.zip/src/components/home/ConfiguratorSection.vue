<script setup lang="ts">
import { computed, ref } from 'vue'
import GradientHeading from '@/components/ui/GradientHeading.vue'
import PillButton from '@/components/ui/PillButton.vue'

const BASE_AREA = 62.5
const MODULE_AREA = 27
const BASE_PRICE = 22500
const MODULE_PRICE = 4100
const BATTERY_PRICE_PER_KWH = 90
const PANEL_PRICE_PER_KW = 350

const moduleCount = ref(1)
const voltage = ref<'low' | 'high'>('low')
const batteryKwh = ref(40)
const panelKw = ref(12)

const totalArea = computed(() => BASE_AREA + moduleCount.value * MODULE_AREA)

const price = computed(() => {
  const base = BASE_PRICE + moduleCount.value * MODULE_PRICE
  const battery = batteryKwh.value * BATTERY_PRICE_PER_KWH
  const panels = panelKw.value * PANEL_PRICE_PER_KW
  const voltagePremium = voltage.value === 'high' ? 1800 : 0
  return Math.round(base + battery + panels + voltagePremium)
})

const formattedPrice = computed(() => `$ ${price.value.toLocaleString('en-US').replace(/,/g, ' ')}`)

function changeModules(delta: number) {
  moduleCount.value = Math.min(6, Math.max(0, moduleCount.value + delta))
}
</script>

<template>
  <section class="mx-auto max-w-page px-4 py-16 sm:px-8 lg:px-12 lg:py-24">
    <GradientHeading as="h2" class="text-center text-4xl sm:text-6xl lg:text-7xl">Онлайн-калькулятор</GradientHeading>
    <p class="mx-auto mt-6 max-w-xl text-center text-lg tracking-tight text-ink/80 sm:text-2xl">
      Порахуйте приблизну ціну будинка-конструктора
    </p>

    <div class="mt-14 grid gap-8 lg:grid-cols-2">
      <div class="relative flex flex-col gap-6 rounded-[34px] border-4 border-brand bg-surface-line px-8 py-10">
        <div class="flex items-center gap-4">
          <span class="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-brand-gradient text-3xl text-white">
            1
          </span>
          <h3 class="text-2xl font-semibold tracking-tight text-ink sm:text-3xl">Конфігурація простору</h3>
        </div>
        <p class="text-lg font-semibold uppercase tracking-tight text-ink">Площа будинку</p>
        <p class="text-lg font-semibold tracking-tight text-ink">Базовий модуль: 62,5м2</p>
        <p class="text-lg font-semibold tracking-tight text-ink">Додаткові модулі (мінімум 27м2)</p>
        <div class="flex items-center gap-4">
          <button
            type="button"
            class="flex h-14 w-14 items-center justify-center rounded-full border border-brand bg-surface-line text-3xl text-ink"
            @click="changeModules(1)"
          >
            +
          </button>
          <button
            type="button"
            class="flex h-14 w-14 items-center justify-center rounded-full border border-brand bg-surface-line text-3xl text-ink"
            @click="changeModules(-1)"
          >
            -
          </button>
          <span class="flex h-14 w-14 items-center justify-center rounded-full border border-brand bg-surface-line text-2xl text-ink">
            {{ moduleCount }}
          </span>
          <span class="text-lg tracking-tight text-ink">{{ moduleCount }} × {{ MODULE_AREA }} м2</span>
        </div>
        <p class="text-sm font-semibold tracking-tight text-ink">Загальна площа: {{ totalArea }}м2</p>
      </div>

      <div class="relative flex flex-col gap-6 rounded-[34px] border-4 border-brand bg-surface-line px-8 py-10">
        <div class="flex items-center gap-4">
          <span class="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-brand-gradient text-3xl text-white">
            2
          </span>
          <h3 class="text-2xl font-semibold uppercase tracking-tight text-ink sm:text-3xl">Гібридний інвертор</h3>
        </div>
        <div>
          <p class="text-lg font-semibold tracking-tight text-ink">Фази</p>
          <div class="mt-3 flex flex-wrap gap-3">
            <button
              type="button"
              class="rounded-2xl border border-brand px-6 py-2 text-lg tracking-tight"
              :class="voltage === 'low' ? 'bg-accent-gradient text-ink' : 'bg-transparent text-ink'"
              @click="voltage = 'low'"
            >
              низьковольтний
            </button>
            <button
              type="button"
              class="rounded-2xl border border-brand px-6 py-2 text-lg tracking-tight"
              :class="voltage === 'high' ? 'bg-accent-gradient text-ink' : 'bg-transparent text-ink'"
              @click="voltage = 'high'"
            >
              високовольтний
            </button>
          </div>
        </div>
        <div>
          <p class="text-lg font-semibold tracking-tight text-ink">Потужність (кВт)</p>
          <input
            v-model.number="panelKw"
            type="range"
            min="6"
            max="80"
            step="1"
            class="mt-3 w-full accent-accent-blue"
          />
          <div class="mt-1 flex justify-between text-base tracking-tight text-ink/70">
            <span>6</span>
            <span class="font-semibold text-ink">{{ panelKw }} кВт</span>
            <span>80</span>
          </div>
        </div>
      </div>

      <div class="relative flex flex-col gap-6 rounded-[34px] border-4 border-brand bg-surface-line px-8 py-10">
        <div class="flex items-center gap-4">
          <span class="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-brand-gradient text-3xl text-white">
            3
          </span>
          <h3 class="text-2xl font-semibold tracking-tight text-ink sm:text-3xl">Акумуляторна батарея</h3>
        </div>
        <p class="text-lg font-semibold tracking-tight text-ink">Ємність: кВт-г</p>
        <input v-model.number="batteryKwh" type="range" min="5" max="100" step="1" class="accent-accent-blue" />
        <div class="flex justify-between text-base tracking-tight text-ink/70">
          <span>5 кВт-г</span>
          <span class="font-semibold text-ink">{{ batteryKwh }} кВт-г</span>
          <span>100 кВт-г</span>
        </div>
      </div>

      <div class="relative flex flex-col gap-6 rounded-[34px] border-4 border-brand bg-surface-line px-8 py-10">
        <div class="flex items-center gap-4">
          <span class="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-brand-gradient text-3xl text-white">
            4
          </span>
          <h3 class="text-2xl font-semibold tracking-tight text-ink sm:text-3xl">Сонячні панелі</h3>
        </div>
        <p class="text-lg font-semibold tracking-tight text-ink">Ємність: кВт-г</p>
        <input v-model.number="panelKw" type="range" min="5" max="102" step="1" class="accent-accent-blue" />
        <div class="flex justify-between text-base tracking-tight text-ink/70">
          <span>5.1 кВт-г</span>
          <span class="font-semibold text-ink">{{ panelKw }} кВт</span>
          <span>102 кВт-г</span>
        </div>
      </div>
    </div>

    <div class="mt-10 flex flex-col items-center gap-4 rounded-[30px] bg-brand-gradient px-6 py-12 text-center sm:px-16">
      <p class="bg-gradient-to-b from-accent-cyan to-accent-blue bg-clip-text text-5xl font-semibold tracking-tight text-transparent sm:text-7xl">
        {{ formattedPrice }}
      </p>
      <p class="text-lg tracking-tight text-white sm:text-2xl">приблизна вартість будинку</p>
      <PillButton variant="light" class="mt-4">Отримати консультацію</PillButton>
    </div>
  </section>
</template>
