<script setup lang="ts">
import GradientHeading from '@/components/ui/GradientHeading.vue'
import StatCard from '@/components/ui/StatCard.vue'

const stats = [
  { value: '25 тонн', label: 'навантаження \nна один геошуруп' },
  { value: '50 - 100', label: 'років служби в ґрунті' },
  { value: '18 шт', label: 'геошурупів \nна один модуль 62,5 м2' },
  { value: '-30С°', label: 'стійкість до \nморозу' },
]

const features = [
  {
    title: 'Будь-який ґрунт',
    text: 'Геошурупи можна вмонтувати в будь-який ґрунт: пісок, глина, торф, схили, а також в дно водойомів',
  },
  {
    title: 'Швидкий монтаж',
    text: 'Встановлення за 1 робочий день без бетону та опалубки',
  },
  {
    title: 'Демонтаж та перенос',
    text: 'На відміну від бетону — геошурупи можна викрутити та перенести на інше місце. Вони не псують землю. Їх можна використовувати на землях сільско-господарського призначення.',
  },
]
</script>

<template>
  <section class="mx-auto max-w-page px-4 py-16 sm:px-8 lg:px-12 lg:py-24">
    <div class="mx-auto max-w-3xl text-center">
      <GradientHeading as="h2" class="text-4xl sm:text-6xl lg:text-7xl"
        >Надійний фундамент,<br class="hidden sm:block" />
        який не псує землю</GradientHeading
      >
      <p class="mx-auto mt-6 max-w-lg text-lg tracking-tight text-ink/80 sm:text-2xl">
        Ми використовуємо оцинковані геошурупи в якості фундаменту
      </p>
    </div>

    <div class="relative mt-14 overflow-hidden rounded-[50px] bg-ink sm:rounded-[80px]">
      <img
        src="https://api.builder.io/api/v1/image/assets/TEMP/e11bd947ccb7c3ae898a4b5395baba5a10df1d65?width=3884"
        alt="Геошурупи"
        class="h-full w-full object-cover opacity-80"
      />
      <div class="absolute inset-0 flex flex-col justify-between gap-10 p-6 sm:p-12 lg:p-16">
        <p class="max-w-2xl text-xl leading-snug tracking-tight text-white sm:text-3xl">
          <strong class="font-semibold">Геошурупи</strong> — це оцинковані металеві гвинтові палі, які
          вкручуються в ґрунт на глибину від 2 до 4,5 м. Завдяки гарячому цинкуванню їх термін служби
          скаладає від 50 до 100 років.
        </p>
        <div class="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <StatCard v-for="stat in stats" :key="stat.label" :value="stat.value" :label="stat.label" />
        </div>
      </div>
    </div>

    <div class="mt-14 grid gap-10 lg:grid-cols-[1.4fr_1fr] lg:items-center">
      <img
        src="https://api.builder.io/api/v1/image/assets/TEMP/909ee1528c8060f03d99889d08c275731bd066ef?width=2466"
        alt="Геошурупи фундамент"
        class="w-full rounded-[40px] object-cover sm:rounded-[60px]"
      />
      <div class="flex flex-col gap-8">
        <div v-for="feature in features" :key="feature.title">
          <p class="text-xl font-bold tracking-tight text-ink sm:text-2xl">{{ feature.title }}</p>
          <p class="mt-2 text-lg tracking-tight text-ink/80 sm:text-xl">{{ feature.text }}</p>
        </div>
      </div>
    </div>
  </section>
</template>
