<script setup lang="ts">
import { ref } from 'vue'
import GradientHeading from '@/components/ui/GradientHeading.vue'

const stats = [
  { value: '62.5 м2', label: 'стартова площа' },
  { value: '27 м2', label: 'на одного дорослого' },
  { value: '27 м2', label: 'кожен наступний \nмодуль' },
  { value: '18 м2', label: 'на одну дитину' },
  { value: '70%', label: 'житлова зона \nвід загальної площі' },
  { value: '1', label: 'поверх' },
  { value: '1 : 4', label: 'площа скління' },
  { value: '0', label: 'темних куточків' },
]

const fullName = ref('')
const phone = ref('')
</script>

<template>
  <section class="mx-auto max-w-page px-4 py-16 sm:px-8 lg:px-12 lg:py-24">
    <GradientHeading as="h2" class="text-center text-4xl sm:text-6xl lg:text-7xl"
      >Характеристики<br />ідеального будинку</GradientHeading
    >

    <div class="relative mt-14 overflow-hidden rounded-[50px] sm:rounded-[80px]">
      <img
        src="https://api.builder.io/api/v1/image/assets/TEMP/ed961a67074ac8fa33968675b5ae86ed00e10d8d?width=3846"
        alt=""
        class="h-full w-full object-cover"
      />
      <div class="absolute inset-0 bg-ink/40"></div>
      <div class="absolute inset-0 grid grid-cols-2 content-center gap-4 p-6 sm:grid-cols-4 sm:gap-6 sm:p-12">
        <div
          v-for="stat in stats"
          :key="stat.value + stat.label"
          class="flex min-h-[150px] flex-col items-center justify-center gap-2 rounded-[30px] border border-white bg-white/10 px-4 py-6 text-center text-white sm:min-h-[180px]"
        >
          <span class="text-3xl font-semibold tracking-tight sm:text-4xl">{{ stat.value }}</span>
          <span class="whitespace-pre-line text-base leading-tight tracking-tight sm:text-2xl">{{
            stat.label
          }}</span>
        </div>
      </div>
    </div>

    <form
      class="mx-auto mt-10 flex max-w-4xl flex-col items-stretch gap-4 sm:flex-row"
      @submit.prevent
    >
      <input
        v-model="fullName"
        type="text"
        placeholder="Імʼя"
        class="flex-1 rounded-full bg-surface-line px-7 py-5 text-lg tracking-tight text-ink placeholder:text-ink/60 outline-none sm:text-xl"
      />
      <input
        v-model="phone"
        type="tel"
        placeholder="+380 (__) ___-__-__"
        class="flex-1 rounded-full bg-surface-line px-7 py-5 text-lg tracking-tight text-ink placeholder:text-ink/60 outline-none sm:text-xl"
      />
      <button
        type="submit"
        class="shrink-0 rounded-full bg-brand px-10 py-5 text-lg tracking-tight text-white transition-transform hover:scale-[1.02] sm:text-xl"
      >
        Розрахувати вартість
      </button>
    </form>
  </section>
</template>
