<script setup lang="ts">
import { ref } from 'vue'
import GradientHeading from '@/components/ui/GradientHeading.vue'

const name = ref('')

const perks = [
  { title: 'Символ родини', text: "Передається разом з будинком. Ім'я живе стільки, скільки стоїть дім." },
  { title: 'Реєстрація імені', text: "Ім'я фіксується в нашій базі. Жоден інший будинок не матиме такого самого." },
  { title: 'Металева табличка', text: 'Лазерне гравіювання на нержавіючій сталі. Входить у комплектацію.' },
]
</script>

<template>
  <section class="mx-auto max-w-page px-4 py-16 sm:px-8 lg:px-12 lg:py-24">
    <GradientHeading as="h2" class="text-center text-4xl sm:text-6xl lg:text-7xl">Власне ім'я</GradientHeading>
    <p class="mx-auto mt-6 max-w-3xl text-center text-lg tracking-tight text-ink/80 sm:text-2xl">
      Дайте вашому будинку імʼя, яке відображає вашу родину, мрію або місце. Табличка з іменем буде
      відрізняти ваш дім серед усіх сусідів.
    </p>

    <div class="relative mt-14 overflow-hidden rounded-[50px] sm:rounded-[80px]">
      <img
        src="https://api.builder.io/api/v1/image/assets/TEMP/a6429e3d04df83b6f908d066a9b0916480c35534?width=3240"
        alt="Дім Катруся"
        class="h-full w-full object-cover"
      />
      <span
        class="absolute left-6 top-6 text-3xl font-bold uppercase tracking-tight text-white sm:left-12 sm:top-10 sm:text-5xl"
        style="-webkit-text-stroke: 1px #ffbd54"
        >Катруся</span
      >
      <form
        class="absolute inset-x-6 bottom-6 flex flex-col gap-3 sm:inset-x-12 sm:bottom-10 sm:flex-row"
        @submit.prevent
      >
        <input
          v-model="name"
          type="text"
          placeholder="Катруся"
          class="flex-1 rounded-full bg-surface-line px-7 py-4 text-lg tracking-tight text-ink placeholder:text-ink/60 outline-none sm:text-xl"
        />
        <button
          type="submit"
          class="rounded-full bg-brand px-8 py-4 text-lg tracking-tight text-white transition-transform hover:scale-[1.02] sm:text-xl"
        >
          Дати імʼя
        </button>
      </form>
    </div>

    <div class="mt-14 grid gap-10 sm:grid-cols-3">
      <div v-for="perk in perks" :key="perk.title" class="flex flex-col items-center gap-4 text-center">
        <svg width="68" height="68" viewBox="0 0 68 68" fill="none">
          <circle cx="34" cy="34" r="31.5" stroke="url(#ng)" stroke-width="5" />
          <defs>
            <linearGradient id="ng" x1="34" y1="0" x2="34" y2="68" gradientUnits="userSpaceOnUse">
              <stop stop-color="#273947" />
              <stop offset="1" stop-color="#476587" />
            </linearGradient>
          </defs>
          <text x="34" y="42" text-anchor="middle" font-size="24" fill="#273947">✓</text>
        </svg>
        <p class="bg-brand-gradient bg-clip-text text-2xl font-semibold tracking-tight text-transparent sm:text-3xl">
          {{ perk.title }}
        </p>
        <p class="text-lg tracking-tight text-ink/80 sm:text-xl">{{ perk.text }}</p>
      </div>
    </div>
  </section>
</template>
