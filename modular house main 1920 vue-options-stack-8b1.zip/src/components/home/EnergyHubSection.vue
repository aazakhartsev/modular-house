<script setup lang="ts">
import GradientHeading from '@/components/ui/GradientHeading.vue'
import StatCard from '@/components/ui/StatCard.vue'

const stats = [
  { value: '12 кВТ', label: 'Потужність \nгібридного \nінвертора' },
  { value: '112.5 кВт/год', label: 'Ємність \nакумуляторних \nбатарей' },
  { value: '12 кВт', label: 'пікова потужність \nсонячних панелей' },
]
</script>

<template>
  <section id="generation" class="mx-auto max-w-page px-4 py-16 sm:px-8 lg:px-12 lg:py-24">
    <div class="mx-auto max-w-3xl text-center">
      <GradientHeading as="h2" class="text-4xl sm:text-6xl lg:text-7xl"
        >Сучасний<br />енергетичний хаб</GradientHeading
      >
      <p class="mx-auto mt-6 max-w-2xl text-lg tracking-tight text-ink/80 sm:text-2xl">
        Повна автономність у Вашому будинку. Сонячне світло перетворюється на цілодобову електроенергію.
      </p>
    </div>

    <div class="relative mt-14 overflow-hidden rounded-[50px] bg-ink sm:rounded-[80px]">
      <img
        src="https://api.builder.io/api/v1/image/assets/TEMP/d211842f63d1e627e459dc24f425980197d25f0a?width=3890"
        alt="Будинок з сонячними панелями"
        class="h-full w-full object-cover"
      />
      <div class="absolute inset-0 bg-gradient-to-t from-ink/80 via-ink/10 to-transparent"></div>
      <div class="absolute bottom-0 left-0 right-0 flex flex-wrap items-center justify-center gap-10 p-6 text-center text-white sm:gap-16 sm:p-10">
        <div>
          <p class="text-2xl font-medium tracking-tight sm:text-3xl">Сонячні панелі</p>
        </div>
        <div>
          <p class="text-2xl font-medium leading-snug tracking-tight sm:text-3xl">
            Інвертор з системою<br />накопичення
          </p>
        </div>
      </div>
    </div>

    <div class="mt-6 grid grid-cols-1 gap-4 rounded-[40px] bg-ink p-6 sm:grid-cols-3 sm:p-10">
      <StatCard v-for="stat in stats" :key="stat.label" :value="stat.value" :label="stat.label" />
    </div>
  </section>
</template>
