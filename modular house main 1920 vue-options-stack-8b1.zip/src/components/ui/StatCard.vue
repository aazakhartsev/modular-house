<script setup lang="ts">
defineProps<{
  value: string
  label: string
}>()
</script>

<template>
  <div
    class="flex min-h-[160px] flex-col items-center justify-center gap-3 rounded-[30px] border border-white/70 bg-white/10 px-6 py-8 text-center text-white backdrop-blur-sm sm:min-h-[180px]"
  >
    <span class="text-3xl font-semibold tracking-tight sm:text-4xl">{{ value }}</span>
    <span class="whitespace-pre-line text-base leading-tight tracking-tight sm:text-xl">{{
      label
    }}</span>
  </div>
</template>
