<script setup lang="ts">
withDefaults(
  defineProps<{
    variant?: 'light' | 'dark'
  }>(),
  {
    variant: 'light',
  },
)
</script>

<template>
  <button
    type="button"
    class="group inline-flex w-full max-w-[426px] items-center justify-between gap-4 rounded-full py-2.5 pl-6 pr-2.5 text-lg transition-transform duration-200 hover:scale-[1.02] sm:text-xl"
    :class="
      variant === 'light'
        ? 'bg-white text-ink'
        : 'bg-brand text-white'
    "
  >
    <span class="truncate font-normal tracking-tight"><slot /></span>
    <span
      class="flex h-[52px] w-[52px] shrink-0 items-center justify-center rounded-full transition-colors"
      :class="variant === 'light' ? 'bg-brand text-white' : 'bg-white text-brand'"
    >
      <svg width="12" height="12" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M0 0H10V10M10 0L0 10" stroke="currentColor" stroke-width="1.5" />
      </svg>
    </span>
  </button>
</template>
