<script setup lang="ts">
withDefaults(
  defineProps<{
    as?: string
  }>(),
  {
    as: 'h2',
  },
)
</script>

<template>
  <component
    :is="as"
    class="bg-brand-gradient bg-clip-text font-semibold leading-[0.9] tracking-tight text-transparent [text-wrap:balance]"
  >
    <slot />
  </component>
</template>
