<script setup lang="ts">
const navItems = [
  { label: 'Будинки', to: '/' },
  { label: 'Генерація', to: '/#generation' },
  { label: 'Утилізація', to: '/#recycling' },
  { label: 'контакти', to: '/#contacts' },
]
</script>

<template>
  <footer class="relative overflow-hidden bg-ink text-white">
    <img
      src="https://api.builder.io/api/v1/image/assets/TEMP/e461e30c97acdd596807803148b80d76b1afa950?width=3846"
      alt=""
      class="absolute inset-0 h-full w-full object-cover opacity-70"
    />
    <div class="relative mx-auto flex max-w-page flex-col gap-10 px-4 py-12 sm:px-8 lg:px-12">
      <div class="flex flex-col items-start justify-between gap-8 lg:flex-row lg:items-center">
        <img
          src="https://api.builder.io/api/v1/image/assets/TEMP/b9a4b1bc70dc4e03407d2bed8c7b3d6f9ebf7c18?width=450"
          alt="Сервіоніка"
          class="h-8 w-auto"
        />
        <nav class="flex flex-wrap gap-x-10 gap-y-3 text-sm uppercase tracking-tight">
          <router-link v-for="item in navItems" :key="item.label" :to="item.to" class="hover:text-accent-cyan">
            {{ item.label }}
          </router-link>
        </nav>
        <a
          href="tel:+380445022888"
          class="flex items-center gap-2.5 rounded-full border border-white/30 py-2.5 pl-4 pr-2.5"
        >
          <span class="text-base tracking-tight">+38 (044) 502 2888</span>
          <span class="flex h-8 w-8 items-center justify-center rounded-full bg-white text-ink">
            <svg width="14" height="14" viewBox="0 0 32 32" fill="none">
              <path
                d="M12.5352 7.9082C12.7595 7.8791 12.9868 7.9283 13.1816 8.0478C13.3759 8.1672 13.5276 8.3502 13.6152 8.5674L15.2695 12.4951"
                stroke="currentColor"
                stroke-width="2"
                fill="none"
              />
              <circle cx="16" cy="16" r="15" stroke="currentColor" stroke-width="1" fill="none" />
            </svg>
          </span>
        </a>
      </div>

      <p class="border-t border-white/15 pt-6 text-center text-sm tracking-tight text-white/70">
        Servionica © 2026. Всі права захищені.
      </p>
    </div>
  </footer>
</template>
