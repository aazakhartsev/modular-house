<script setup lang="ts">
import { ref } from 'vue'
import { useRoute } from 'vue-router'

const route = useRoute()
const mobileOpen = ref(false)

const navItems = [
  { label: 'Будинки', to: '/' },
  { label: 'Генерація', to: '/#generation' },
  { label: 'Утилізація', to: '/#recycling' },
  { label: 'контакти', to: '/#contacts' },
]

function close() {
  mobileOpen.value = false
}
</script>

<template>
  <header class="sticky top-0 z-50 bg-ink/90 backdrop-blur-md">
    <div class="mx-auto flex max-w-page items-center justify-between gap-4 px-4 py-3 sm:px-8 lg:px-12">
      <router-link to="/" class="shrink-0" @click="close">
        <img
          src="https://api.builder.io/api/v1/image/assets/TEMP/b9a4b1bc70dc4e03407d2bed8c7b3d6f9ebf7c18?width=450"
          alt="Сервіоніка"
          class="h-7 w-auto sm:h-9"
        />
      </router-link>

      <nav class="hidden items-center gap-1 rounded-full border border-white/30 p-1 lg:flex">
        <router-link
          v-for="item in navItems"
          :key="item.label"
          :to="item.to"
          class="rounded-full px-5 py-2 text-sm font-normal uppercase tracking-tight text-white transition-colors hover:bg-white/10"
          :class="{ 'bg-white !text-ink': item.to === '/' && route.path === '/' }"
        >
          {{ item.label }}
        </router-link>
      </nav>

      <div class="hidden items-center gap-3 xl:flex">
        <a
          href="tel:+380445022888"
          class="flex items-center gap-2.5 rounded-full border border-white/30 py-2.5 pl-4 pr-2.5 text-white"
        >
          <span class="text-base tracking-tight">+38 (044) 502 2888</span>
          <span class="flex h-8 w-8 items-center justify-center rounded-full bg-white text-ink">
            <svg width="16" height="16" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M12.5352 7.8999C12.7595 7.87082 12.9868 7.91996 13.1816 8.03955C13.3759 8.15892 13.5276 8.3419 13.6152 8.55908L15.2695 12.4868L15.2705 12.4888C15.3379 12.6556 15.3655 12.8375 15.3506 13.0181C15.3357 13.1986 15.2786 13.3728 15.1846 13.5249L15.1836 13.5269L15.1562 13.5659L13.5049 15.6587C13.4884 15.6896 13.4792 15.725 13.4775 15.7612C13.4758 15.7992 13.4831 15.8367 13.498 15.8706L13.6191 16.1177C14.2631 17.356 15.4758 18.5997 16.6455 19.2026C16.6759 19.2177 16.7094 19.2251 16.7422 19.2231C16.7741 19.2212 16.8048 19.2097 16.833 19.1919L18.7607 17.4399L18.8018 17.4077C18.9454 17.3069 19.1108 17.2452 19.2832 17.229C19.4128 17.2169 19.5431 17.2305 19.667 17.269L19.7891 17.3159L19.79 17.3169L23.4775 19.0767C23.6832 19.172 23.8537 19.3354 23.9639 19.5405C24.074 19.7456 24.1193 19.9826 24.0928 20.2163V20.2173C23.9604 21.2883 23.4663 22.2728 22.7021 22.9858C21.9857 23.6543 21.0773 24.0415 20.1279 24.0854L19.9375 24.0894C13.8452 24.0893 8.90057 18.8061 8.90039 12.3247C8.89829 11.2446 9.26454 10.1997 9.93262 9.38525C10.6008 8.57078 11.5253 8.04186 12.5342 7.8999H12.5352Z"
                fill="currentColor"
              />
            </svg>
          </span>
        </a>
        <div class="rounded-full border border-white/30 px-5 py-2.5 text-base uppercase tracking-tight">
          <span class="text-white">uk</span>
          <span class="text-white/50"> | en </span>
          <span class="text-white">|</span>
          <span class="text-white/50"> pl</span>
        </div>
      </div>

      <button
        type="button"
        class="flex h-10 w-10 items-center justify-center rounded-full border border-white/30 text-white lg:hidden"
        aria-label="Відкрити меню"
        @click="mobileOpen = !mobileOpen"
      >
        <svg v-if="!mobileOpen" width="20" height="20" viewBox="0 0 24 24" fill="none">
          <path d="M3 6h18M3 12h18M3 18h18" stroke="currentColor" stroke-width="2" stroke-linecap="round" />
        </svg>
        <svg v-else width="18" height="18" viewBox="0 0 24 24" fill="none">
          <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" />
        </svg>
      </button>
    </div>

    <div v-if="mobileOpen" class="border-t border-white/10 px-4 pb-6 pt-2 lg:hidden">
      <nav class="flex flex-col gap-1">
        <router-link
          v-for="item in navItems"
          :key="item.label"
          :to="item.to"
          class="rounded-xl px-4 py-3 text-base uppercase tracking-tight text-white transition-colors hover:bg-white/10"
          @click="close"
        >
          {{ item.label }}
        </router-link>
      </nav>
      <a
        href="tel:+380445022888"
        class="mt-4 flex items-center justify-center rounded-full border border-white/30 py-3 text-white"
        >+38 (044) 502 2888</a
      >
    </div>
  </header>
</template>
