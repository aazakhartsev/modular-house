<script setup lang="ts">
import HeroSection from '@/components/home/HeroSection.vue'
import GrowthIntroSection from '@/components/home/GrowthIntroSection.vue'
import RecyclingSection from '@/components/home/RecyclingSection.vue'
import InteriorSection from '@/components/home/InteriorSection.vue'
import WarmHouseSection from '@/components/home/WarmHouseSection.vue'
import FoundationSection from '@/components/home/FoundationSection.vue'
import WindowsSection from '@/components/home/WindowsSection.vue'
import EnergyHubSection from '@/components/home/EnergyHubSection.vue'
import NamingSection from '@/components/home/NamingSection.vue'
import ConfiguratorSection from '@/components/home/ConfiguratorSection.vue'
import CharacteristicsSection from '@/components/home/CharacteristicsSection.vue'
import ContactsSection from '@/components/home/ContactsSection.vue'
</script>

<template>
  <div>
    <HeroSection />
    <GrowthIntroSection />
    <RecyclingSection />
    <InteriorSection />
    <WarmHouseSection />
    <FoundationSection />
    <WindowsSection />
    <EnergyHubSection />
    <NamingSection />
    <ConfiguratorSection />
    <CharacteristicsSection />
    <ContactsSection />
  </div>
</template>
