<script setup lang="ts">
import { useRoute } from 'vue-router'
import GradientHeading from '@/components/ui/GradientHeading.vue'

const route = useRoute()
</script>

<template>
  <section class="mx-auto flex max-w-page flex-col items-center gap-6 px-4 py-32 text-center sm:px-8">
    <span class="rounded-full border border-brand/30 px-4 py-1 text-sm uppercase tracking-tight text-brand"
      >Сторінка в розробці</span
    >
    <GradientHeading as="h1" class="text-4xl sm:text-5xl">{{ route.path }}</GradientHeading>
    <p class="max-w-xl text-lg text-ink/70">
      Цей розділ ще не наповнений контентом. Продовжуйте діалог з асистентом, щоб ми додали сюди потрібну
      інформацію.
    </p>
    <router-link
      to="/"
      class="rounded-full bg-brand px-8 py-3 text-base text-white transition-transform hover:scale-[1.02]"
      >На головну</router-link
    >
  </section>
</template>
