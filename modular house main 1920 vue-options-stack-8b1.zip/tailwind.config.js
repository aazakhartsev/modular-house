/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{vue,js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['"Playfair Display"', 'serif'],
        sans: ['"Golos Text"', '-apple-system', 'Roboto', 'Helvetica', 'sans-serif'],
      },
      colors: {
        ink: {
          DEFAULT: '#0B1926',
          soft: '#0E1E28',
        },
        brand: {
          DEFAULT: '#273947',
          light: '#476587',
          dark: '#1a2832',
        },
        accent: {
          cyan: '#45E5FF',
          blue: '#006EA3',
        },
        surface: {
          soft: '#F8F8F8',
          mute: '#F1F1F1',
          grey: '#E5E5E5',
          line: '#D9D9D9',
          sky: '#BED9E6',
        },
      },
      backgroundImage: {
        'brand-gradient': 'linear-gradient(180deg, #273947 0%, #476587 100%)',
        'accent-gradient': 'linear-gradient(90deg, #45E5FF 0%, #006EA3 100%)',
      },
      maxWidth: {
        page: '1920px',
      },
    },
  },
  plugins: [],
}
