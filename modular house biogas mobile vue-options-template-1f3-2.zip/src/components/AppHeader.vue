<template>
  <header class="header">
    <router-link to="/" class="header__logo" aria-label="Servionica">
      <img
        src="https://api.builder.io/api/v1/image/assets/TEMP/9dfa48e0523854ea0e196dde2758e80c410f7aee?width=248"
        alt="Servionica"
        width="124"
        height="25"
      />
    </router-link>

    <button class="header__burger" type="button" aria-label="Меню" @click="toggleMenu">
      <svg width="28" height="25" viewBox="0 0 28 25" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M0 12.462H28M0 24.9239H28M0 0H28" stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
      </svg>
    </button>

    <v-navigation-drawer
      :model-value="menuOpen"
      temporary
      location="right"
      class="drawer"
      @update:model-value="setMenu"
    >
      <nav class="drawer__nav">
        <router-link
          v-for="item in navItems"
          :key="item.hash"
          :to="{ path: '/', hash: item.hash }"
          @click="closeMenu"
        >
          {{ item.label }}
        </router-link>
        <a href="tel:+380445022888">+38 (044) 502 2888</a>
      </nav>
    </v-navigation-drawer>
  </header>
</template>

<script>
import { mapActions, mapState } from 'vuex'
import { NAV_ITEMS } from '@/constants/nav'

export default {
  name: 'AppHeader',
  data() {
    return { navItems: NAV_ITEMS }
  },
  computed: {
    ...mapState('ui', ['menuOpen']),
  },
  methods: {
    ...mapActions('ui', ['toggleMenu', 'closeMenu']),
    setMenu(value) {
      if (!value) this.closeMenu()
    },
  },
}
</script>

<style scoped lang="scss">
@use '@/styles/variables' as *;

.header {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 0;
  z-index: 10;

  &__logo {
    position: absolute;
    left: 32px;
    top: 43px;

    img {
      width: 124px;
      height: 25px;
    }
  }

  &__burger {
    position: absolute;
    left: 330px;
    top: 48px;
    width: 28px;
    height: 25px;
    padding: 0;
    background: none;
    border: 0;
    cursor: pointer;

    svg {
      display: block;
    }
  }
}

.drawer {
  &__nav {
    display: flex;
    flex-direction: column;
    gap: 28px;
    padding: 48px 28px;

    a {
      color: $navy;
      font-size: 18px;
      letter-spacing: -0.64px;
      text-transform: uppercase;
      text-decoration: none;
    }
  }
}
</style>
