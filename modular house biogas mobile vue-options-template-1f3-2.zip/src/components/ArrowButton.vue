<template>
  <v-btn
    :class="['arrow-btn', 'arrow-btn--' + theme]"
    :href="href"
    :type="href ? undefined : type"
    :loading="loading"
    variant="flat"
    rounded="pill"
    @click="$emit('click', $event)"
  >
    <span class="arrow-btn__label">{{ label }}</span>
    <span class="arrow-btn__circle">
      <svg width="7" height="7" viewBox="0 0 7 7" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M0 0H6.10329V6.10329M6.10329 0L0 6.10329" stroke="currentColor" stroke-width="0.915493" />
      </svg>
    </span>
  </v-btn>
</template>

<script>
export default {
  name: 'ArrowButton',
  props: {
    label: { type: String, required: true },
    theme: { type: String, default: 'light' },
    href: { type: String, default: undefined },
    type: { type: String, default: 'button' },
    loading: { type: Boolean, default: false },
  },
  emits: ['click'],
}
</script>

<style scoped lang="scss">
@use '@/styles/variables' as *;

.arrow-btn.v-btn {
  position: relative;
  width: 260px;
  max-width: 100%;
  height: 53px;
  padding: 0 8px 0 0;
  text-transform: none;
  font-family: $font;
  font-size: 16px;
  font-weight: 400;
  letter-spacing: -0.48px;

  :deep(.v-btn__content) {
    width: 100%;
    justify-content: space-between;
  }

  &__label {
    padding-left: 22px;
  }

  &__circle {
    display: grid;
    place-items: center;
    width: 38px;
    height: 38px;
    border-radius: 50%;
    transition: transform 0.25s ease;
  }

  &:hover &__circle {
    transform: rotate(45deg);
  }

  &--light {
    background: #fff;
    color: #000;
    .arrow-btn__circle {
      background: $navy;
      color: #fff;
    }
  }

  &--dark {
    background: $navy;
    color: #fff;
    .arrow-btn__circle {
      background: #fff;
      color: $navy;
    }
  }
}
</style>
