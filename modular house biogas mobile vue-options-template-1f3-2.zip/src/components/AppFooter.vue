<template>
  <footer class="footer">
    <img
      class="footer__bg"
      src="https://api.builder.io/api/v1/image/assets/TEMP/7ca7162e18eed3c09cccba2f6d72a840309c862d?width=1658"
      alt=""
    />
    <img
      class="footer__logo"
      src="https://api.builder.io/api/v1/image/assets/TEMP/838b64f7be4d535943300c1bb7d76b5e67fd1304?width=322"
      alt="Servionica"
      width="161"
      height="32"
    />

    <nav class="footer__nav" aria-label="Навігація у футері">
      <router-link v-for="item in navItems" :key="item.hash" :to="{ path: '/', hash: item.hash }">
        {{ item.label }}
      </router-link>
    </nav>

    <PhoneButton class="footer__phone" />

    <div class="footer__social">
      <a href="https://www.instagram.com/" target="_blank" rel="noopener" aria-label="Instagram">
        <svg width="56" height="56" viewBox="0 0 56 56" fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="28" cy="28" r="28" fill="#F1F1F1" />
          <path d="M28.8636 19.5996C29.8086 19.6021 30.2882 19.6072 30.7023 19.6189L30.8652 19.6248C31.0534 19.6315 31.239 19.6399 31.4633 19.65C32.357 19.692 32.9668 19.8331 33.5019 20.0406C34.0562 20.254 34.5233 20.5429 34.9903 21.0091C35.4176 21.4289 35.7481 21.9368 35.9587 22.4975C36.1662 23.0326 36.3073 23.6424 36.3493 24.537C36.3594 24.7604 36.3678 24.9461 36.3745 25.1351L36.3796 25.298C36.3922 25.7113 36.3972 26.1909 36.3989 27.1359L36.3997 27.7625V28.8629C36.4018 29.4756 36.3953 30.0883 36.3804 30.7008L36.3754 30.8637C36.3686 31.0527 36.3602 31.2384 36.3502 31.4618C36.3082 32.3564 36.1654 32.9654 35.9587 33.5013C35.7481 34.062 35.4176 34.57 34.9903 34.9897C34.5705 35.417 34.0626 35.7475 33.5019 35.9582C32.9668 36.1657 32.357 36.3068 31.4633 36.3488L30.8652 36.374L30.7023 36.379C30.2882 36.3908 29.8086 36.3967 28.8636 36.3984L28.237 36.3992H27.1375C26.5246 36.4014 25.9116 36.3949 25.2988 36.3799L25.1359 36.3748C24.9365 36.3673 24.7371 36.3586 24.5378 36.3488C23.6441 36.3068 23.0343 36.1657 22.4984 35.9582C21.938 35.7474 21.4304 35.4169 21.0109 34.9897C20.5833 34.57 20.2525 34.0621 20.0416 33.5013C19.8341 32.9662 19.693 32.3564 19.651 31.4618L19.6258 30.8637L19.6216 30.7008C19.6061 30.0883 19.5991 29.4756 19.6006 28.8629V27.1359C19.5983 26.5232 19.6044 25.9105 19.6191 25.298L19.6249 25.1351C19.6317 24.9461 19.6401 24.7604 19.6501 24.537C19.6921 23.6424 19.8332 23.0334 20.0407 22.4975C20.2521 21.9366 20.5835 21.4286 21.0117 21.0091C21.431 20.582 21.9383 20.2515 22.4984 20.0406C23.0343 19.8331 23.6433 19.692 24.5378 19.65C24.7613 19.6399 24.9477 19.6315 25.1359 19.6248L25.2988 19.6198C25.9113 19.6048 26.524 19.5984 27.1367 19.6004L28.8636 19.5996ZM28.0002 23.7995C26.8863 23.7995 25.8181 24.242 25.0305 25.0296C24.2428 25.8173 23.8004 26.8855 23.8004 27.9994C23.8004 29.1133 24.2428 30.1815 25.0305 30.9692C25.8181 31.7568 26.8863 32.1993 28.0002 32.1993C29.114 32.1993 30.1822 31.7568 30.9698 30.9692C31.7575 30.1815 32.1999 29.1133 32.1999 27.9994C32.1999 26.8855 31.7575 25.8173 30.9698 25.0296C30.1822 24.242 29.114 23.7995 28.0002 23.7995ZM28.0002 25.4795C28.3311 25.4794 28.6588 25.5445 28.9645 25.6711C29.2702 25.7977 29.5481 25.9833 29.7821 26.2172C30.0161 26.4512 30.2018 26.729 30.3285 27.0347C30.4552 27.3404 30.5204 27.6681 30.5204 27.999C30.5205 28.3299 30.4554 28.6576 30.3288 28.9634C30.2022 29.2691 30.0166 29.5469 29.7827 29.781C29.5487 30.015 29.271 30.2007 28.9653 30.3274C28.6596 30.4541 28.3319 30.5193 28.001 30.5193C27.3327 30.5193 26.6917 30.2539 26.2192 29.7813C25.7466 29.3087 25.4811 28.6677 25.4811 27.9994C25.4811 27.3311 25.7466 26.6901 26.2192 26.2175C26.6917 25.745 27.3327 25.4795 28.001 25.4795M32.4108 22.5395C32.1323 22.5395 31.8652 22.6502 31.6683 22.8471C31.4714 23.044 31.3608 23.311 31.3608 23.5895C31.3608 23.868 31.4714 24.135 31.6683 24.332C31.8652 24.5289 32.1323 24.6395 32.4108 24.6395C32.6892 24.6395 32.9563 24.5289 33.1532 24.332C33.3501 24.135 33.4607 23.868 33.4607 23.5895C33.4607 23.311 33.3501 23.044 33.1532 22.8471C32.9563 22.6502 32.6892 22.5395 32.4108 22.5395Z" fill="#1c2a37" />
        </svg>
      </a>
      <a href="https://www.facebook.com/" target="_blank" rel="noopener" aria-label="Facebook">
        <svg width="56" height="56" viewBox="0 0 56 56" fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="28" cy="28" r="28" fill="#F1F1F1" />
          <path d="M26.058 37.7996H29.829V30.1269H33.227L33.6 26.3145H29.829V24.3891C29.829 24.135 29.928 23.8914 30.105 23.7117C30.282 23.5321 30.522 23.4312 30.772 23.4312H33.6V19.5996H30.772C29.522 19.5996 28.323 20.1042 27.439 21.0024C26.555 21.9006 26.058 23.1188 26.058 24.3891V26.3145H24.173L23.8 30.1269H26.058V37.7996Z" fill="#1c2a37" />
        </svg>
      </a>
    </div>

    <p class="footer__copy">Servionica © 2026. Всі права захищені.</p>
  </footer>
</template>

<script>
import PhoneButton from '@/components/PhoneButton.vue'
import { NAV_ITEMS } from '@/constants/nav'

export default {
  name: 'AppFooter',
  components: { PhoneButton },
  data() {
    return { navItems: NAV_ITEMS }
  },
}
</script>

<style scoped lang="scss">
@use '@/styles/variables' as *;

.footer {
  position: relative;
  height: 561px;
  overflow: hidden;
  background: $navy;
  color: #fff;

  &__bg {
    position: absolute;
    left: -233px;
    top: 0;
    width: 829px;
    height: 573px;
  }

  &__logo {
    position: absolute;
    left: 112px;
    top: 31px;
    width: 161px;
    height: 32px;
  }

  &__nav {
    position: absolute;
    left: 93px;
    top: 93px;
    width: 93px;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 45px;

    a {
      color: #fff;
      font-size: 16px;
      line-height: 19px;
      letter-spacing: -0.64px;
      text-transform: uppercase;
      text-decoration: none;
      &:hover {
        opacity: 0.7;
      }
    }
  }

  &__phone {
    position: absolute;
    left: 69px;
    top: 344px;
    width: 248px;
    height: 56px;
  }

  &__social {
    position: absolute;
    left: 97px;
    top: 430px;
    display: flex;
    gap: 80px;

    a {
      display: block;
      transition: transform 0.2s;
      &:hover {
        transform: translateY(-2px);
      }
    }
  }

  &__copy {
    position: absolute;
    left: 70px;
    top: 524px;
    width: 247px;
    margin: 0;
    font-size: 14px;
    line-height: 17px;
    letter-spacing: -0.56px;
    text-align: center;
    white-space: nowrap;
  }
}
</style>
