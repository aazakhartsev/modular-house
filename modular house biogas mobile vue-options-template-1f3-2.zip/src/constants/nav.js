export const NAV_ITEMS = [
  { label: 'Будинки', hash: '#houses' },
  { label: 'Генерація', hash: '#generation' },
  { label: 'Утилізація', hash: '#disposal' },
  { label: 'Контакти', hash: '#contacts' },
]
