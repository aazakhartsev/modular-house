<template>
  <div class="layout">
    <AppHeader />
    <main>
      <router-view />
    </main>
    <AppFooter />
  </div>
</template>

<script>
import AppHeader from '@/components/AppHeader.vue'
import AppFooter from '@/components/AppFooter.vue'

export default {
  name: 'DefaultLayout',
  components: { AppHeader, AppFooter },
}
</script>

<style scoped lang="scss">
.layout {
  position: relative;
  width: 100%;
  max-width: 390px;
  margin: 0 auto;
  overflow: hidden;
  background: #fff;
}
</style>
