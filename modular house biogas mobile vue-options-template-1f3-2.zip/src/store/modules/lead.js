export default {
  namespaced: true,
  state: () => ({ leads: [], submitting: false, submitted: false }),
  getters: {
    count: (state) => state.leads.length,
  },
  mutations: {
    SET_SUBMITTING(state, value) {
      state.submitting = value
    },
    ADD_LEAD(state, lead) {
      state.leads.push(lead)
      state.submitted = true
    },
    RESET(state) {
      state.submitted = false
    },
  },
  actions: {
    async submit({ commit }, payload) {
      commit('SET_SUBMITTING', true)
      await new Promise((resolve) => setTimeout(resolve, 600))
      commit('ADD_LEAD', { ...payload, createdAt: Date.now() })
      commit('SET_SUBMITTING', false)
    },
  },
}
