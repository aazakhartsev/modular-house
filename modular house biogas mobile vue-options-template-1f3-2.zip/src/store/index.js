import { createStore } from 'vuex'
import lead from './modules/lead'
import ui from './modules/ui'

export default createStore({
  modules: { lead, ui },
})
