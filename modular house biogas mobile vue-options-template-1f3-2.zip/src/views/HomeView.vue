<template>
  <div class="home">
    <svg width="0" height="0" style="position: absolute" aria-hidden="true">
      <defs>
        <linearGradient id="navyGrad" x1="0" y1="0" x2="0" y2="1">
          <stop stop-color="#273947" />
          <stop offset="1" stop-color="#476587" />
        </linearGradient>
      </defs>
    </svg>

    <section class="hero">
      <img
        class="hero__bg"
        src="https://api.builder.io/api/v1/image/assets/TEMP/40cce29dde2073c7f91261c5d8c2419eb3cc149b?width=1672"
        alt=""
      />
      <div class="hero__shade"></div>
      <h1 class="hero__title">Енергія<br />з біовідходів</h1>
      <p class="hero__text">
        Відходи вашої родини — це не сміття. Це паливо. Щодня установка переробляє залишки їжі та
        органіку на газ для плити, гарячу воду та добриво для саду. Замкнений цикл — без відходів і
        без зайвих рахунків.
      </p>
      <ArrowButton class="hero__consult" label="Отримати консультацію" theme="light" href="#contacts" />
      <PhoneButton class="hero__phone" />
    </section>

    <section id="houses" class="houses">
      <img
        class="houses__img"
        src="https://api.builder.io/api/v1/image/assets/TEMP/e7cba98729cf22d80ad75a39e0daf9b1afdcca13?width=722"
        alt="Будинок який зростає"
        width="361"
        height="125"
      />
    </section>

    <section id="generation" class="generation">
      <img
        class="generation__bg"
        src="https://api.builder.io/api/v1/image/assets/TEMP/0eac2ce6ff8a318020a4b78ce3d150119bf42825?width=1128"
        alt=""
      />
      <div v-for="(step, i) in steps" :key="step.title" class="chip" :class="'chip--s' + (i + 1)">
        <strong>{{ step.title }}</strong>
        <span>{{ step.caption }}</span>
      </div>
      <svg
        v-for="i in 3"
        :key="'arrow-' + i"
        class="generation__arrow"
        :class="'generation__arrow--a' + i"
        width="14"
        height="13"
        viewBox="0 0 14 13"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path d="M0 3.91073L2.34644 3.91073V1.02566e-07L9.38575 6.25717L2.34644 12.5143V8.6036L0 8.6036V3.91073ZM1.56429 5.47502V7.03931L3.91073 7.03931V9.03379L7.03931 6.25717L3.91073 3.48055V5.47502L1.56429 5.47502ZM6.25717 2.73509e-07L13.2965 6.25717L6.25717 12.5143V10.4221L10.95 6.25717L6.25717 2.09224V2.73509e-07Z" fill="white" />
      </svg>
      <div v-for="stat in stats" :key="stat.caption" class="chip chip--stat" :class="'chip--' + stat.pos">
        <strong>{{ stat.value }}</strong>
        <span>{{ stat.caption }}</span>
      </div>

      <div class="card card--input">
        <div class="card__title">Що йде на вхід</div>
        <div v-for="item in inputs" :key="item" class="card__line">{{ item }}</div>
      </div>
      <div class="card card--output">
        <div class="card__title">Що отримуєте</div>
        <div v-for="item in outputs" :key="item" class="card__line">{{ item }}</div>
      </div>
    </section>

    <section id="disposal" class="features">
      <img
        class="features__bg"
        src="https://api.builder.io/api/v1/image/assets/TEMP/f72fbe96521a4b8b859f0ca8cd276a70930a503e?width=2330"
        alt=""
      />
      <article v-for="(f, i) in features" :key="f.title" class="feature" :class="'feature--' + (i + 1)">
        <h3 class="feature__title">✓ {{ f.title }}</h3>
        <p class="feature__text">{{ f.text }}</p>
      </article>
      <p class="features__summary">
        Домашня біогазова система - це персональний завод безвідходного циклу на вашій ділянці, що
        перетворює побутове сміття та органіку на безкоштовний газ для готування й опалення.
      </p>
    </section>

    <section class="lead">
      <form v-if="!submitted" class="lead__form" novalidate @submit.prevent="onSubmit">
        <v-text-field
          v-model="form.name"
          class="field field--name"
          placeholder="Імʼя"
          variant="flat"
          hide-details="auto"
          autocomplete="name"
          :error-messages="errors.name"
        />
        <v-text-field
          v-model="form.phone"
          class="field field--phone"
          placeholder="+380 (__) ___-__-__"
          type="tel"
          variant="flat"
          hide-details="auto"
          autocomplete="tel"
          :error-messages="errors.phone"
        />
        <ArrowButton class="lead__submit" type="submit" label="Розрахувати вартість" theme="dark" :loading="submitting" />
      </form>
      <div v-else class="lead__done">
        <p>Дякуємо! Ми зв'яжемося з вами найближчим часом.</p>
        <button type="button" class="lead__again" @click="reset">Надіслати ще раз</button>
      </div>
    </section>

    <section id="contacts" class="contacts">
      <span class="contacts__line contacts__line--left"></span>
      <h2 class="gradient-title contacts__title">Контакти</h2>
      <span class="contacts__line contacts__line--right"></span>

      <div class="contacts__item contacts__item--phone">
        <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M23.664 29.136C24.0771 29.3257 24.5424 29.369 24.9834 29.2589C25.4244 29.1487 25.8147 28.8916 26.09 28.53L26.8 27.6C27.1726 27.1032 27.6557 26.7 28.2111 26.4223C28.7666 26.1446 29.379 26 30 26H36C37.0609 26 38.0783 26.4214 38.8284 27.1716C39.5786 27.9217 40 28.9391 40 30V36C40 37.0609 39.5786 38.0783 38.8284 38.8284C38.0783 39.5786 37.0609 40 36 40C26.4522 40 17.2955 36.2072 10.5442 29.4558C3.79285 22.7045 0 13.5478 0 4C0 2.93913 0.421427 1.92172 1.17157 1.17157C1.92172 0.421427 2.93913 0 4 0H10C11.0609 0 12.0783 0.421427 12.8284 1.17157C13.5786 1.92172 14 2.93913 14 4V10C14 10.621 13.8554 11.2334 13.5777 11.7889C13.3 12.3443 12.8968 12.8274 12.4 13.2L11.464 13.902C11.0968 14.1824 10.838 14.5812 10.7316 15.0307C10.6251 15.4802 10.6776 15.9528 10.88 16.368C13.6134 21.9197 18.1088 26.4096 23.664 29.136Z" stroke="url(#navyGrad)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" />
        </svg>
        <a href="tel:+380445022888">+38 (044) 502 2888</a>
      </div>
      <div class="contacts__item contacts__item--mail">
        <svg width="40" height="35" viewBox="0 0 40 35" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M40 6.5625L22.018 19.0903C21.4078 19.478 20.7147 19.6822 20.009 19.6822C19.3033 19.6822 18.6102 19.478 18 19.0903L0 6.5625M4 0H36C38.2091 0 40 1.95875 40 4.375V30.625C40 33.0412 38.2091 35 36 35H4C1.79086 35 0 33.0412 0 30.625V4.375C0 1.95875 1.79086 0 4 0Z" stroke="url(#navyGrad)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" />
        </svg>
        <a href="mailto:info@servionica.com">info@servionica.com</a>
      </div>
      <div class="contacts__item contacts__item--address">
        <svg width="34" height="42" viewBox="0 0 34 42" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M34 16.8002C34 27.2856 22.2296 38.2058 18.2771 41.5784C17.9089 41.852 17.4607 42 17 42C16.5393 42 16.0911 41.852 15.7229 41.5784C11.7704 38.2058 0 27.2856 0 16.8002C0 12.3445 1.79107 8.07132 4.97918 4.92067C8.1673 1.77002 12.4913 0 17 0C21.5087 0 25.8327 1.77002 29.0208 4.92067C32.2089 8.07132 34 12.3445 34 16.8002Z" stroke="url(#navyGrad)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" />
          <path d="M17 23.1003C20.5208 23.1003 23.375 20.2796 23.375 16.8002C23.375 13.3208 20.5208 10.5001 17 10.5001C13.4792 10.5001 10.625 13.3208 10.625 16.8002C10.625 20.2796 13.4792 23.1003 17 23.1003Z" stroke="url(#navyGrad)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" />
        </svg>
        <span>вул. Ігоря Сікорського 1, м. Київ, 04112</span>
      </div>
      <div class="contacts__item contacts__item--web">
        <svg width="42" height="42" viewBox="0 0 42 42" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M42 21C42 32.598 32.598 42 21 42M42 21C42 9.40202 32.598 0 21 0M42 21H0M21 42C9.40202 42 0 32.598 0 21M21 42C15.6077 36.3381 12.6 28.8188 12.6 21C12.6 13.1812 15.6077 5.66192 21 0M21 42C26.3923 36.3381 29.4 28.8188 29.4 21C29.4 13.1812 26.3923 5.66192 21 0M0 21C0 9.40202 9.40202 0 21 0" stroke="url(#navyGrad)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" />
        </svg>
        <a href="https://www.servionica.com" target="_blank" rel="noopener">www.servionica.com</a>
      </div>
    </section>
  </div>
</template>

<script>
import { mapActions, mapState } from 'vuex'
import ArrowButton from '@/components/ArrowButton.vue'
import PhoneButton from '@/components/PhoneButton.vue'

export default {
  name: 'HomeView',
  components: { ArrowButton, PhoneButton },
  data() {
    return {
      form: { name: '', phone: '' },
      errors: { name: [], phone: [] },
      steps: [
        { title: 'Відходи', caption: 'Їжа, органіка' },
        { title: 'Реактор', caption: 'Анаеробний процес' },
        { title: 'Біогаз', caption: 'Метан для дому' },
        { title: 'Енергія', caption: 'вода, плита, світло' },
      ],
      stats: [
        { value: '2 м3', caption: 'газу на добу (макс)', pos: 'stat-1' },
        { value: '25 кг', caption: 'відходів на добу', pos: 'stat-2' },
        { value: '10+', caption: 'років служби', pos: 'stat-3' },
        { value: 'ISO', caption: '12100 сертифікат', pos: 'stat-4' },
      ],
      inputs: [
        'Харчові відходи — до 25 кг/добу',
        'Людські фекалії — до 32 кг/добу',
        'Свинячий гній — до 45 кг/добу',
        'Курячий послід - до 26 кг/добу',
        'Овочеві залишки - до 65 кг/добу',
      ],
      outputs: [
        'До 2 м біогазу — варіння й обігрів',
        'Гаряча вода без електрики',
        'Генерація електроенергії (з генератором)',
        'Органічне добриво — digestate для городу',
        'Нуль смердючого сміття у відрі',
      ],
      features: [
        {
          title: 'Довговічність та надійність:',
          text: 'Високоякісна мембрана стійка до ультрафіолету, кислот, путів та гризунів. Каркас та вузли з нержавіючої сталі забезпечують понад 10 років експлуатації.',
        },
        {
          title: 'Конструкція «Sun Room»:',
          text: 'Спеціальний захисний купол зі стільникового полікарбонату працює як теплиця, акумулюючи сонячне тепло для максимальної та стабільної генерації гаду.',
        },
        {
          title: 'Повна утилізація відходів:',
          text: 'Надійно та без зaпaху переробляє залишки їжі, садові та будь-які інші органічні відходи.',
        },
        {
          title: 'Розумне та безпечне DIY-рішення:',
          text: 'Конструкція встановлюється на поверхні грунту всього за пару годин без капітального будівництва та земляних робіт. Вбудована система фільтрації гарантує чистий газ без неприємних зaпaxiв.',
        },
      ],
    }
  },
  computed: {
    ...mapState('lead', ['submitting', 'submitted']),
  },
  methods: {
    ...mapActions('lead', ['submit']),
    validate() {
      const digits = this.form.phone.replace(/\D/g, '')
      this.errors = {
        name: this.form.name.trim() ? [] : ['Вкажіть імʼя'],
        phone: digits.length >= 10 ? [] : ['Вкажіть коректний телефон'],
      }
      return !this.errors.name.length && !this.errors.phone.length
    },
    async onSubmit() {
      if (!this.validate()) return
      await this.submit({ ...this.form })
      this.form = { name: '', phone: '' }
    },
    reset() {
      this.$store.commit('lead/RESET')
    },
  },
}
</script>

<style scoped lang="scss">
@use '@/styles/variables' as *;

/* Hero: 0–824 */
.hero {
  position: relative;
  height: 824px;
  overflow: hidden;
  background: $navy;
  color: #fff;

  &__bg {
    position: absolute;
    left: -363px;
    top: -14px;
    width: 836px;
    height: 838px;
  }

  &__shade {
    position: absolute;
    left: -37px;
    top: 181px;
    width: 412px;
    height: 177px;
    border-radius: 50%;
    background: #000;
    filter: blur(80px);
  }

  &__title {
    position: absolute;
    left: 32px;
    top: 122px;
    width: 289px;
    margin: 0;
    font-size: 40px;
    font-weight: 600;
    line-height: 0.9;
    letter-spacing: -2px;
    text-transform: uppercase;
  }

  &__text {
    position: absolute;
    left: 32px;
    top: 214px;
    width: 323px;
    margin: 0;
    font-size: 16px;
    line-height: 1.2;
    letter-spacing: -0.48px;
  }

  &__consult {
    position: absolute;
    left: 65px;
    top: 670px;
  }

  &__phone {
    position: absolute;
    left: 65px;
    top: 733px;
  }
}

/* Houses heading image: 824–1024 */
.houses {
  position: relative;
  height: 200px;

  &__img {
    position: absolute;
    left: 15px;
    top: 50px;
    width: 361px;
    height: 125px;
  }
}

/* Process and input/output cards: 1024–1951 */
.generation {
  position: relative;
  height: 927px;
  overflow: hidden;

  &__bg {
    position: absolute;
    left: -91px;
    top: 0;
    width: 564px;
    height: 358px;
    border-radius: 80px;
  }

  &__arrow {
    position: absolute;
    top: 27px;
  }
  &__arrow--a1 {
    left: 90px;
  }
  &__arrow--a2 {
    left: 188px;
  }
  &__arrow--a3 {
    left: 286px;
  }
}

.chip {
  position: absolute;
  display: flex;
  flex-direction: column;
  align-items: center;
  background: $glass;
  color: #fff;
  text-align: center;
  line-height: 0.9;

  strong {
    display: block;
    font-size: 16px;
    font-weight: 600;
    letter-spacing: -0.48px;
  }

  span {
    display: block;
    font-size: 10px;
    letter-spacing: -0.3px;
  }

  &--s1,
  &--s2,
  &--s3,
  &--s4 {
    top: 16px;
    width: 74px;
    height: 47px;
    padding-top: 5px;
    border-radius: 8px;
  }
  &--s1 {
    left: 11px;
  }
  &--s2 {
    left: 109px;
  }
  &--s3 {
    left: 206px;
  }
  &--s4 {
    left: 304px;
  }

  &--stat-1,
  &--stat-2,
  &--stat-3,
  &--stat-4 {
    width: 96px;
    height: 46px;
    padding-top: 5px;
    border-radius: 10px;
  }
  &--stat-1 {
    left: 20px;
    top: 233px;
  }
  &--stat-2 {
    left: 20px;
    top: 299px;
  }
  &--stat-3 {
    left: 282px;
    top: 233px;
  }
  &--stat-4 {
    left: 282px;
    top: 300px;
  }
}

.card {
  position: absolute;
  color: #000;
  letter-spacing: -0.48px;

  &__title {
    font-size: 16px;
    font-weight: 600;
    line-height: 16px;
  }

  &__line {
    font-size: 16px;
    line-height: 16px;
  }

  &--input {
    left: 21px;
    top: 383px;
    width: 349px;
    height: 230px;
    box-sizing: border-box;
    padding: 19px 35px;
    border-radius: 44px;
    background: #e5e5e5;

    .card__title {
      margin-bottom: 14px;
    }
    .card__line {
      margin-bottom: 6px;
    }
  }

  &--output {
    left: 20px;
    top: 638px;
    width: 349px;
    height: 245px;
    box-sizing: border-box;
    padding: 10px 36px;
    border-radius: 44px;
    background: #bed9e6;

    .card__title {
      margin-bottom: 21px;
    }
    .card__line {
      margin-bottom: 21px;
    }
  }
}

/* Features: 1951–2761 */
.features {
  position: relative;
  height: 810px;
  overflow: hidden;
  background: $navy;
  color: #fff;

  &__bg {
    position: absolute;
    left: -436px;
    top: 0;
    width: 1165px;
    height: 810px;
  }

  &__summary {
    position: absolute;
    left: 14px;
    top: 722px;
    width: 361px;
    margin: 0;
    font-size: 16px;
    line-height: 0.9;
    letter-spacing: -0.48px;
    text-align: center;
  }
}

.feature {
  position: absolute;
  left: 32px;
  width: 338px;
  box-sizing: border-box;
  padding: 12px 15px;
  border-radius: 17.459px;
  background: $glass;
  line-height: 1.4;
  letter-spacing: -0.48px;

  &__title {
    margin: 0;
    font-size: 16px;
    font-weight: 600;
    line-height: 1.4;
    text-transform: uppercase;
  }

  &__text {
    margin: 0;
    font-size: 16px;
    line-height: 1.4;
  }

  &--1 {
    top: 20px;
    height: 156px;
  }
  &--2 {
    top: 196px;
    height: 137px;
  }
  &--3 {
    top: 353px;
    height: 116px;
    border-radius: 18.27px;
  }
  &--4 {
    top: 489px;
    height: 206px;
    border-radius: 18.27px;
  }
}

/* Lead form: 2761–3000 */
.lead {
  position: relative;
  height: 239px;

  &__form {
    position: absolute;
    inset: 0;
  }

  &__submit {
    position: absolute;
    left: 63px;
    top: 178px;
  }

  &__done {
    position: absolute;
    left: 35px;
    top: 50px;
    width: 320px;
    text-align: center;
    letter-spacing: -0.48px;

    p {
      margin: 0 0 12px;
    }
  }

  &__again {
    padding: 0;
    border: 0;
    background: none;
    color: $navy;
    font-family: $font;
    font-size: 14px;
    text-decoration: underline;
    cursor: pointer;
  }
}

.field {
  position: absolute;
  left: 63px;
  width: 260px;

  &--name {
    top: 50px;
  }
  &--phone {
    top: 114px;
  }

  :deep(.v-field) {
    height: 53px;
    border-radius: 305px 297px 305px 305px;
    background: #d9d9d9;
    font-family: $font;
  }

  :deep(.v-field__input) {
    min-height: 53px;
    padding: 0 16px;
    color: #000;
    font-size: 16px;
    letter-spacing: -0.48px;
    align-items: center;

    &::placeholder {
      color: #706f6f;
      opacity: 1;
    }
  }

  &--phone :deep(.v-field__input) {
    letter-spacing: 1.44px;
  }

  :deep(.v-field__outline) {
    display: none;
  }

  :deep(.v-messages) {
    padding-left: 16px;
  }
}

/* Contacts: 3000–3371 */
.contacts {
  position: relative;
  height: 371px;

  &__title {
    position: absolute;
    left: 134px;
    top: 42px;
    width: 116px;
    height: 23px;
    line-height: 0.9;
  }

  &__line {
    position: absolute;
    top: 55px;
    width: 107px;
    height: 1px;
    background: $grad;

    &--left {
      left: -2px;
    }
    &--right {
      left: 280px;
    }
  }

  &__item {
    position: absolute;
    left: 22px;
    display: flex;
    align-items: center;
    gap: 21px;
    color: #000;
    font-size: 20px;
    letter-spacing: -0.6px;

    a,
      span {
      color: #000;
      text-decoration: none;
      white-space: nowrap;
    }

    svg {
      flex: none;
    }

    &--phone {
      top: 90px;
    }
    &--mail {
      top: 150px;
    }
    &--address {
      top: 208px;
      left: 25px;
    }
    &--web {
      top: 273px;
      left: 23px;
    }
  }
}
</style>
