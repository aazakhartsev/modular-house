<template>
  <section class="placeholder">
    <div class="placeholder__box">
      <h1 class="placeholder__title">Сторінка в розробці</h1>
      <p>Продовжуйте підказувати Fusion, щоб наповнити цю сторінку вмістом.</p>
      <ArrowButton label="На головну" theme="light" href="/" />
    </div>
  </section>
</template>

<script>
import ArrowButton from '@/components/ArrowButton.vue'

export default {
  name: 'PlaceholderView',
  components: { ArrowButton },
}
</script>

<style scoped lang="scss">
@use '@/styles/variables' as *;

.placeholder {
  display: grid;
  place-items: center;
  min-height: 70vh;
  padding: 140px 20px 60px;
  background: $navy;
  color: #fff;
  text-align: center;

  &__box {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 24px;
    max-width: 440px;
  }

  &__title {
    margin: 0;
    font-size: 32px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: -1px;
  }

  p {
    margin: 0;
    letter-spacing: -0.48px;
  }
}
</style>
