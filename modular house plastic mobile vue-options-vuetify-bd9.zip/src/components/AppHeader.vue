<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'AppHeader',
  data() {
    return {
      open: false,
      links: [
        { label: 'Будинки', to: '/houses' },
        { label: 'Генерація', to: '/generation' },
        { label: 'Утилізація', to: '/disposal' },
        { label: 'Контакти', to: '/#contacts' },
      ],
    }
  },
  watch: {
    $route() {
      this.open = false
    },
  },
})
</script>

<template>
  <header class="absolute inset-x-0 top-0 z-30 text-white">
    <div class="mx-auto flex max-w-[1200px] items-center justify-between px-8 pt-[57px] md:px-10">
      <router-link to="/" aria-label="Servionica">
        <img
          src="https://api.builder.io/api/v1/image/assets/TEMP/9dfa48e0523854ea0e196dde2758e80c410f7aee?width=248"
          alt="Servionica"
          class="h-[25px] w-[124px]"
        />
      </router-link>
      <nav class="hidden items-center gap-10 text-[16px] uppercase tracking-[-0.64px] md:flex">
        <router-link v-for="l in links" :key="l.to" :to="l.to" class="hover:opacity-80">
          {{ l.label }}
        </router-link>
      </nav>
      <button
        class="md:hidden"
        aria-label="Меню"
        :aria-expanded="open"
        @click="open = !open"
      >
        <svg width="28" height="25" viewBox="0 0 28 25" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M0 12.462H28M0 24.9239H28M0 0H28" stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
        </svg>
      </button>
    </div>
    <nav
      v-if="open"
      class="mx-6 mt-4 flex flex-col items-center gap-5 rounded-3xl bg-brand-dark/95 py-6 text-[16px] uppercase tracking-[-0.64px] md:hidden"
    >
      <router-link v-for="l in links" :key="l.to" :to="l.to">{{ l.label }}</router-link>
    </nav>
  </header>
</template>
