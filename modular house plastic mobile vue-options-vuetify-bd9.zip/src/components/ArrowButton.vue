<script lang="ts">
import { defineComponent, type PropType } from 'vue'

export default defineComponent({
  name: 'ArrowButton',
  props: {
    variant: { type: String, default: 'light' },
    type: { type: String as PropType<'button' | 'submit'>, default: 'button' },
  },
  computed: {
    isLight(): boolean {
      return this.variant === 'light'
    },
  },
})
</script>

<template>
  <button
    :type="type"
    class="inline-flex h-[53px] w-[260px] items-center justify-between rounded-full pl-[29px] pr-[8px] text-[16px] tracking-[-0.48px] transition-opacity hover:opacity-90"
    :class="isLight ? 'bg-white pl-[22px] text-black' : 'bg-brand-dark text-white'"
  >
    <span><slot /></span>
    <span
      class="flex h-[38px] w-[38px] items-center justify-center rounded-full"
      :class="isLight ? 'bg-brand-dark' : 'bg-white'"
    >
      <svg width="7" height="7" viewBox="0 0 7 7" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path
          d="M0 0H6.10329V6.10329M6.10329 0L0 6.10329"
          :stroke="isLight ? '#fff' : '#273947'"
          stroke-width="0.915493"
        />
      </svg>
    </span>
  </button>
</template>
