import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import PlaceholderView from '../views/PlaceholderView.vue'

export default createRouter({
  history: createWebHistory(),
  scrollBehavior: (to) => (to.hash ? { el: to.hash, behavior: 'smooth' } : { top: 0 }),
  routes: [
    { path: '/', name: 'home', component: HomeView },
    { path: '/houses', component: PlaceholderView, meta: { title: 'Будинки' } },
    { path: '/generation', component: PlaceholderView, meta: { title: 'Генерація' } },
    { path: '/disposal', component: PlaceholderView, meta: { title: 'Утилізація' } },
    { path: '/:pathMatch(.*)*', component: PlaceholderView, meta: { title: 'Сторінку не знайдено' } },
  ],
})
