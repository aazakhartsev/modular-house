<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'PlaceholderView',
  computed: {
    title(): string {
      return (this.$route.meta.title as string) || 'Сторінка'
    },
  },
})
</script>

<template>
  <section class="flex min-h-[70vh] flex-col items-center justify-center bg-brand-dark px-8 pb-20 pt-40 text-center text-white">
    <h1 class="text-[32px] font-semibold uppercase leading-[0.95] tracking-[-1.5px] md:text-[48px]">{{ title }}</h1>
    <p class="mt-6 max-w-[420px] text-[16px] tracking-[-0.48px] opacity-80">
      Цей розділ ще порожній. Продовжте діалог, щоб наповнити цю сторінку контентом.
    </p>
    <router-link to="/" class="mt-8 rounded-full bg-white px-8 py-4 text-[16px] tracking-[-0.48px] text-black">
      На головну
    </router-link>
  </section>
</template>
