<script lang="ts">
import { defineComponent } from 'vue'
import ArrowButton from '../components/ArrowButton.vue'
import PhonePill from '../components/PhonePill.vue'

export default defineComponent({
  name: 'HomeView',
  components: { ArrowButton, PhonePill },
  data() {
    return {
      name: '',
      phone: '',
      sent: false,
      accepts: [
        'ПЕТ-пляшки (вода, напої)',
        'HDPE-каністри та ємності',
        'Пластикові пакети та плівка',
        'Пінопласт і пінополістирол',
        'Жорстке пакування (контейнери)',
      ],
      benefits: [
        "Зменшує об'єм сміття до 10 разів",
        'Немає запаху — закрита камера',
        'Флекс здають переробникам за гроші',
        'Вбудовано в техзону — не займає місця',
        'Мінімальне обслуговування',
      ],
      steps: [
        {
          title: 'Завантаження\nпластику в бункер',
          img: 'https://api.builder.io/api/v1/image/assets/TEMP/d2a06baddf6bfc278d2046186df10a70a9c0663b?width=376',
        },
        {
          title: 'Різання\nподрібненим валом',
          img: 'https://api.builder.io/api/v1/image/assets/TEMP/cb5b0701df1f9ba113c31b86c63c927bb5daa935?width=376',
        },
        {
          title: 'На виході\nфлекс гранулят',
          img: 'https://api.builder.io/api/v1/image/assets/TEMP/b5845612034c1d8799b20aee6485650183751a0b?width=494',
        },
      ],
      chips: [
        { big: '1', small: 'робочий вал (ротор)', bold: true },
        { big: '3-фаз', small: 'індукційний двигун', bold: true },
        { big: 'CE', small: 'сертифікація EU', bold: false },
        { big: '24/7', small: 'безперервна робота', bold: false },
      ],
      contacts: [
        { text: '+38 (044) 502 2888', href: 'tel:+380445022888', icon: 'phone' },
        { text: 'info@servionica.com', href: 'mailto:info@servionica.com', icon: 'mail' },
        { text: 'вул. Ігоря Сікорського 1, м. Київ, 04112', href: '', icon: 'pin' },
        { text: 'www.servionica.com', href: 'https://www.servionica.com', icon: 'globe' },
      ],
    }
  },
  methods: {
    submit() {
      this.sent = true
      this.name = ''
      this.phone = ''
    },
    scrollTo(id: string) {
      document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' })
    },
  },
})
</script>

<template>
  <div>
    <!-- Hero -->
    <section class="relative h-[838px] overflow-hidden bg-black text-white md:h-[900px]">
      <img
        src="https://api.builder.io/api/v1/image/assets/TEMP/5d69344eeddeffa842391adc40b102dd699f739b?width=1672"
        alt=""
        class="absolute left-[calc(50%-558px)] top-0 h-[838px] w-[836px] max-w-none md:inset-0 md:left-0 md:h-full md:w-full md:object-cover"
      />
      <img
        src="https://api.builder.io/api/v1/image/assets/TEMP/12ab8f091a6a37fd64b844776d64b34cc953d10c?width=2054"
        alt=""
        class="absolute left-[calc(50%-352px)] top-0 h-[838px] w-[1027px] max-w-none md:left-1/2 md:ml-[-420px] md:h-full md:w-auto md:object-cover"
      />
      <div class="pointer-events-none absolute left-[calc(50%-232px)] top-[211px] h-[159px] w-[412px] rounded-full bg-black blur-[80px] md:hidden"></div>

      <div class="relative mx-auto flex h-full max-w-[1200px] flex-col px-8 pt-[122px] md:px-10 md:pt-[200px]">
        <h1 class="max-w-[323px] text-[40px] font-semibold uppercase leading-[0.9] tracking-[-2px] md:max-w-[640px] md:text-[64px] md:tracking-[-3px]">
          ПЕРЕРОБЛЕННЯ ПЛАСТИКУ <br class="md:hidden" />У ВАШОМУ ДОМІ
        </h1>
        <p class="mt-5 max-w-[314px] text-[16px] tracking-[-0.48px] md:mt-8 md:max-w-[460px] md:text-[18px]">
          Інтегрований шредер для модульних будинків Servionica. Перетворюйте побутовий пластик на корисну сировину прямо в технічному приміщенні.
        </p>
        <div class="mt-auto flex flex-col items-center gap-[10px] pb-[38px] md:mt-12 md:items-start md:pb-0">
          <ArrowButton @click="scrollTo('contacts')">Отримати консультацію</ArrowButton>
          <PhonePill />
        </div>
      </div>
    </section>

    <!-- Info cards -->
    <section class="mx-auto max-w-[1100px] px-5 pt-[30px]">
      <img
        src="https://api.builder.io/api/v1/image/assets/TEMP/32d0d3a6252edd5b0f096beb499d61d940faa353?width=740"
        alt="Будинок який зростає"
        class="mx-auto h-auto w-full max-w-[370px]"
      />
      <div class="mx-auto mt-[33px] max-w-[320px] text-center">
        <h2 class="bg-brand-gradient bg-clip-text text-[26px] font-semibold leading-[0.9] tracking-[-0.78px] text-transparent">
          Ефективне перероблення пластику
        </h2>
        <p class="mt-5 text-[16px] leading-[1.2] tracking-[-0.48px]">
          Ваш ключ до власного заводу відходів. Забудьте про сміттєві баки та накопичення пластику
        </p>
      </div>
      <div class="mt-[33px] grid gap-[21px] md:grid-cols-2">
        <article class="relative min-h-[229px] rounded-[34px] border border-[#AAA] p-5">
          <ul class="relative z-10 max-w-[264px] text-[16px] uppercase leading-[200%] tracking-[-0.48px]">
            <li class="font-semibold">Що переробляє?</li>
            <li v-for="a in accepts" :key="a">{{ a }}</li>
          </ul>
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/17859bac660827b872612dbcd55c00cc2b17cc09?width=234"
            alt=""
            class="absolute bottom-[37px] right-5 h-[162px] w-[117px] sm:right-8"
          />
        </article>
        <article class="relative min-h-[275px] rounded-[34px] border border-[#AAA] p-[21px] pt-[15px]">
          <div class="absolute right-0 top-[64px] h-[130px] w-[130px] rounded-full bg-[#9DD77C] blur-[37px]"></div>
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/2f5932136744d722b07076d648b8cf4e2dcf4fcc?width=276"
            alt=""
            class="absolute right-[4px] top-[68px] h-[113px] w-[138px]"
          />
          <div class="relative max-w-[213px] text-[16px] uppercase leading-none tracking-[-0.48px]">
            <p class="font-semibold">Переваги в будинку</p>
            <p v-for="b in benefits" :key="b" class="mt-[16px]">{{ b }}</p>
          </div>
        </article>
      </div>
    </section>

    <!-- How it works -->
    <section class="mx-auto max-w-[1100px] px-5 pt-[36px]">
      <div class="mx-auto max-w-[320px] text-center">
        <h2 class="bg-brand-gradient bg-clip-text text-[26px] font-semibold leading-[0.9] tracking-[-0.78px] text-transparent">
          Як це працює?
        </h2>
        <p class="mt-5 text-[16px] leading-[0.9] tracking-[-0.48px]">
          Забудьте про сміттєві баки та накопичення пластику. Зменшує об'єм пластикового сміття до 10 разів.
        </p>
      </div>
      <div class="mt-[32px] flex flex-col items-center gap-[10px] md:flex-row md:items-start md:justify-center md:gap-6">
        <template v-for="(s, i) in steps" :key="s.title">
          <div class="flex w-[247px] flex-col items-center gap-[10px] text-center">
            <img :src="s.img" alt="" class="h-[200px] w-auto max-w-full object-contain" />
            <p class="whitespace-pre-line text-[18px] font-semibold leading-[0.9] tracking-[-0.54px]">{{ s.title }}</p>
          </div>
          <svg
            v-if="i < steps.length - 1"
            class="h-[37px] w-[35px] shrink-0 md:-rotate-90 md:self-center"
            width="35" height="37" viewBox="0 0 35 37" fill="none" xmlns="http://www.w3.org/2000/svg"
          >
            <path d="M23.5441 1.02915e-06L23.5441 6.42113L34.246 6.42113L17.123 25.6845L1.30982e-06 6.42113L10.7019 6.42113L10.7019 4.67794e-07L23.5441 1.02915e-06ZM19.2634 4.28075L14.9826 4.28075L14.9826 10.7019L9.52467 10.7019L17.123 19.2634L24.7213 10.7019L19.2634 10.7019L19.2634 4.28075ZM34.246 17.123L17.123 36.3864L8.42029e-07 17.123L5.7255 17.123L17.123 29.9653L28.5205 17.123L34.246 17.123Z" fill="#273947" />
          </svg>
        </template>
      </div>
    </section>

    <!-- Specs on grass -->
    <section class="relative mt-[31px] overflow-hidden bg-black text-white">
      <img
        src="https://api.builder.io/api/v1/image/assets/TEMP/bc56ba11893a0a8aaec2a622215ed7a34d139241?width=902"
        alt=""
        class="absolute inset-0 h-full w-full object-cover object-center"
      />
      <div class="relative mx-auto flex min-h-[420px] max-w-[1100px] flex-col justify-between px-[11px] pb-[24px] pt-[14px] md:min-h-[520px] md:px-5">
        <div class="mx-auto grid w-full max-w-[383px] grid-cols-4 gap-4 md:max-w-[480px]">
          <div
            v-for="c in chips"
            :key="c.small"
            class="flex h-[56px] flex-col items-center justify-center rounded-[9px] bg-white/10 px-1 text-center"
          >
            <span class="text-[16px] leading-[0.9] tracking-[-0.48px]" :class="c.bold ? 'font-semibold' : ''">{{ c.big }}</span>
            <span class="mt-[5px] text-[10px] leading-[0.9] tracking-[-0.3px]">{{ c.small }}</span>
          </div>
        </div>
        <p class="mx-auto mt-[260px] max-w-[350px] px-[9px] text-[16px] leading-[1.2] tracking-[-0.8px] md:mt-[360px] md:max-w-[560px] md:text-center">
          Ваш побутовий пластик більше не потребує сміттєвого баку. Шредер подрібнює пляшки, пакування та плівку в гранулят, придатний для повторного використання або здачі на переробку.
        </p>
      </div>
    </section>

    <!-- Form -->
    <section class="flex flex-col items-center px-5 pt-[40px]">
      <form class="flex w-[260px] flex-col gap-[11px]" @submit.prevent="submit">
        <input
          v-model="name"
          type="text"
          required
          placeholder="Імʼя"
          class="h-[53px] w-full rounded-[305px_297px_305px_305px] bg-field px-4 text-[16px] tracking-[-0.48px] text-black outline-none placeholder:text-field-text"
        />
        <input
          v-model="phone"
          type="tel"
          required
          placeholder="+380 (__) ___-__-__"
          class="h-[53px] w-full rounded-[305px_297px_305px_305px] bg-field px-4 text-[16px] tracking-[1.44px] text-black outline-none placeholder:text-field-text"
        />
        <ArrowButton type="submit" variant="dark">Розрахувати вартість</ArrowButton>
        <p v-if="sent" class="text-center text-[14px] text-brand-dark">Дякуємо! Ми зв'яжемося з вами найближчим часом.</p>
      </form>
    </section>

    <!-- Contacts -->
    <section id="contacts" class="scroll-mt-6 pb-[50px] pt-[50px]">
      <div class="flex items-center gap-4 overflow-hidden">
        <span class="h-[2px] flex-1 bg-brand-dark"></span>
        <h2 class="bg-brand-gradient bg-clip-text text-[26px] font-semibold leading-[0.9] tracking-[-0.78px] text-transparent">Контакти</h2>
        <span class="h-[2px] flex-1 bg-brand-dark"></span>
      </div>
      <ul class="mx-auto mt-[28px] flex w-fit max-w-full flex-col gap-[22px] px-[22px]">
        <li v-for="c in contacts" :key="c.text" class="flex items-center gap-[20px] text-[20px] tracking-[-0.6px]">
          <span class="flex w-[42px] shrink-0 justify-center">
            <svg v-if="c.icon === 'phone'" width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M23.664 29.136C24.0771 29.3257 24.5424 29.369 24.9834 29.2589C25.4244 29.1487 25.8147 28.8916 26.09 28.53L26.8 27.6C27.1726 27.1032 27.6557 26.7 28.2111 26.4223C28.7666 26.1446 29.379 26 30 26H36C37.0609 26 38.0783 26.4214 38.8284 27.1716C39.5786 27.9217 40 28.9391 40 30V36C40 37.0609 39.5786 38.0783 38.8284 38.8284C38.0783 39.5786 37.0609 40 36 40C26.4522 40 17.2955 36.2072 10.5442 29.4558C3.79285 22.7045 0 13.5478 0 4C0 2.93913 0.421427 1.92172 1.17157 1.17157C1.92172 0.421427 2.93913 0 4 0H10C11.0609 0 12.0783 0.421427 12.8284 1.17157C13.5786 1.92172 14 2.93913 14 4V10C14 10.621 13.8554 11.2334 13.5777 11.7889C13.3 12.3443 12.8968 12.8274 12.4 13.2L11.464 13.902C11.0968 14.1824 10.838 14.5812 10.7316 15.0307C10.6251 15.4802 10.6776 15.9528 10.88 16.368C13.6134 21.9197 18.1088 26.4096 23.664 29.136Z" stroke="url(#c-phone)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" />
              <defs><linearGradient id="c-phone" x1="20" y1="0" x2="20" y2="40" gradientUnits="userSpaceOnUse"><stop stop-color="#273947" /><stop offset="1" stop-color="#476587" /></linearGradient></defs>
            </svg>
            <svg v-else-if="c.icon === 'mail'" width="40" height="35" viewBox="0 0 40 35" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M40 6.5625L22.018 19.0903C21.4078 19.478 20.7147 19.6822 20.009 19.6822C19.3033 19.6822 18.6102 19.478 18 19.0903L0 6.5625M4 0H36C38.2091 0 40 1.95875 40 4.375V30.625C40 33.0412 38.2091 35 36 35H4C1.79086 35 0 33.0412 0 30.625V4.375C0 1.95875 1.79086 0 4 0Z" stroke="url(#c-mail)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" />
              <defs><linearGradient id="c-mail" x1="20" y1="0" x2="20" y2="35" gradientUnits="userSpaceOnUse"><stop stop-color="#273947" /><stop offset="1" stop-color="#476587" /></linearGradient></defs>
            </svg>
            <svg v-else-if="c.icon === 'pin'" width="34" height="42" viewBox="0 0 34 42" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M34 16.8002C34 27.2856 22.2296 38.2058 18.2771 41.5784C17.9089 41.852 17.4607 42 17 42C16.5393 42 16.0911 41.852 15.7229 41.5784C11.7704 38.2058 0 27.2856 0 16.8002C0 12.3445 1.79107 8.07132 4.97918 4.92067C8.1673 1.77002 12.4913 0 17 0C21.5087 0 25.8327 1.77002 29.0208 4.92067C32.2089 8.07132 34 12.3445 34 16.8002Z" stroke="url(#c-pin)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" />
              <path d="M17 23.1003C20.5208 23.1003 23.375 20.2796 23.375 16.8002C23.375 13.3208 20.5208 10.5001 17 10.5001C13.4792 10.5001 10.625 13.3208 10.625 16.8002C10.625 20.2796 13.4792 23.1003 17 23.1003Z" stroke="url(#c-pin)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" />
              <defs><linearGradient id="c-pin" x1="17" y1="0" x2="17" y2="42" gradientUnits="userSpaceOnUse"><stop stop-color="#273947" /><stop offset="1" stop-color="#476587" /></linearGradient></defs>
            </svg>
            <svg v-else width="42" height="42" viewBox="0 0 42 42" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M42 21C42 32.598 32.598 42 21 42M42 21C42 9.40202 32.598 0 21 0M42 21H0M21 42C9.40202 42 0 32.598 0 21M21 42C15.6077 36.3381 12.6 28.8188 12.6 21C12.6 13.1812 15.6077 5.66192 21 0M21 42C26.3923 36.3381 29.4 28.8188 29.4 21C29.4 13.1812 26.3923 5.66192 21 0M0 21C0 9.40202 9.40202 0 21 0" stroke="url(#c-globe)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" />
              <defs><linearGradient id="c-globe" x1="21" y1="0" x2="21" y2="42" gradientUnits="userSpaceOnUse"><stop stop-color="#273947" /><stop offset="1" stop-color="#476587" /></linearGradient></defs>
            </svg>
          </span>
          <a v-if="c.href" :href="c.href" class="max-w-[236px] md:max-w-none">{{ c.text }}</a>
          <span v-else class="max-w-[236px] md:max-w-none">{{ c.text }}</span>
        </li>
      </ul>
    </section>
  </div>
</template>
