/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{vue,js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['"Golos Text"', '-apple-system', 'Roboto', 'Helvetica', 'sans-serif'],
      },
      colors: {
        brand: { dark: '#273947', light: '#476587' },
        field: { DEFAULT: '#D9D9D9', text: '#706F6F' },
      },
      backgroundImage: {
        'brand-gradient': 'linear-gradient(180deg, #273947 0%, #476587 100%)',
      },
    },
  },
  plugins: [],
}
