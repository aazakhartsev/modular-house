<template>
  <v-main class="layout">
    <div class="page">
      <AppHeader />
      <router-view />
      <AppFooter />
    </div>
  </v-main>
</template>

<script>
import AppHeader from '@/components/layout/AppHeader.vue'
import AppFooter from '@/components/layout/AppFooter.vue'

export default {
  name: 'DefaultLayout',
  components: { AppHeader, AppFooter },
}
</script>
