export default {
  namespaced: true,
  state: () => ({
    current: 'uk',
    options: [
      { code: 'uk', label: 'uk' },
      { code: 'en', label: 'en' },
      { code: 'pl', label: 'PL' },
    ],
  }),
  mutations: {
    SET_LOCALE(state, code) {
      state.current = code
    },
  },
  actions: {
    setLocale({ commit }, code) {
      commit('SET_LOCALE', code)
    },
  },
}
