export default {
  namespaced: true,
  state: () => ({
    drawerOpen: false,
    headerItems: [
      { key: 'houses', label: 'Будинки', to: { name: 'houses' } },
      { key: 'biogas', label: 'Біогаз', to: { name: 'biogas' } },
      { key: 'processing', label: 'переробка', to: { name: 'processing' } },
      { key: 'contacts', label: 'контакти', to: { name: 'biogas', hash: '#contacts' } },
    ],
    footerItems: [
      { key: 'houses', label: 'Будинки', to: { name: 'houses' } },
      { key: 'generation', label: 'Генерація', to: { name: 'biogas' } },
      { key: 'utilization', label: 'Утилізація', to: { name: 'processing' } },
      { key: 'contacts', label: 'контакти', to: { name: 'biogas', hash: '#contacts' } },
    ],
  }),
  mutations: {
    SET_DRAWER(state, value) {
      state.drawerOpen = value
    },
  },
  actions: {
    setDrawer({ commit }, value) {
      commit('SET_DRAWER', value)
    },
  },
}
