export default {
  namespaced: true,
  state: () => ({
    headerPhone: { label: '+38 (067) 209 2790', tel: '+380672092790' },
    phone: { label: '+38 (044) 502 2888', tel: '+380445022888' },
    address: 'вул. Ігоря Сікорського 1, м. Київ, 04112',
    email: 'info@servionica.com',
    site: { label: 'www.servionica.com', href: 'https://www.servionica.com' },
    socials: [
      { key: 'facebook', label: 'Facebook', href: 'https://www.facebook.com/' },
      { key: 'instagram', label: 'Instagram', href: 'https://www.instagram.com/' },
    ],
    copyright: 'Servionica © 2026. Всі права захищені.',
  }),
}
