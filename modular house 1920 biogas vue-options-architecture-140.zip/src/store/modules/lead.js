export default {
  namespaced: true,
  state: () => ({
    sending: false,
    leads: [],
  }),
  mutations: {
    SET_SENDING(state, value) {
      state.sending = value
    },
    ADD_LEAD(state, lead) {
      state.leads.push(lead)
    },
  },
  actions: {
    async submit({ commit }, payload) {
      commit('SET_SENDING', true)
      try {
        await new Promise((resolve) => setTimeout(resolve, 600))
        commit('ADD_LEAD', { ...payload, createdAt: Date.now() })
      } finally {
        commit('SET_SENDING', false)
      }
    },
  },
}
