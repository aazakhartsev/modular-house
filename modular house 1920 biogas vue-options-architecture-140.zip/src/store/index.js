import { createStore } from 'vuex'
import navigation from './modules/navigation'
import locale from './modules/locale'
import company from './modules/company'
import biogas from './modules/biogas'
import lead from './modules/lead'

export default createStore({
  modules: { navigation, locale, company, biogas, lead },
})
