const base = 'https://api.builder.io/api/v1/image/assets/TEMP'

export const images = {
  logo: `${base}/b9a4b1bc70dc4e03407d2bed8c7b3d6f9ebf7c18?width=450`,
  heroBg: `${base}/aa75e6a8ce933c83ca55b9e0d72497b4a03652db?width=3902`,
  installation: `${base}/82ca23c630b5edffe3459ebd13fec4cc5b94a274?width=3236`,
  featuresBg: `${base}/85ccba191f73b21b5eb3cd84098a8d44dfa30697?width=3846`,
  footerBg: `${base}/feef55fd80416c8a8c556ca5e6fcf0686dc7b6f7?width=3846`,
}
