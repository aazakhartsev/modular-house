<template>
  <section id="contacts" class="contacts">
    <svg class="contacts__defs" width="0" height="0" aria-hidden="true" focusable="false">
      <defs>
        <linearGradient id="contacts-gradient" x1="0.5" y1="0" x2="0.5" y2="1">
          <stop stop-color="#273947" />
          <stop offset="1" stop-color="#476587" />
        </linearGradient>
      </defs>
    </svg>

    <SectionTitle lines :span="1108">{{ contactsTitle }}</SectionTitle>

    <ul class="contacts__grid">
      <li class="contacts__item">
        <svg viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
          <path d="M29.58 36.42C30.0963 36.6571 30.678 36.7113 31.2292 36.5736C31.7805 36.4359 32.2683 36.1146 32.6125 35.6625L33.5 34.5C33.9657 33.879 34.5697 33.375 35.2639 33.0279C35.9582 32.6807 36.7238 32.5 37.5 32.5H45C46.3261 32.5 47.5979 33.0268 48.5355 33.9645C49.4732 34.9021 50 36.1739 50 37.5V45C50 46.3261 49.4732 47.5979 48.5355 48.5355C47.5979 49.4732 46.3261 50 45 50C33.0653 50 21.6193 45.2589 13.1802 36.8198C4.74106 28.3807 0 16.9347 0 5C0 3.67392 0.526784 2.40215 1.46447 1.46447C2.40215 0.526784 3.67392 0 5 0H12.5C13.8261 0 15.0979 0.526784 16.0355 1.46447C16.9732 2.40215 17.5 3.67392 17.5 5V12.5C17.5 13.2762 17.3193 14.0418 16.9721 14.7361C16.625 15.4303 16.121 16.0343 15.5 16.5L14.33 17.3775C13.871 17.7279 13.5475 18.2265 13.4145 18.7884C13.2814 19.3503 13.347 19.9409 13.6 20.46C17.0167 27.3997 22.6361 33.012 29.58 36.42Z" stroke="url(#contacts-gradient)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" />
        </svg>
        <a :href="`tel:${phone.tel}`">{{ phone.label }}</a>
      </li>

      <li class="contacts__item">
        <svg viewBox="0 0 40 50" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
          <path d="M40 20.0003C40 32.4829 26.1525 45.4831 21.5025 49.4981C21.0693 49.8239 20.542 50 20 50C19.458 50 18.9307 49.8239 18.4975 49.4981C13.8475 45.4831 0 32.4829 0 20.0003C0 14.6959 2.10714 9.60871 5.85786 5.85794C9.60859 2.10716 14.6957 0 20 0C25.3043 0 30.3914 2.10716 34.1421 5.85794C37.8929 9.60871 40 14.6959 40 20.0003Z" stroke="url(#contacts-gradient)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" />
          <path d="M20 27.5003C24.1421 27.5003 27.5 24.1424 27.5 20.0003C27.5 15.8581 24.1421 12.5002 20 12.5002C15.8579 12.5002 12.5 15.8581 12.5 20.0003C12.5 24.1424 15.8579 27.5003 20 27.5003Z" stroke="url(#contacts-gradient)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" />
        </svg>
        <span>{{ address }}</span>
      </li>

      <li class="contacts__item">
        <svg viewBox="0 0 63 50" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
          <path d="M63 9.375L34.6783 27.2719C33.7173 27.8257 32.6256 28.1174 31.5142 28.1174C30.4027 28.1174 29.3111 27.8257 28.35 27.2719L0 9.375M6.3 0H56.7C60.1794 0 63 2.79822 63 6.25V43.75C63 47.2018 60.1794 50 56.7 50H6.3C2.82061 50 0 47.2018 0 43.75V6.25C0 2.79822 2.82061 0 6.3 0Z" stroke="url(#contacts-gradient)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" />
        </svg>
        <a :href="`mailto:${email}`">{{ email }}</a>
      </li>

      <li class="contacts__item">
        <svg viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
          <path d="M50 25C50 38.8071 38.8071 50 25 50M50 25C50 11.1929 38.8071 0 25 0M50 25H0M25 50C11.1929 50 0 38.8071 0 25M25 50C18.5806 43.2596 15 34.3081 15 25C15 15.6919 18.5806 6.74038 25 0M25 50C31.4194 43.2596 35 34.3081 35 25C35 15.6919 31.4194 6.74038 25 0M0 25C0 11.1929 11.1929 0 25 0" stroke="url(#contacts-gradient)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" />
        </svg>
        <a :href="site.href" target="_blank" rel="noopener noreferrer">{{ site.label }}</a>
      </li>
    </ul>
  </section>
</template>

<script>
import { mapState } from 'vuex'
import SectionTitle from '@/components/common/SectionTitle.vue'

export default {
  name: 'ContactsSection',
  components: { SectionTitle },
  computed: {
    ...mapState('biogas', ['contactsTitle']),
    ...mapState('company', ['phone', 'address', 'email', 'site']),
  },
}
</script>

<style scoped lang="scss">
.contacts {
  padding: u(100) 20px u(133);
  scroll-margin-top: 0;

  &__defs {
    position: absolute;
  }

  &__grid {
    display: grid;
    grid-template-columns: 798fr 489fr;
    gap: u(57) 0;
    max-width: u(1287);
    margin: u(100) auto 0;
    padding: 0;
    list-style: none;
  }

  &__item {
    display: flex;
    align-items: center;
    gap: u(20);
    font-size: fs(24, 16);
    letter-spacing: -0.03em;

    svg {
      flex: none;
      height: max(32px, #{u(50)});
      width: auto;
    }

    a {
      transition: opacity 0.2s ease;
      &:hover {
        opacity: 0.65;
      }
    }
  }

  @include down($bp-lg) {
    padding: 56px 20px 64px;

    &__grid {
      grid-template-columns: 1fr;
      gap: 24px;
      max-width: 420px;
      margin-top: 40px;
    }

    &__item {
      gap: 16px;
      font-size: 18px;
      overflow-wrap: anywhere;
    }
  }
}
</style>
