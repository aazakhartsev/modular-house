<template>
  <section class="panels">
    <article
      v-for="panel in panels"
      :key="panel.key"
      class="panel"
      :class="`panel--${panel.key}`"
    >
      <h3 class="panel__title">{{ panel.title }}</h3>
      <ul class="panel__list">
        <li v-for="item in panel.items" :key="item">{{ item }}</li>
      </ul>
    </article>
  </section>
</template>

<script>
import { mapState } from 'vuex'

export default {
  name: 'IoPanels',
  computed: {
    ...mapState('biogas', ['panels']),
  },
}
</script>

<style scoped lang="scss">
.panels {
  display: flex;
  gap: u(143);
  max-width: 1920px;
  margin: 0 auto;
  padding: u(62) u(264) 0 u(243);

  @include down($bp-lg) {
    flex-direction: column;
    gap: 20px;
    padding: 20px 20px 0;
  }
}

.panel {
  flex: 1;
  min-height: u(370);
  padding: u(38) u(65) u(36);
  border-radius: u(80);
  font-size: fs(24, 15);
  letter-spacing: -0.03em;
  line-height: 2;

  &--input {
    background: $grey;
  }

  &--output {
    background: $sky;
    padding-left: u(66);
  }

  &__title {
    margin: 0;
    font-size: inherit;
    font-weight: 600;
    line-height: inherit;
  }

  &__list {
    margin: 0;
    padding: 0;
    list-style: none;
  }

  @include down($bp-lg) {
    min-height: 0;
    padding: 32px 28px;
    border-radius: 40px;
    font-size: 18px;
    line-height: 1.8;
  }
}
</style>
