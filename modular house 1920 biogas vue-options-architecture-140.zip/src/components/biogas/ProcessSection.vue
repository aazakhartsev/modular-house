<template>
  <section class="process">
    <div class="process__stage">
      <img class="process__img" :src="images.installation" alt="Біогазова установка" />

      <div class="process__overlay">
        <div class="process__flow">
          <template v-for="(step, index) in flow" :key="step.title">
            <div class="card card--step">
              <span class="card__title">{{ step.title }}</span>
              <span class="card__text">{{ step.text }}</span>
            </div>
            <svg
              v-if="index < flow.length - 1"
              class="process__arrow"
              viewBox="0 0 51 47"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              aria-hidden="true"
            >
              <path d="M1.41242e-06 14.6875L9 14.6875L9 3.93403e-07L36 23.5L9 47L9 32.3125L6.42011e-07 32.3125L1.41242e-06 14.6875ZM6 20.5625L6 26.4375L15 26.4375L15 33.9281L27 23.5L15 13.0719L15 20.5625L6 20.5625ZM24 1.04907e-06L51 23.5L24 47L24 39.1422L42 23.5L24 7.85782L24 1.04907e-06Z" fill="white" />
            </svg>
          </template>
        </div>

        <div class="process__stats">
          <div class="process__col process__col--left">
            <div v-for="stat in statsLeft" :key="stat.label" class="card card--stat">
              <span class="card__title">{{ stat.value }}</span>
              <span class="card__text">{{ stat.label }}</span>
            </div>
          </div>
          <div class="process__col process__col--right">
            <div v-for="stat in statsRight" :key="stat.label" class="card card--stat">
              <span class="card__title">{{ stat.value }}</span>
              <span class="card__text">{{ stat.label }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
import { mapState } from 'vuex'
import { images } from '@/constants/images'

export default {
  name: 'ProcessSection',
  data() {
    return { images }
  },
  computed: {
    ...mapState('biogas', ['flow', 'statsLeft', 'statsRight']),
  },
}
</script>

<style scoped lang="scss">
.process {
  padding: u(66) u(151) 0;

  &__stage {
    position: relative;
    aspect-ratio: 1618 / 1028;
    overflow: hidden;
    border-radius: u(80);
  }

  &__img {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
  }

  &__overlay {
    position: relative;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    height: 100%;
    padding: u(71) u(112) u(93);
    color: #fff;
  }

  &__flow {
    display: flex;
    align-items: center;
    justify-content: space-between;
  }

  &__arrow {
    flex: none;
    width: u(51);
    height: auto;
  }

  &__stats {
    display: flex;
    align-items: flex-end;
    justify-content: space-between;
  }

  &__col {
    display: flex;
    flex-direction: column;

    &--left {
      gap: u(82);
    }

    &--right {
      gap: u(69);
    }
  }

  @include down($bp-lg) {
    padding: 40px 20px 0;

    &__stage {
      aspect-ratio: auto;
      border-radius: 32px;
    }

    &__overlay {
      gap: 20px;
      height: auto;
      padding: 24px;
    }

    &__flow {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 12px;
    }

    &__arrow {
      display: none;
    }

    &__stats {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 12px;
    }

    &__col {
      gap: 12px !important;
    }
  }

  @include down($bp-md) {
    &__flow,
    &__stats {
      grid-template-columns: 1fr;
    }
  }
}

.card {
  display: flex;
  flex-direction: column;
  align-items: center;
  width: u(280);
  border-radius: u(30);
  background: rgba(255, 255, 255, 0.1);
  text-align: center;
  line-height: 0.9;

  &--step {
    height: u(180);
    padding-top: u(54);
    gap: u(31);
  }

  &--stat {
    height: u(133);
    padding-top: u(30);
    gap: u(14);
  }

  &__title {
    font-size: fs(40, 22);
    font-weight: 600;
    letter-spacing: -0.03em;
  }

  &__text {
    font-size: fs(24, 13);
    letter-spacing: -0.03em;
  }

  @include down($bp-lg) {
    width: 100%;
    height: auto !important;
    padding: 24px 16px !important;
    gap: 10px !important;

    &__title {
      font-size: 28px;
    }

    &__text {
      font-size: 18px;
    }
  }
}
</style>
