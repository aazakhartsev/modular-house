<template>
  <section class="features">
    <img class="features__bg" :src="images.featuresBg" alt="" />
    <div class="features__glow" aria-hidden="true" />

    <div class="features__overlay">
      <div class="features__col">
        <article
          v-for="item in featuresLeft"
          :key="item.key"
          class="feature"
          :style="cardStyle(item)"
        >
          <p class="feature__text">
            <span class="feature__title">✓ {{ item.title }}</span>
            {{ item.text }}
          </p>
        </article>
      </div>
      <div class="features__col">
        <article
          v-for="item in featuresRight"
          :key="item.key"
          class="feature"
          :style="cardStyle(item)"
        >
          <p class="feature__text">
            <span class="feature__title">✓ {{ item.title }}</span>
            {{ item.text }}
          </p>
        </article>
      </div>
    </div>

    <p class="features__note">{{ featuresText }}</p>
  </section>
</template>

<script>
import { mapState } from 'vuex'
import { images } from '@/constants/images'

export default {
  name: 'FeaturesSection',
  data() {
    return { images }
  },
  computed: {
    ...mapState('biogas', ['featuresLeft', 'featuresRight', 'featuresText']),
  },
  methods: {
    cardStyle(item) {
      return { '--h': item.h, '--pl': item.pl, '--pr': item.pr, '--pt': item.pt }
    },
  },
}
</script>

<style scoped lang="scss">
.features {
  position: relative;
  aspect-ratio: 1923 / 1336;
  margin-top: u(80);
  overflow: hidden;
  background: #0d1a22;
  color: #fff;

  &__bg {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
  }

  &__glow {
    position: absolute;
    top: u(343);
    left: u(1292);
    width: u(596);
    height: u(289);
    border-radius: 50%;
    background: rgba(0, 0, 0, 0.6);
    filter: blur(80px);
  }

  &__overlay {
    position: relative;
    display: flex;
    justify-content: space-between;
    padding: u(81) u(41) 0 u(145);
  }

  &__col {
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    width: u(555);
    height: u(546);
  }

  &__note {
    position: absolute;
    bottom: u(64);
    left: u(151);
    width: u(1329);
    margin: 0;
    font-size: fs(24, 14);
    letter-spacing: -0.03em;
    line-height: 0.9;
  }

  @include down($bp-lg) {
    aspect-ratio: auto;
    margin-top: 40px;

    &__glow {
      display: none;
    }

    &::after {
      content: '';
      position: absolute;
      inset: 0;
      background: rgba(0, 0, 0, 0.35);
    }

    &__overlay {
      z-index: 1;
      flex-direction: column;
      gap: 16px;
      padding: 48px 20px 0;
    }

    &__col {
      width: 100%;
      height: auto;
      gap: 16px;
    }

    &__note {
      position: relative;
      z-index: 1;
      bottom: auto;
      left: auto;
      width: auto;
      padding: 32px 20px 48px;
      font-size: 18px;
      line-height: 1.3;
    }
  }
}

.feature {
  height: calc(var(--h) * var(--u));
  padding: calc(var(--pt) * var(--u)) calc(var(--pr) * var(--u)) 0 calc(var(--pl) * var(--u));
  border-radius: u(30);
  background: rgba(255, 255, 255, 0.1);

  &__text {
    margin: 0;
    font-size: fs(24, 13);
    letter-spacing: -0.03em;
    line-height: 1.4;
    white-space: pre-line;
  }

  &__title {
    display: block;
    font-weight: 600;
    text-transform: uppercase;
  }

  @include down($bp-lg) {
    height: auto;
    padding: 24px;
    border-radius: 24px;

    &__text {
      font-size: 17px;
    }
  }
}
</style>
