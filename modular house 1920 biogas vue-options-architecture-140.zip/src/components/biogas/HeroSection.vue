<template>
  <section class="hero">
    <img class="hero__bg" :src="images.heroBg" alt="" />
    <div class="hero__glow" aria-hidden="true" />
    <SocialLinks class="hero__social" direction="column" :gap="19.6" />

    <div class="hero__inner">
      <h1 class="hero__title">{{ hero.titleTop }}<br />{{ hero.titleBottom }}</h1>
      <p class="hero__text">{{ hero.text }}</p>
      <CtaButton variant="light" :to="{ name: 'biogas', hash: '#contacts' }">
        {{ hero.cta }}
      </CtaButton>
    </div>
  </section>
</template>

<script>
import { mapState } from 'vuex'
import { images } from '@/constants/images'
import CtaButton from '@/components/common/CtaButton.vue'
import SocialLinks from '@/components/common/SocialLinks.vue'

export default {
  name: 'HeroSection',
  components: { CtaButton, SocialLinks },
  data() {
    return { images }
  },
  computed: {
    ...mapState('biogas', ['hero']),
  },
}
</script>

<style scoped lang="scss">
.hero {
  position: relative;
  aspect-ratio: 1920 / 1353;
  overflow: hidden;
  background: #0d1a22;
  color: #fff;

  &__bg {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: top center;
  }

  &__glow {
    position: absolute;
    top: u(753);
    left: u(77);
    width: u(596);
    height: u(289);
    border-radius: 50%;
    background: #000;
    filter: blur(80px);
  }

  &__social {
    position: absolute;
    top: u(437);
    left: u(60);
  }

  &__inner {
    position: relative;
    padding: u(200) u(144) 0 u(144);
  }

  &__title {
    margin: 0;
    font-size: fs(100, 40);
    font-weight: 600;
    line-height: 0.9;
    letter-spacing: -0.05em;
    text-transform: uppercase;
  }

  &__text {
    max-width: u(549);
    margin: u(434) 0 u(69) u(1);
    font-size: fs(24, 16);
    letter-spacing: -0.03em;
    line-height: normal;
  }

  @include down($bp-lg) {
    display: flex;
    flex-direction: column;
    aspect-ratio: auto;
    min-height: 640px;

    &::after {
      content: '';
      position: absolute;
      inset: 0;
      background: linear-gradient(180deg, rgba(0, 0, 0, 0.35), rgba(0, 0, 0, 0.6));
    }

    &__glow {
      display: none;
    }

    &__inner {
      z-index: 1;
      flex: 1;
      padding: 140px 24px 24px;
    }

    &__title {
      font-size: clamp(40px, 11vw, 80px);
    }

    &__text {
      max-width: 549px;
      margin: 32px 0;
      font-size: 18px;
    }

    &__social {
      position: relative;
      z-index: 1;
      top: auto;
      left: auto;
      flex-direction: row;
      order: 2;
      padding: 0 24px 40px;
    }
  }
}
</style>
