<template>
  <section class="lead">
    <form class="lead__form" novalidate @submit.prevent="onSubmit">
      <v-text-field
        v-model="form.name"
        class="lead__field"
        variant="solo"
        flat
        hide-details
        persistent-placeholder
        placeholder="Імʼя"
        autocomplete="name"
        aria-label="Імʼя"
        :error="errors.name"
      />
      <v-text-field
        v-model="form.phone"
        class="lead__field"
        variant="solo"
        flat
        hide-details
        persistent-placeholder
        type="tel"
        placeholder="+380 (__) ___-__-__"
        autocomplete="tel"
        aria-label="Телефон"
        :error="errors.phone"
      />
      <CtaButton variant="dark" type="submit" :loading="sending">
        {{ hero.cta }}
      </CtaButton>
    </form>

    <v-snackbar v-model="done" :timeout="4000" color="primary" location="bottom">
      Дякуємо! Ми зв'яжемося з вами найближчим часом.
    </v-snackbar>
  </section>
</template>

<script>
import { mapState, mapActions } from 'vuex'
import CtaButton from '@/components/common/CtaButton.vue'

export default {
  name: 'LeadForm',
  components: { CtaButton },
  data() {
    return {
      form: { name: '', phone: '' },
      errors: { name: false, phone: false },
      done: false,
    }
  },
  computed: {
    ...mapState('biogas', ['hero']),
    ...mapState('lead', ['sending']),
  },
  methods: {
    ...mapActions('lead', ['submit']),
    async onSubmit() {
      this.errors.name = !this.form.name.trim()
      this.errors.phone = this.form.phone.replace(/\D/g, '').length < 10
      if (this.errors.name || this.errors.phone) return

      await this.submit({ ...this.form })
      this.form = { name: '', phone: '' }
      this.done = true
    },
  },
}
</script>

<style scoped lang="scss">
.lead {
  padding: u(60) u(261) 0;

  &__form {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: u(60);
  }

  &__field {
    flex: 0 0 u(426);
    width: u(426);

    :deep(.v-field) {
      --v-field-padding-start: #{u(72)};
      --v-field-padding-end: #{u(30)};
      --v-field-input-padding-top: 0px;
      --v-field-input-padding-bottom: 0px;
      --v-input-control-height: #{u(87)};
      height: u(87);
      min-height: 56px;
      border-radius: 500px;
      background: $field;
      box-shadow: none;
    }

    :deep(.v-field__overlay),
    :deep(.v-field__outline) {
      display: none;
    }

    :deep(.v-field__input) {
      align-items: center;
      min-height: 0;
      height: 100%;
      padding-top: 0;
      padding-bottom: 0;
      color: #000;
      font-family: $font;
      font-size: fs(30, 18);
      letter-spacing: -0.03em;
    }

    :deep(input) {
      padding: 0;

      &::placeholder {
        color: #000 !important;
        opacity: 1 !important;
      }
    }

    :deep(.v-field--error) {
      box-shadow: inset 0 0 0 2px #c0392b;
    }
  }

  @include down($bp-lg) {
    padding: 40px 20px 0;

    &__form {
      flex-direction: column;
      gap: 20px;
    }

    &__field {
      flex: none;
      width: min(100%, 426px);
    }
  }
}
</style>
