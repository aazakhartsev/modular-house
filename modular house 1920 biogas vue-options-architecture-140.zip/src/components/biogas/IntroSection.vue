<template>
  <section class="intro">
    <SectionTitle lines>{{ intro.title }}</SectionTitle>
    <p class="intro__text">{{ intro.text }}</p>
    <SectionTitle class="intro__process-title">{{ intro.processTitle }}</SectionTitle>
  </section>
</template>

<script>
import { mapState } from 'vuex'
import SectionTitle from '@/components/common/SectionTitle.vue'

export default {
  name: 'IntroSection',
  components: { SectionTitle },
  computed: {
    ...mapState('biogas', ['intro']),
  },
}
</script>

<style scoped lang="scss">
.intro {
  padding: u(56) 20px 0;

  &__text {
    max-width: u(754);
    margin: u(24) auto 0;
    font-size: fs(24, 16);
    line-height: 0.9;
    letter-spacing: -0.03em;
    text-align: center;

    @include down($bp-lg) {
      max-width: 754px;
      line-height: 1.25;
    }
  }

  &__process-title {
    margin-top: u(63);
  }

  @include down($bp-lg) {
    padding-top: 48px;

    &__process-title {
      margin-top: 48px;
    }
  }
}
</style>
