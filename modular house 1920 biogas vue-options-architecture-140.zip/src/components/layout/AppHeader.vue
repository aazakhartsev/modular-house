<template>
  <header class="header">
    <router-link to="/" class="header__logo" aria-label="Servionica">
      <img :src="images.logo" alt="Servionica" />
    </router-link>

    <nav class="header__nav" aria-label="Головна навігація">
      <router-link
        v-for="item in headerItems"
        :key="item.key"
        :to="item.to"
        class="header__link"
        :class="{ 'header__link--active': isActive(item) }"
      >
        {{ item.label }}
      </router-link>
    </nav>

    <div class="header__actions">
      <PhoneButton :label="headerPhone.label" :tel="headerPhone.tel" :width="243" />
      <LangSwitcher />
    </div>

    <v-btn
      class="header__burger"
      icon
      variant="text"
      aria-label="Відкрити меню"
      @click="setDrawer(true)"
    >
      <svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M4 8H24M4 14H24M4 20H24" stroke="#fff" stroke-width="2" stroke-linecap="round" />
      </svg>
    </v-btn>
  </header>

  <v-navigation-drawer
    v-model="drawer"
    class="drawer"
    location="right"
    temporary
    width="300"
    color="primary"
  >
    <div class="drawer__inner">
      <router-link
        v-for="item in headerItems"
        :key="item.key"
        :to="item.to"
        class="drawer__link"
        :class="{ 'drawer__link--active': isActive(item) }"
        @click="setDrawer(false)"
      >
        {{ item.label }}
      </router-link>
      <PhoneButton :label="headerPhone.label" :tel="headerPhone.tel" :width="243" />
      <LangSwitcher />
    </div>
  </v-navigation-drawer>
</template>

<script>
import { mapState, mapActions } from 'vuex'
import { images } from '@/constants/images'
import PhoneButton from '@/components/common/PhoneButton.vue'
import LangSwitcher from '@/components/common/LangSwitcher.vue'

export default {
  name: 'AppHeader',
  components: { PhoneButton, LangSwitcher },
  data() {
    return { images }
  },
  computed: {
    ...mapState('navigation', ['headerItems', 'drawerOpen']),
    ...mapState('company', ['headerPhone']),
    drawer: {
      get() {
        return this.drawerOpen
      },
      set(value) {
        this.setDrawer(value)
      },
    },
  },
  methods: {
    ...mapActions('navigation', ['setDrawer']),
    isActive(item) {
      return item.to.name === this.$route.name && (item.to.hash || '') === this.$route.hash
    },
  },
}
</script>

<style scoped lang="scss">
.header {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  z-index: 10;
  display: grid;
  grid-template-columns: 1fr auto 1fr;
  align-items: start;
  padding: u(47) u(55) 0 u(57);
  color: #fff;

  &__logo img {
    width: u(225);
    min-width: 140px;
    height: auto;
    margin-top: u(3);
  }

  &__nav {
    display: flex;
    gap: u(10);
    height: u(56);
    min-height: 44px;
    padding: 11px;
    border: 1px solid #fff;
    border-radius: 93px;
  }

  &__link {
    display: flex;
    align-items: center;
    justify-content: center;
    width: u(120);
    min-width: 70px;
    border-radius: 16px;
    font-size: fs(16, 11);
    letter-spacing: -0.04em;
    text-transform: uppercase;
    transition: background-color 0.2s ease, color 0.2s ease;

    &:hover {
      background: rgba(255, 255, 255, 0.18);
    }

    &--active,
    &--active:hover {
      background: #fff;
      color: #000;
    }
  }

  &__actions {
    display: flex;
    justify-self: end;
    gap: u(63);
  }

  &__burger {
    display: none;
  }

  @include down($bp-lg) {
    grid-template-columns: 1fr auto;
    align-items: center;
    padding: 20px;

    &__logo img {
      width: 160px;
      margin-top: 0;
    }

    &__nav,
    &__actions {
      display: none;
    }

    &__burger {
      display: inline-flex;
      justify-self: end;
    }
  }
}

.drawer {
  &__inner {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    gap: 20px;
    padding: 72px 24px 24px;
    color: #fff;
  }

  &__link {
    font-size: 20px;
    letter-spacing: -0.04em;
    text-transform: uppercase;
    opacity: 0.7;

    &--active {
      opacity: 1;
    }
  }
}
</style>
