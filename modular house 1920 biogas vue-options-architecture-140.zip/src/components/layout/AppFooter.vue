<template>
  <footer class="footer">
    <img class="footer__bg" :src="images.footerBg" alt="" />
    <div class="footer__inner">
      <router-link to="/" class="footer__logo" aria-label="Servionica">
        <img :src="images.logo" alt="Servionica" />
      </router-link>

      <nav class="footer__nav" aria-label="Навігація у футері">
        <router-link
          v-for="item in footerItems"
          :key="item.key"
          :to="item.to"
          class="footer__link"
        >
          {{ item.label }}
        </router-link>
      </nav>

      <PhoneButton
        class="footer__phone"
        :label="phone.label"
        :tel="phone.tel"
        :width="248"
        tracking="-0.03em"
      />

      <SocialLinks class="footer__social" reverse :gap="80" />

      <p class="footer__copy">{{ copyright }}</p>
    </div>
  </footer>
</template>

<script>
import { mapState } from 'vuex'
import { images } from '@/constants/images'
import PhoneButton from '@/components/common/PhoneButton.vue'
import SocialLinks from '@/components/common/SocialLinks.vue'

export default {
  name: 'AppFooter',
  components: { PhoneButton, SocialLinks },
  data() {
    return { images }
  },
  computed: {
    ...mapState('navigation', ['footerItems']),
    ...mapState('company', ['phone', 'copyright']),
  },
}
</script>

<style scoped lang="scss">
.footer {
  position: relative;
  min-height: u(307);
  color: #fff;
  background: $navy;

  &__bg {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
  }

  &__inner {
    position: relative;
    display: grid;
    grid-template-columns: 1fr auto 1fr;
    grid-template-areas:
      'logo nav phone'
      '. . social'
      'copy copy copy';
    padding: u(64) u(60) u(28) u(57);
  }

  &__logo {
    grid-area: logo;
    margin-top: u(21);

    img {
      width: u(225);
      min-width: 140px;
      height: auto;
    }
  }

  &__nav {
    display: flex;
    grid-area: nav;
    gap: u(96);
    margin-top: u(42);
  }

  &__link {
    font-size: fs(16, 12);
    letter-spacing: -0.04em;
    text-transform: uppercase;
    transition: opacity 0.2s ease;

    &:hover {
      opacity: 0.7;
    }
  }

  &__phone {
    grid-area: phone;
    justify-self: end;
  }

  &__social {
    grid-area: social;
    justify-self: end;
    margin-top: u(46);
  }

  &__copy {
    grid-area: copy;
    margin: u(15) 0 0;
    font-size: fs(16, 13);
    letter-spacing: -0.04em;
    text-align: center;
  }

  @include down($bp-lg) {
    &__inner {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 28px;
      padding: 48px 20px 32px;
    }

    &__logo,
    &__nav,
    &__social,
    &__copy {
      margin: 0;
    }

    &__nav {
      flex-wrap: wrap;
      justify-content: center;
      gap: 16px 32px;
    }
  }
}
</style>
