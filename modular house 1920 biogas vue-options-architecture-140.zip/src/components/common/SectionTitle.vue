<template>
  <div class="section-title" :style="{ '--span': span }">
    <span v-if="lines" class="section-title__line" />
    <h2 class="section-title__text"><slot /></h2>
    <span v-if="lines" class="section-title__line" />
  </div>
</template>

<script>
export default {
  name: 'SectionTitle',
  props: {
    lines: { type: Boolean, default: false },
    span: { type: Number, default: 1448 },
  },
}
</script>

<style scoped lang="scss">
.section-title {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: min(100%, calc(var(--span) * var(--u)));
  margin: 0 auto;

  &__line {
    flex: 0 0 u(304);
    height: 1px;
    background: $navy;

    @include down($bp-lg) {
      display: none;
    }
  }

  &__text {
    flex: 1;
    margin: 0;
    padding-bottom: 0.12em;
    @include gradient-text;
    font-size: fs(70, 34);
    font-weight: 600;
    line-height: 0.9;
    letter-spacing: -0.03em;
    text-align: center;
  }
}
</style>
