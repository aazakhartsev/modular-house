<template>
  <div class="lang" role="group" aria-label="Мова">
    <template v-for="(option, index) in options" :key="option.code">
      <span v-if="index" class="lang__sep">|</span>
      <button
        type="button"
        class="lang__btn"
        :class="{ 'lang__btn--active': option.code === current }"
        @click="setLocale(option.code)"
      >
        {{ option.label }}
      </button>
    </template>
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex'

export default {
  name: 'LangSwitcher',
  computed: {
    ...mapState('locale', ['current', 'options']),
  },
  methods: {
    ...mapActions('locale', ['setLocale']),
  },
}
</script>

<style scoped lang="scss">
.lang {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 0.28em;
  height: u(56);
  min-height: 44px;
  padding: 0 u(28);
  border: 1px solid #fff;
  border-radius: 57px;
  color: #fff;
  font-size: fs(20, 14);
  letter-spacing: -0.05em;
  line-height: 0.96;
  text-transform: uppercase;

  &__btn {
    padding: 0;
    border: 0;
    background: none;
    color: $muted;
    font: inherit;
    letter-spacing: inherit;
    text-transform: inherit;
    cursor: pointer;
    transition: color 0.2s ease;

    &--active,
    &:hover {
      color: #fff;
    }
  }
}
</style>
