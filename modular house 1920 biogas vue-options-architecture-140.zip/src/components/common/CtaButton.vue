<template>
  <v-btn
    class="cta"
    :class="`cta--${variant}`"
    variant="flat"
    :to="to"
    :type="type"
    :loading="loading"
  >
    <span class="cta__label"><slot /></span>
    <span class="cta__icon" aria-hidden="true">
      <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M0 0H10V10M10 0L0 10" stroke="currentColor" stroke-width="1.5" />
      </svg>
    </span>
  </v-btn>
</template>

<script>
export default {
  name: 'CtaButton',
  props: {
    variant: { type: String, default: 'light' },
    to: { type: [String, Object], default: undefined },
    type: { type: String, default: 'button' },
    loading: { type: Boolean, default: false },
  },
}
</script>

<style scoped lang="scss">
.cta.v-btn {
  width: min(100%, #{u(426)});
  max-width: 426px;
  height: u(87);
  min-height: 64px;
  padding: 0 u(13) 0 u(46);
  border-radius: 500px;
  text-transform: none;
  letter-spacing: -0.03em;
  font-family: $font;
  font-weight: 400;
  font-size: fs(24, 17);

  :deep(.v-btn__content) {
    width: 100%;
    justify-content: space-between;
    gap: 8px;
    white-space: nowrap;
  }

  &.cta--light {
    background: #fff;
    color: #000;
  }

  &.cta--dark {
    background: $navy;
    color: #fff;
  }

  @include down($bp-lg) {
    width: 100%;
    max-width: 426px;
    height: 72px;
    padding: 0 12px 0 32px;
  }
}

.cta__icon {
  display: grid;
  flex: none;
  place-items: center;
  width: max(48px, #{u(62)});
  height: max(48px, #{u(62)});
  border-radius: 50%;
  transition: transform 0.25s ease;
}

.cta--light .cta__icon {
  background: $navy;
  color: #fff;
}

.cta--dark .cta__icon {
  background: #fff;
  color: $navy;
}

.cta:hover .cta__icon {
  transform: rotate(45deg);
}
</style>
