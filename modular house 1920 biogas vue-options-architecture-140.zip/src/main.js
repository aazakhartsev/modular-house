import 'vuetify/styles'
import './styles/main.scss'

import { createApp } from 'vue'
import { createVuetify } from 'vuetify'
import App from './App.vue'
import router from './router'
import store from './store'

const vuetify = createVuetify({
  theme: {
    defaultTheme: 'servionica',
    themes: {
      servionica: {
        dark: false,
        colors: {
          primary: '#273947',
          secondary: '#476587',
          background: '#ffffff',
          surface: '#ffffff',
        },
      },
    },
  },
})

createApp(App).use(router).use(store).use(vuetify).mount('#app')
