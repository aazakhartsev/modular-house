<template>
  <div class="biogas">
    <HeroSection />
    <IntroSection />
    <ProcessSection />
    <IoPanels />
    <FeaturesSection />
    <LeadForm />
    <ContactsSection />
  </div>
</template>

<script>
import HeroSection from '@/components/biogas/HeroSection.vue'
import IntroSection from '@/components/biogas/IntroSection.vue'
import ProcessSection from '@/components/biogas/ProcessSection.vue'
import IoPanels from '@/components/biogas/IoPanels.vue'
import FeaturesSection from '@/components/biogas/FeaturesSection.vue'
import LeadForm from '@/components/biogas/LeadForm.vue'
import ContactsSection from '@/components/biogas/ContactsSection.vue'

export default {
  name: 'BiogasView',
  components: {
    HeroSection,
    IntroSection,
    ProcessSection,
    IoPanels,
    FeaturesSection,
    LeadForm,
    ContactsSection,
  },
}
</script>
