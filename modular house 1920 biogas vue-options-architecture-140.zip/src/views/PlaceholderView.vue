<template>
  <section class="placeholder">
    <h1 class="placeholder__title">{{ $route.meta.title }}</h1>
    <p class="placeholder__text">
      Цю сторінку ще не наповнено. Продовжуйте ставити запити, і ми створимо її вміст.
    </p>
    <CtaButton variant="light" :to="{ name: 'biogas' }">На головну</CtaButton>
  </section>
</template>

<script>
import CtaButton from '@/components/common/CtaButton.vue'

export default {
  name: 'PlaceholderView',
  components: { CtaButton },
}
</script>

<style scoped lang="scss">
.placeholder {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 32px;
  min-height: 720px;
  padding: 160px 24px 80px;
  background: linear-gradient(180deg, $navy 0%, $blue 100%);
  color: #fff;
  text-align: center;

  &__title {
    margin: 0;
    font-size: clamp(40px, 7vw, 100px);
    font-weight: 600;
    line-height: 0.9;
    letter-spacing: -0.05em;
    text-transform: uppercase;
  }

  &__text {
    max-width: 549px;
    margin: 0;
    font-size: 24px;
    letter-spacing: -0.03em;
  }
}
</style>
