import { createRouter, createWebHistory } from 'vue-router'
import DefaultLayout from '@/layouts/DefaultLayout.vue'

const BiogasView = () => import('@/views/BiogasView.vue')
const PlaceholderView = () => import('@/views/PlaceholderView.vue')

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/',
      component: DefaultLayout,
      children: [
        { path: '', name: 'biogas', component: BiogasView, meta: { title: 'Біогаз' } },
        { path: 'houses', name: 'houses', component: PlaceholderView, meta: { title: 'Будинки' } },
        {
          path: 'processing',
          name: 'processing',
          component: PlaceholderView,
          meta: { title: 'Переробка' },
        },
      ],
    },
    { path: '/:pathMatch(.*)*', redirect: { name: 'biogas' } },
  ],
  scrollBehavior(to, from, savedPosition) {
    if (to.hash) return { el: to.hash, top: 0, behavior: 'smooth' }
    if (savedPosition) return savedPosition
    return { top: 0 }
  },
})

router.afterEach((to) => {
  document.title = `${to.meta.title} — Servionica`
})

export default router
