# Servionica Biogas Landing

Vue 3 (Options API, plain JavaScript) + Vite, Vue Router 4, Vuex 4 (namespaced modules), Vuetify 3, SCSS.

## Structure

- `src/main.js` — app entry (Vuetify, router, store)
- `src/router/` — routes; `DefaultLayout` wraps all pages (header + footer)
- `src/store/modules/` — `navigation`, `locale`, `company`, `biogas` (page content), `lead`
- `src/views/` — `BiogasView` (home), `PlaceholderView` (houses, processing)
- `src/components/{layout,common,biogas}/` — building blocks
- `src/styles/_variables.scss` — injected into every SCSS file (colors, `u()`, `fs()`, `down()`)

## Conventions

- Options API only, no TypeScript, no `<script setup>`.
- Scale design pixels (1920 frame) with `u(n)` / `fs(n, min)`; stack layouts below `$bp-lg`.
- Commands: `npm run dev`, `npm run build`, `npm run format`.
