<template>
  <v-btn
    class="cta"
    :class="{ 'cta--dark': dark }"
    variant="flat"
    :type="type"
    :loading="loading"
    :to="to"
    @click="$emit('click', $event)"
  >
    <span class="cta__label"><slot>Отримати консультацію</slot></span>
    <span class="cta__circle">
      <svg viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M0 0H10V10M10 0L0 10" stroke="currentColor" stroke-width="1.5" />
      </svg>
    </span>
  </v-btn>
</template>

<script>
export default {
  name: 'CtaButton',
  props: {
    dark: { type: Boolean, default: false },
    type: { type: String, default: 'button' },
    loading: { type: Boolean, default: false },
    to: { type: [String, Object], default: undefined },
  },
  emits: ['click'],
}
</script>

<style scoped lang="scss">
.cta.v-btn {
  width: u(426);
  height: u(87);
  padding: 0;
  border-radius: 500px;
  background: #fff;
  color: #33495f;
  font-size: u(24);
  font-weight: 400;
  letter-spacing: u(-0.72);
  text-transform: none;

  &.cta--dark {
    background: $navy;
    color: #fff;
  }

  :deep(.v-btn__content) {
    width: 100%;
    justify-content: space-between;
    padding: 0 u(13) 0 u(46);
  }

  &__circle {
    display: flex;
    align-items: center;
    justify-content: center;
    width: u(62);
    height: u(62);
    border-radius: 50%;
    background: $navy;
    color: #fff;
    transition: transform 0.2s;

    svg {
      width: u(10);
      height: u(10);
    }
  }

  &--dark &__circle {
    background: #fff;
    color: $navy;
  }

  &:hover &__circle {
    transform: rotate(45deg);
  }
}
</style>
