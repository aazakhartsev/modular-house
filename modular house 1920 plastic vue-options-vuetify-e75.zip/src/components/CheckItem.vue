<template>
  <li class="check">
    <span class="check__icon">
      <svg viewBox="0 0 35 35" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="17.2208" cy="17.2208" r="15.9545" :stroke="'url(#' + uid + ')'" stroke-width="2.53247" />
        <defs>
          <linearGradient :id="uid" x1="17.2208" y1="0" x2="17.2208" y2="34.4416" gradientUnits="userSpaceOnUse">
            <stop stop-color="#273947" />
            <stop offset="1" stop-color="#476587" />
          </linearGradient>
        </defs>
      </svg>
      <span class="check__mark">✓</span>
    </span>
    <span><slot /></span>
  </li>
</template>

<script>
let counter = 0

export default {
  name: 'CheckItem',
  data() {
    counter += 1
    return { uid: 'check-grad-' + counter }
  },
}
</script>

<style scoped lang="scss">
.check {
  display: flex;
  align-items: center;
  gap: u(20);
  min-height: u(48);
  list-style: none;

  &__icon {
    position: relative;
    flex: none;
    width: u(35);
    height: u(35);
    margin-left: u(-58);
    margin-right: u(3);

    svg {
      display: block;
      width: 100%;
      height: 100%;
    }
  }

  &__mark {
    @include gradient-text;
    position: absolute;
    inset: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: 'Exo', sans-serif;
    font-size: u(35);
    line-height: 0.9;
  }
}
</style>
