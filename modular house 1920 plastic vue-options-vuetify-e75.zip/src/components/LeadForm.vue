<template>
  <form class="lead" novalidate @submit.prevent="onSubmit">
    <v-text-field
      v-model="name"
      class="lead__field"
      placeholder="Імʼя"
      variant="solo-flat"
      bg-color="#D9D9D9"
      hide-details
      autocomplete="name"
      aria-label="Імʼя"
    />
    <v-text-field
      v-model="phone"
      class="lead__field"
      placeholder="+380 (__) ___-__-__"
      variant="solo-flat"
      bg-color="#D9D9D9"
      hide-details
      type="tel"
      autocomplete="tel"
      aria-label="Телефон"
    />
    <CtaButton dark type="submit" :loading="submitting" />
    <p v-if="error" class="lead__msg lead__msg--error">{{ error }}</p>
    <p v-else-if="submitted" class="lead__msg">Дякуємо! Ми зв’яжемося з вами найближчим часом.</p>
  </form>
</template>

<script>
import { mapState, mapActions } from 'vuex'
import CtaButton from '@/components/CtaButton.vue'

export default {
  name: 'LeadForm',
  components: { CtaButton },
  data() {
    return { name: '', phone: '' }
  },
  computed: {
    ...mapState('leads', ['submitting', 'submitted', 'error']),
  },
  watch: {
    submitted(value) {
      if (value) {
        this.name = ''
        this.phone = ''
      }
    },
  },
  methods: {
    ...mapActions('leads', ['submit']),
    onSubmit() {
      this.submit({ name: this.name, phone: this.phone })
    },
  },
}
</script>

<style scoped lang="scss">
.lead {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: center;
  gap: u(60);

  @include mobile {
    flex-direction: column;
    gap: u(30);
  }

  &__field {
    flex: none;
    width: u(426);

    :deep(.v-field) {
      height: u(87);
      border-radius: 500px;
      padding: 0 u(72);
      font-size: u(30);
      letter-spacing: u(-0.9);
      color: #000;
    }

    :deep(.v-field__input) {
      height: 100%;
      min-height: 0;
      padding: 0;
      align-items: center;
      font-size: u(30);
      letter-spacing: u(-0.9);
      opacity: 1;
    }

    :deep(input::placeholder) {
      color: #000;
      opacity: 1;
    }
  }

  &__msg {
    flex-basis: 100%;
    margin: u(-20) 0 0;
    text-align: center;
    font-size: u(20);
    color: $navy;

    &--error {
      color: #b3261e;
    }
  }
}
</style>
