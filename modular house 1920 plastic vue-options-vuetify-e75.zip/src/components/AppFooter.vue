<template>
  <footer class="footer">
    <img class="footer__bg" :src="bg" alt="" />
    <div class="footer__inner">
      <router-link to="/" class="footer__logo"><img :src="logo" alt="Servionica" /></router-link>

      <nav class="footer__nav" aria-label="Навігація у футері">
        <router-link v-for="link in links" :key="link.label" :to="link.to" class="footer__link">
          {{ link.label }}
        </router-link>
      </nav>

      <div class="footer__right">
        <PhoneButton :phone="phone" />
        <SocialLinks />
      </div>

      <p class="footer__copy">Servionica © 2026. Всі права захищені.</p>
    </div>
  </footer>
</template>

<script>
import PhoneButton from '@/components/PhoneButton.vue'
import SocialLinks from '@/components/SocialLinks.vue'
import { images, footerLinks, contacts } from '@/data/content'

export default {
  name: 'AppFooter',
  components: { PhoneButton, SocialLinks },
  data() {
    return {
      bg: images.footer,
      logo: images.logo,
      links: footerLinks,
      phone: contacts.phone,
    }
  },
}
</script>

<style scoped lang="scss">
.footer {
  position: relative;
  max-width: 1920px;
  margin: u(60) auto 0;
  color: #fff;
  background: $navy;
  overflow: hidden;

  &__bg {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
  }

  &__inner {
    position: relative;
    display: grid;
    grid-template-columns: 1fr auto 1fr;
    grid-template-areas: 'logo nav right' 'copy copy copy';
    align-items: start;
    row-gap: u(90);
    padding: u(64) u(60) u(50) u(57);

    @include mobile {
      grid-template-columns: 1fr;
      grid-template-areas: 'logo' 'nav' 'right' 'copy';
      justify-items: center;
      row-gap: u(40);
      padding: u(60) u(30);
    }
  }

  &__logo {
    grid-area: logo;
    padding-top: u(21);

    img {
      display: block;
      width: u(225);
      height: u(45);
      @include mobile {
        width: u(300);
        height: u(60);
      }
    }
  }

  &__nav {
    grid-area: nav;
    display: flex;
    gap: u(97);
    padding-top: u(42);

    @include mobile {
      flex-wrap: wrap;
      justify-content: center;
      gap: u(30) u(50);
      padding-top: 0;
    }
  }

  &__link {
    color: #fff;
    font-size: u(16);
    letter-spacing: u(-0.64);
    text-transform: uppercase;
    text-decoration: none;

    &:hover {
      opacity: 0.7;
    }
  }

  &__right {
    grid-area: right;
    justify-self: end;
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    gap: u(46);

    @include mobile {
      justify-self: center;
      align-items: center;
    }
  }

  &__copy {
    grid-area: copy;
    justify-self: center;
    margin: 0;
    font-size: u(16);
    letter-spacing: u(-0.64);
    text-align: center;
  }
}
</style>
