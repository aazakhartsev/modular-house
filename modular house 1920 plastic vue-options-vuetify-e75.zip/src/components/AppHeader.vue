<template>
  <header class="header">
    <router-link to="/" class="header__logo" @click="closeMenu">
      <img :src="logo" alt="Servionica" />
    </router-link>

    <nav class="header__nav" aria-label="Головна навігація">
      <router-link
        v-for="link in links"
        :key="link.label"
        :to="link.to"
        class="header__link"
        :class="{ 'header__link--active': isActive(link) }"
      >
        {{ link.label }}
      </router-link>
    </nav>

    <div class="header__actions">
      <PhoneButton class="header__phone" :phone="phone" />
      <div class="header__lang">
        <span>uk</span><span class="header__lang-sep">|</span><span class="header__lang-dim">en</span>
        <span class="header__lang-sep">|</span><span class="header__lang-dim">PL</span>
      </div>
      <v-btn class="header__burger" icon variant="text" aria-label="Меню" @click="toggleMenu">
        <v-icon :icon="menuOpen ? 'mdi-close' : 'mdi-menu'" color="white" />
      </v-btn>
    </div>

    <transition name="fade">
      <nav v-if="menuOpen" class="header__mobile" aria-label="Мобільна навігація">
        <router-link
          v-for="link in links"
          :key="link.label"
          :to="link.to"
          class="header__mobile-link"
          :class="{ 'header__mobile-link--active': isActive(link) }"
          @click="closeMenu"
        >
          {{ link.label }}
        </router-link>
        <PhoneButton :phone="phone" />
      </nav>
    </transition>
  </header>
</template>

<script>
import { mapState, mapActions } from 'vuex'
import PhoneButton from '@/components/PhoneButton.vue'
import { images, navLinks, contacts } from '@/data/content'

export default {
  name: 'AppHeader',
  components: { PhoneButton },
  data() {
    return {
      logo: images.logo,
      links: navLinks,
      phone: contacts.mainPhone,
    }
  },
  computed: {
    ...mapState('ui', ['menuOpen']),
  },
  watch: {
    '$route.fullPath'() {
      this.closeMenu()
    },
  },
  methods: {
    ...mapActions('ui', ['toggleMenu', 'closeMenu']),
    isActive(link) {
      if (link.to.includes('#')) return false
      return this.$route.path === link.to
    },
  },
}
</script>

<style scoped lang="scss">
.header {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  z-index: 10;
  display: grid;
  grid-template-columns: 1fr auto 1fr;
  align-items: center;
  padding: u(47) u(55) 0 u(57);
  color: #fff;

  @include mobile {
    display: flex;
    justify-content: space-between;
    padding: u(30) u(30) 0;
  }

  &__logo {
    justify-self: start;
    display: block;

    img {
      display: block;
      width: u(225);
      height: u(45);
      @include mobile {
        width: u(300);
        height: u(60);
      }
    }
  }

  &__nav {
    display: flex;
    align-items: center;
    gap: u(10);
    height: u(56);
    padding: 0 u(22);
    border: 1px solid #fff;
    border-radius: 93px;
    box-sizing: border-box;

    @include mobile {
      display: none;
    }
  }

  &__link {
    display: flex;
    align-items: center;
    justify-content: center;
    min-width: u(120);
    height: u(32);
    padding: 0 u(14);
    border-radius: u(16);
    color: #fff;
    font-size: u(16);
    letter-spacing: u(-0.64);
    text-transform: uppercase;
    text-decoration: none;
    box-sizing: border-box;
    transition: background 0.2s, color 0.2s;

    &:hover {
      background: rgba(255, 255, 255, 0.2);
    }

    &--active,
    &--active:hover {
      background: #fff;
      color: #000;
    }
  }

  &__actions {
    justify-self: end;
    display: flex;
    align-items: center;
    gap: u(55);
  }

  &__phone {
    @include mobile {
      display: none;
    }
  }

  &__lang {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: u(6);
    width: u(151);
    height: u(56);
    border: 1px solid #fff;
    border-radius: 57px;
    box-sizing: border-box;
    font-size: u(20);
    letter-spacing: u(-1);
    text-transform: uppercase;

    @include mobile {
      display: none;
    }
  }

  &__lang-dim {
    color: #7f7e7e;
  }

  &__burger {
    display: none;

    @include mobile {
      display: inline-flex;
    }
  }

  &__mobile {
    position: absolute;
    top: u(120);
    left: u(30);
    right: u(30);
    display: flex;
    flex-direction: column;
    align-items: stretch;
    gap: u(10);
    padding: u(24);
    border-radius: u(40);
    background: rgba(39, 57, 71, 0.96);
    backdrop-filter: blur(8px);

    :deep(.phone) {
      justify-content: center;
      margin-top: u(10);
    }
  }

  &__mobile-link {
    padding: u(16) u(20);
    border-radius: u(30);
    color: #fff;
    font-size: u(24);
    text-transform: uppercase;
    text-decoration: none;

    &--active {
      background: #fff;
      color: #000;
    }
  }
}

.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.2s;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>
