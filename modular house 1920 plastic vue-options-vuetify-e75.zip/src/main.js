import { createApp } from 'vue'
import { createVuetify } from 'vuetify'
import * as components from 'vuetify/components'
import 'vuetify/styles'
import '@mdi/font/css/materialdesignicons.css'
import './styles/main.scss'
import App from './App.vue'
import router from './router'
import store from './store'

const vuetify = createVuetify({ components })

createApp(App).use(router).use(store).use(vuetify).mount('#app')
