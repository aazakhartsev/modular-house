<template>
  <div class="page recycling">
    <section class="hero">
      <img class="hero__bg hero__bg--house" :src="images.house" alt="" />
      <img class="hero__bg hero__bg--machine" :src="images.machine" alt="" />

      <SocialLinks class="hero__social" vertical />

      <div class="hero__content">
        <h1 class="hero__title">Перероблення пластику<br />у вашому домі</h1>
        <p class="hero__text">
          Інтегрований шредер для модульних будинків Servionica. Перетворюйте побутовий пластик на корисну сировину
          прямо в технічному приміщенні.
        </p>
      </div>

      <CtaButton class="hero__cta" to="#consult" />
    </section>

    <section class="intro">
      <div class="heading">
        <span class="heading__line heading__line--left" />
        <h2 class="section-title">Ефективне перероблення пластику</h2>
        <span class="heading__line heading__line--right" />
        <p class="heading__sub">Ваш ключ до власного заводу відходів. Забудьте про сміттєві баки та накопичення пластику</p>
      </div>

      <div class="cards">
        <article class="card card--accepted">
          <ul class="card__list">
            <li class="card__title">{{ accepted.title }}</li>
            <CheckItem v-for="item in accepted.items" :key="item">{{ item }}</CheckItem>
          </ul>
          <img class="card__img card__img--shredder" :src="images.shredder" alt="" />
        </article>

        <article class="card card--benefits">
          <ul class="card__list">
            <li class="card__title">{{ benefits.title }}</li>
            <CheckItem v-for="item in benefits.items" :key="item">{{ item }}</CheckItem>
          </ul>
          <span class="card__glow" />
          <img class="card__img card__img--mini" :src="images.miniMachine" alt="" />
        </article>
      </div>
    </section>

    <section class="process">
      <div class="heading heading--plain">
        <h2 class="section-title">Як це працює?</h2>
        <p class="heading__sub">
          Забудьте про сміттєві баки та накопичення пластику. Зменшує об'єм пластикового сміття до 10 разів.
        </p>
      </div>

      <div class="steps">
        <template v-for="(step, index) in steps" :key="step.image">
          <svg v-if="index > 0" class="steps__arrow" viewBox="0 0 81 76" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M2.28392e-06 23.75L14.2941 23.75L14.2941 6.24816e-07L57.1765 38L14.2941 76L14.2941 52.25L1.03815e-06 52.25L2.28392e-06 23.75ZM9.52941 33.25L9.52941 42.75L23.8235 42.75L23.8235 54.8625L42.8824 38L23.8235 21.1375L23.8235 33.25L9.52941 33.25ZM38.1176 1.66618e-06L81 38L38.1176 76L38.1176 63.2938L66.7059 38L38.1176 12.7063L38.1176 1.66618e-06Z"
              fill="#273947"
            />
          </svg>
          <figure class="step" :class="'step--' + (index + 1)">
            <div class="step__media"><img :src="step.image" alt="" /></div>
            <figcaption class="step__caption">
              <span v-for="line in step.caption" :key="line">{{ line }}</span>
            </figcaption>
          </figure>
        </template>
      </div>
    </section>

    <section id="consult" class="specs">
      <div class="specs__box">
        <img class="specs__bg" :src="images.specs" alt="" />
        <div class="specs__grid">
          <div v-for="spec in specs" :key="spec.label" class="spec">
            <span class="spec__value" :class="{ 'spec__value--bold': spec.bold }">{{ spec.value }}</span>
            <span class="spec__label" :class="{ 'spec__label--bold': spec.bold }">{{ spec.label }}</span>
          </div>
        </div>
        <p class="specs__text">
          Ваш побутовий пластик більше не потребує сміттєвого баку. Шредер подрібнює пляшки, пакування та плівку в
          гранулят, придатний для повторного використання або здачі на переробку.
        </p>
      </div>

      <LeadForm class="specs__form" />
    </section>

    <section id="contacts" class="contacts">
      <div class="heading heading--contacts">
        <span class="heading__line heading__line--left" />
        <h2 class="section-title">Контакти</h2>
        <span class="heading__line heading__line--right" />
      </div>

      <div class="contacts__grid">
        <div class="contact">
          <svg class="contact__icon" viewBox="0 0 63 50" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M63 9.375L34.6783 27.2719C33.7173 27.8257 32.6256 28.1174 31.5142 28.1174C30.4027 28.1174 29.3111 27.8257 28.35 27.2719L0 9.375M6.3 0H56.7C60.1794 0 63 2.79822 63 6.25V43.75C63 47.2018 60.1794 50 56.7 50H6.3C2.82061 50 0 47.2018 0 43.75V6.25C0 2.79822 2.82061 0 6.3 0Z"
              stroke="#273947"
              stroke-width="4"
              stroke-linecap="round"
              stroke-linejoin="round"
            />
          </svg>
          <a :href="'mailto:' + contacts.email">{{ contacts.email }}</a>
        </div>

        <div class="contact">
          <svg class="contact__icon" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M50 25C50 38.8071 38.8071 50 25 50M50 25C50 11.1929 38.8071 0 25 0M50 25H0M25 50C11.1929 50 0 38.8071 0 25M25 50C18.5806 43.2596 15 34.3081 15 25C15 15.6919 18.5806 6.74038 25 0M25 50C31.4194 43.2596 35 34.3081 35 25C35 15.6919 31.4194 6.74038 25 0M0 25C0 11.1929 11.1929 0 25 0"
              stroke="#273947"
              stroke-width="4"
              stroke-linecap="round"
              stroke-linejoin="round"
            />
          </svg>
          <a :href="'https://' + contacts.site" target="_blank" rel="noopener">{{ contacts.site }}</a>
        </div>

        <div class="contact">
          <svg class="contact__icon" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M29.58 36.42C30.0963 36.6571 30.678 36.7113 31.2292 36.5736C31.7805 36.4359 32.2683 36.1146 32.6125 35.6625L33.5 34.5C33.9657 33.879 34.5697 33.375 35.2639 33.0279C35.9582 32.6807 36.7238 32.5 37.5 32.5H45C46.3261 32.5 47.5979 33.0268 48.5355 33.9645C49.4732 34.9021 50 36.1739 50 37.5V45C50 46.3261 49.4732 47.5979 48.5355 48.5355C47.5979 49.4732 46.3261 50 45 50C33.0653 50 21.6193 45.2589 13.1802 36.8198C4.74106 28.3807 0 16.9347 0 5C0 3.67392 0.526784 2.40215 1.46447 1.46447C2.40215 0.526784 3.67392 0 5 0H12.5C13.8261 0 15.0979 0.526784 16.0355 1.46447C16.9732 2.40215 17.5 3.67392 17.5 5V12.5C17.5 13.2762 17.3193 14.0418 16.9721 14.7361C16.625 15.4303 16.121 16.0343 15.5 16.5L14.33 17.3775C13.871 17.7279 13.5475 18.2265 13.4145 18.7884C13.2814 19.3503 13.347 19.9409 13.6 20.46C17.0167 27.3997 22.6361 33.012 29.58 36.42Z"
              stroke="#273947"
              stroke-width="4"
              stroke-linecap="round"
              stroke-linejoin="round"
            />
          </svg>
          <a :href="'tel:' + contacts.phone.replace(/[^\d+]/g, '')">{{ contacts.phone }}</a>
        </div>

        <div class="contact">
          <svg class="contact__icon contact__icon--pin" viewBox="0 0 40 50" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M40 20.0003C40 32.4829 26.1525 45.4831 21.5025 49.4981C21.0693 49.8239 20.542 50 20 50C19.458 50 18.9307 49.8239 18.4975 49.4981C13.8475 45.4831 0 32.4829 0 20.0003C0 14.6959 2.10714 9.60871 5.85786 5.85794C9.60859 2.10716 14.6957 0 20 0C25.3043 0 30.3914 2.10716 34.1421 5.85794C37.8929 9.60871 40 14.6959 40 20.0003Z"
              stroke="#273947"
              stroke-width="4"
              stroke-linecap="round"
              stroke-linejoin="round"
            />
            <path
              d="M20 27.5003C24.1421 27.5003 27.5 24.1424 27.5 20.0003C27.5 15.8581 24.1421 12.5002 20 12.5002C15.8579 12.5002 12.5 15.8581 12.5 20.0003C12.5 24.1424 15.8579 27.5003 20 27.5003Z"
              stroke="#273947"
              stroke-width="4"
              stroke-linecap="round"
              stroke-linejoin="round"
            />
          </svg>
          <span>{{ contacts.address }}</span>
        </div>
      </div>
    </section>
  </div>
</template>

<script>
import CtaButton from '@/components/CtaButton.vue'
import CheckItem from '@/components/CheckItem.vue'
import LeadForm from '@/components/LeadForm.vue'
import SocialLinks from '@/components/SocialLinks.vue'
import { images, accepted, benefits, steps, specs, contacts } from '@/data/content'

export default {
  name: 'RecyclingView',
  components: { CtaButton, CheckItem, LeadForm, SocialLinks },
  data() {
    return { images, accepted, benefits, steps, specs, contacts }
  },
}
</script>

<style scoped lang="scss">
.hero {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  min-height: u(1337);
  padding: u(201) u(169) u(145) u(145);
  color: #fff;
  overflow: hidden;
  background: #1a2733;

  @include mobile {
    min-height: u(1100);
    padding: u(220) u(40) u(80);
  }

  &__bg {
    position: absolute;
    left: 0;
    width: 100%;
    max-width: none;
    object-fit: cover;
    object-position: center top;
    pointer-events: none;

    &--house {
      top: 0;
      height: u(1081);
    }

    &--machine {
      top: 0;
      height: 100%;
    }
  }

  &__social {
    position: absolute;
    left: u(60);
    top: u(437);
    z-index: 2;

    @include mobile {
      top: auto;
      bottom: u(60);
      left: u(40);
      flex-direction: row;
      gap: u(20);
    }
  }

  &__content {
    position: relative;
    z-index: 1;
    align-self: stretch;
  }

  &__title {
    margin: 0;
    font-size: u(100);
    font-weight: 600;
    line-height: 0.9;
    letter-spacing: u(-5);
    text-transform: uppercase;
    @include mobile {
      font-size: u(88);
      letter-spacing: u(-3);
    }
  }

  &__text {
    max-width: u(650);
    margin: u(31) 0 0;
    font-size: u(24);
    line-height: 0.9;
    letter-spacing: u(-0.72);
    @include mobile {
      font-size: u(30);
      line-height: 1.1;
    }
  }

  &__cta {
    position: relative;
    z-index: 1;
    margin-top: auto;
  }
}

.heading {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  max-width: u(855);
  margin: 0 auto;
  padding: 0;

  &__sub {
    max-width: u(754);
    margin: u(20) 0 0;
    text-align: center;
    font-size: u(24);
    line-height: 0.9;
    letter-spacing: u(-0.72);
    @include mobile {
      font-size: u(30);
      line-height: 1.15;
    }
  }

  &--plain {
    padding: 0;
  }

  &__line {
    position: absolute;
    top: u(38);
    height: 2px;
    width: u(304);
    background: $navy;
    @include mobile {
      display: none;
    }

    &--left {
      right: calc(100% + #{u(23)});
    }

    &--right {
      left: calc(100% + #{u(22)});
    }
  }
}

.intro {
  padding: u(69) 0 0;
}

.cards {
  display: grid;
  grid-template-columns: repeat(2, u(824));
  justify-content: center;
  gap: u(70);
  margin-top: u(60);
  padding: 0 u(40);

  @include mobile {
    grid-template-columns: 1fr;
    gap: u(40);
  }
}

.card {
  position: relative;
  min-height: u(370);
  padding: u(38) u(40) u(38) u(106);
  border: 2px solid #aaa;
  border-radius: u(80);
  box-sizing: border-box;
  overflow: hidden;

  @include mobile {
    padding-right: u(40);
  }

  &__list {
    position: relative;
    z-index: 1;
    margin: 0;
    padding: 0;
    font-size: u(24);
    line-height: 2;
    letter-spacing: u(-0.72);
    text-transform: uppercase;

    @include desktop {
      white-space: nowrap;
    }
  }

  &__title {
    min-height: u(48);
    list-style: none;
    font-weight: 600;
  }

  &__img {
    position: absolute;
    max-width: none;

    @include mobile {
      display: none;
    }

    &--shredder {
      left: u(522);
      top: u(22);
      width: u(248);
      height: u(314);
    }

    &--mini {
      left: u(541);
      top: u(74);
      width: u(280);
      height: u(221);
    }
  }

  &__glow {
    position: absolute;
    left: u(546);
    top: u(53);
    width: u(259);
    height: u(251);
    border-radius: 50%;
    background: #9dd77c;
    filter: blur(37px);

    @include mobile {
      display: none;
    }
  }
}

.process {
  padding-top: u(74);
}

.steps {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: u(20);
  max-width: u(1740);
  margin: u(60) auto 0;
  padding: 0 u(40);
  box-sizing: border-box;

  @include mobile {
    flex-direction: column;
    align-items: center;
    gap: u(40);
  }

  &__arrow {
    flex: none;
    width: u(81);
    height: u(76);
    margin-top: u(194);

    @include mobile {
      margin-top: 0;
      transform: rotate(90deg);
    }
  }
}

.step {
  display: flex;
  flex-direction: column;
  align-items: center;
  margin: 0;

  &__media {
    display: flex;
    align-items: flex-start;
    justify-content: center;
    height: u(464);
    width: 100%;
    max-width: u(550);

    img {
      display: block;
      max-width: 100%;
      height: auto;
    }
  }

  &--1 .step__media {
    width: u(418);
  }

  &--2 .step__media {
    width: u(418);
  }

  &--3 .step__media {
    width: u(549);
    padding-top: u(39);
    box-sizing: border-box;
  }

  &__caption {
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-top: u(46);
    text-align: center;
    font-size: u(40);
    font-weight: 600;
    line-height: 0.9;
    letter-spacing: u(-1.2);
    @include mobile {
      font-size: u(44);
    }
  }
}

.specs {
  margin-top: u(80);

  &__box {
    position: relative;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    gap: u(60);
    max-width: u(1606);
    min-height: u(1245);
    margin: 0 auto;
    padding: u(101) u(85) u(49);
    border-radius: u(80);
    box-sizing: border-box;
    overflow: hidden;
    color: #fff;
    background: #14202b;

    @include mobile {
      min-height: 0;
      margin: 0 u(30);
      padding: u(60) u(30) u(60);
      padding-top: u(500);
    }
  }

  &__bg {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
    z-index: 0;
  }

  &__grid {
    position: relative;
    z-index: 1;
    display: grid;
    grid-template-columns: repeat(4, u(280));
    justify-content: space-between;
    gap: u(30);

    @include mobile {
      grid-template-columns: repeat(2, 1fr);
    }
  }

  &__text {
    position: relative;
    z-index: 1;
    max-width: u(1342);
    margin: 0 auto;
    padding-bottom: u(0);
    text-align: center;
    font-size: u(24);
    line-height: 1.2;
    letter-spacing: u(-1.2);
    @include mobile {
      font-size: u(30);
    }
  }

  &__form {
    margin-top: u(88);
  }
}

.spec {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: u(31);
  height: u(180);
  padding: 0 u(20);
  border-radius: u(30);
  background: rgba(255, 255, 255, 0.1);
  text-align: center;
  box-sizing: border-box;

  @include mobile {
    height: auto;
    min-height: u(180);
    padding: u(30) u(20);
  }

  &__value {
    font-size: u(40);
    line-height: 0.9;
    letter-spacing: u(-1.2);

    &--bold {
      font-weight: 600;
    }
  }

  &__label {
    font-size: u(24);
    line-height: 0.9;
    letter-spacing: u(-0.72);

    &--bold {
      font-weight: 600;
    }
    @include mobile {
      font-size: u(28);
    }
  }
}

.contacts {
  padding-top: u(100);

  &__grid {
    display: grid;
    grid-template-columns: u(799) auto;
    justify-content: center;
    gap: u(57) 0;
    margin-top: u(100);
    padding: 0 u(40);

    @include mobile {
      grid-template-columns: 1fr;
      justify-items: start;
      padding: 0 u(60);
    }
  }
}

.heading--contacts {
  max-width: none;

  .heading__line {
    top: 50%;
  }

  .heading__line--left {
    right: calc(50% + #{u(156 + 90)});
  }

  .heading__line--right {
    left: calc(50% + #{u(156 + 90)});
  }
}

.contact {
  display: flex;
  align-items: center;
  gap: u(20);
  min-height: u(50);
  font-size: u(24);
  letter-spacing: u(-0.72);

  @include mobile {
    font-size: u(30);
  }

  &__icon {
    flex: none;
    height: u(50);
    width: auto;
    max-width: u(63);
  }

  a {
    color: inherit;
    text-decoration: none;

    &:hover {
      text-decoration: underline;
    }
  }
}
</style>
