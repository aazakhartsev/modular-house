<template>
  <section class="placeholder">
    <h1 class="placeholder__title">{{ title }}</h1>
    <p class="placeholder__text">
      Цей розділ ще не заповнено. Продовжуйте формулювати запити, щоб ми створили його вміст.
    </p>
    <CtaButton to="/">На головну</CtaButton>
  </section>
</template>

<script>
import CtaButton from '@/components/CtaButton.vue'

export default {
  name: 'PlaceholderView',
  components: { CtaButton },
  computed: {
    title() {
      return this.$route.meta.title || ''
    },
  },
}
</script>

<style scoped lang="scss">
.placeholder {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: u(40);
  min-height: u(900);
  background: $navy;
  color: #fff;
  padding: u(200) u(40) u(100);
  text-align: center;

  &__title {
    margin: 0;
    font-size: u(70);
    font-weight: 600;
    letter-spacing: u(-2.1);
  }

  &__text {
    max-width: u(754);
    margin: 0;
    font-size: u(24);
    letter-spacing: u(-0.72);
  }
}
</style>
