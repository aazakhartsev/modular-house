import { createRouter, createWebHistory } from 'vue-router'
import DefaultLayout from '@/layouts/DefaultLayout.vue'
import RecyclingView from '@/views/RecyclingView.vue'
import PlaceholderView from '@/views/PlaceholderView.vue'

const routes = [
  {
    path: '/',
    component: DefaultLayout,
    children: [
      { path: '', name: 'recycling', component: RecyclingView },
      { path: 'houses', name: 'houses', component: PlaceholderView, meta: { title: 'Будинки' } },
      { path: 'biogas', name: 'biogas', component: PlaceholderView, meta: { title: 'Біогаз' } },
      { path: ':pathMatch(.*)*', name: 'not-found', component: PlaceholderView, meta: { title: 'Сторінку не знайдено' } },
    ],
  },
]

export default createRouter({
  history: createWebHistory(),
  routes,
  scrollBehavior(to, from, saved) {
    if (to.hash) return { el: to.hash, behavior: 'smooth' }
    return saved || { top: 0 }
  },
})
