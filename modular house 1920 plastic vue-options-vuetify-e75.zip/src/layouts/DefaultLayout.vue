<template>
  <div class="layout">
    <AppHeader />
    <v-main class="layout__main">
      <router-view />
    </v-main>
    <AppFooter />
  </div>
</template>

<script>
import AppHeader from '@/components/AppHeader.vue'
import AppFooter from '@/components/AppFooter.vue'

export default {
  name: 'DefaultLayout',
  components: { AppHeader, AppFooter },
}
</script>

<style scoped lang="scss">
.layout {
  position: relative;
  max-width: 1920px;
  margin: 0 auto;
  width: 100%;

  &__main {
    padding: 0 !important;
  }
}
</style>
