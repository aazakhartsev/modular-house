const img = (id, w) => 'https://api.builder.io/api/v1/image/assets/TEMP/' + id + '?width=' + w

export const images = {
  house: img('1e415f64ee91b9107767d73290c9ff37c405e1d8', 4088),
  machine: img('77a9d23185978043e60e4fd343a1ce4c458129e0', 3862),
  logo: img('b9a4b1bc70dc4e03407d2bed8c7b3d6f9ebf7c18', 450),
  shredder: img('afccea38b8893ad0a292d386aa33fd750bb0f28b', 496),
  miniMachine: img('3a2e87c231e8ef9d58f96790204dc14dbbc9b2e1', 560),
  step1: img('c992cc07e8c1b95246c4b51e5e36c56a5eab0f34', 836),
  step2: img('e88cd26ba0689be9bbcf1edb0af1ca7162275127', 836),
  step3: img('00ee7512551da748d95930408d3df8e295d5cc83', 1098),
  specs: img('0aa07a1ffd08e93d3ebb3f25dfb01ba73ddeb6d0', 3212),
  footer: img('90c0c1266ac86a77d4df5acfa08d2660f6e05b0e', 3846),
}

export const navLinks = [
  { label: 'Будинки', to: '/houses' },
  { label: 'Біогаз', to: '/biogas' },
  { label: 'переробка', to: '/' },
  { label: 'контакти', to: '/#contacts' },
]

export const footerLinks = [
  { label: 'Будинки', to: '/houses' },
  { label: 'Генерація', to: '/biogas' },
  { label: 'Утилізація', to: '/' },
  { label: 'контакти', to: '/#contacts' },
]

export const accepted = {
  title: 'Що переробляє?',
  items: [
    'ПЕТ-пляшки (вода, напої)',
    'HDPE-каністри та ємності',
    'Пластикові пакети та плівка',
    'Пінопласт і пінополістирол',
    'Жорстке пакування (контейнери)',
  ],
}

export const benefits = {
  title: 'Переваги в будинку',
  items: [
    "Зменшує об'єм сміття до 10 разів",
    'Немає запаху — закрита камера',
    'Флекс здають переробникам за гроші',
    'Вбудовано в техзону — не займає місця',
    'Мінімальне обслуговування',
  ],
}

export const steps = [
  { image: images.step1, caption: ['Завантаження', 'пластику в бункер'] },
  { image: images.step2, caption: ['Різання', 'подрібненим валом'] },
  { image: images.step3, caption: ['На виході', 'флекс гранулят'] },
]

export const specs = [
  { value: '1', label: 'робочий вал (ротор)', bold: true },
  { value: '3-фаз', label: 'індукційний двигун', bold: true },
  { value: 'CE', label: 'сертифікація EU' },
  { value: '24/7', label: 'безперервна робота' },
]

export const contacts = {
  phone: '+38 (044) 502 2888',
  mainPhone: '+38 (067) 209 2790',
  email: 'info@servionica.com',
  site: 'www.servionica.com',
  address: 'вул. Ігоря Сікорського 1, м. Київ, 04112',
}
