import { createStore } from 'vuex'
import ui from './modules/ui'
import leads from './modules/leads'

export default createStore({ modules: { ui, leads } })
