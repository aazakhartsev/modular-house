export default {
  namespaced: true,
  state: () => ({ submitting: false, submitted: false, error: '' }),
  mutations: {
    SET_SUBMITTING(state, value) {
      state.submitting = value
    },
    SET_SUBMITTED(state, value) {
      state.submitted = value
    },
    SET_ERROR(state, value) {
      state.error = value
    },
  },
  actions: {
    async submit({ commit }, payload) {
      commit('SET_ERROR', '')
      commit('SET_SUBMITTED', false)
      if (!payload.name.trim() || payload.phone.replace(/\D/g, '').length < 10) {
        commit('SET_ERROR', 'Вкажіть імʼя та коректний номер телефону')
        return
      }
      commit('SET_SUBMITTING', true)
      await new Promise((resolve) => setTimeout(resolve, 600))
      commit('SET_SUBMITTING', false)
      commit('SET_SUBMITTED', true)
    },
  },
}
