import { createStore } from 'vuex'
import ui from './modules/ui'
import calculator from './modules/calculator'
import contact from './modules/contact'

export default createStore({
  modules: { ui, calculator, contact },
})
