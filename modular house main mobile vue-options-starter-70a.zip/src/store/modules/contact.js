export default {
  namespaced: true,
  state: () => ({
    name: '',
    phone: '',
    submitted: false,
  }),
  mutations: {
    SET_FIELD(state, { key, value }) {
      state[key] = value
      state.submitted = false
    },
    SET_SUBMITTED(state, value) {
      state.submitted = value
    },
    RESET(state) {
      state.name = ''
      state.phone = ''
    },
  },
  actions: {
    submit({ commit, state }) {
      if (!state.name.trim() || state.phone.replace(/\D/g, '').length < 12) return false
      commit('RESET')
      commit('SET_SUBMITTED', true)
      return true
    },
  },
}
