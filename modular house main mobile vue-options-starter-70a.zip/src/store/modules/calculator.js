const BASE_AREA = 62.5
const MODULE_AREA = 27

export default {
  namespaced: true,
  state: () => ({
    modules: 1,
    phases: 1,
    voltage: 'low',
    inverterPower: 6,
    batteryCapacity: 40,
    panelsCapacity: 51,
  }),
  getters: {
    totalArea: (state) => BASE_AREA + state.modules * MODULE_AREA,
    price(state, getters) {
      const raw =
        getters.totalArea * 300 +
        state.inverterPower * 100 +
        state.batteryCapacity * 50 +
        state.panelsCapacity * 47 +
        (state.phases === 3 ? 800 : 0) +
        (state.voltage === 'high' ? 1200 : 0)
      return Math.round(raw / 50) * 50
    },
    formattedPrice: (state, getters) =>
      new Intl.NumberFormat('uk-UA').format(getters.price).replace(/\u00a0/g, ' '),
    formattedArea: (state, getters) => String(getters.totalArea).replace('.', ','),
  },
  mutations: {
    SET_FIELD(state, { key, value }) {
      state[key] = value
    },
    SET_MODULES(state, value) {
      state.modules = Math.max(0, Math.min(10, value))
    },
  },
  actions: {
    setField({ commit }, payload) {
      commit('SET_FIELD', payload)
    },
    changeModules({ commit, state }, delta) {
      commit('SET_MODULES', state.modules + delta)
    },
  },
}
