export default {
  namespaced: true,
  state: () => ({
    menuOpen: false,
  }),
  mutations: {
    SET_MENU(state, value) {
      state.menuOpen = value
    },
  },
  actions: {
    toggleMenu({ commit, state }) {
      commit('SET_MENU', !state.menuOpen)
    },
    closeMenu({ commit }) {
      commit('SET_MENU', false)
    },
  },
}
