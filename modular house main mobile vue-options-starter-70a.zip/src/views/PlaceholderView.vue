<template>
  <section class="placeholder">
    <h1 class="placeholder__title">{{ title }}</h1>
    <p class="placeholder__text">
      Цю сторінку ще не наповнено. Продовжуйте формувати запити, щоб ми створили її вміст.
    </p>
    <v-btn to="/" color="primary" rounded="pill" size="large">На головну</v-btn>
  </section>
</template>

<script>
export default {
  name: 'PlaceholderView',
  computed: {
    title() {
      return this.$route.meta.title || 'Сторінка'
    },
  },
}
</script>

<style lang="scss" scoped>
@use '@/styles/variables' as *;
@use '@/styles/mixins' as *;

.placeholder {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 20px;
  min-height: 60vh;
  padding: 60px 20px;
  text-align: center;

  &__title {
    @include gradient-text;
    margin: 0;
    font-size: 32px;
    font-weight: 600;
    letter-spacing: -0.03em;
  }

  &__text {
    max-width: 380px;
    margin: 0;
    font-size: 16px;
    letter-spacing: -0.03em;
  }
}
</style>
