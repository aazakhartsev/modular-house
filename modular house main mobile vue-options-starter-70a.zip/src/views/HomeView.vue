<template>
  <div class="home">
    <hero-section />
    <growing-house />
    <modular-banner />
    <interior-section />
    <insulation-section />
    <sip-section />
    <foundation-section />
    <windows-section />
    <energy-hub-section />
    <house-name-section />
    <calculator-section />
    <characteristics-section />
    <contacts-section />
  </div>
</template>

<script>
import HeroSection from '@/components/home/HeroSection.vue'
import GrowingHouse from '@/components/home/GrowingHouse.vue'
import ModularBanner from '@/components/home/ModularBanner.vue'
import InteriorSection from '@/components/home/InteriorSection.vue'
import InsulationSection from '@/components/home/InsulationSection.vue'
import SipSection from '@/components/home/SipSection.vue'
import FoundationSection from '@/components/home/FoundationSection.vue'
import WindowsSection from '@/components/home/WindowsSection.vue'
import EnergyHubSection from '@/components/home/EnergyHubSection.vue'
import HouseNameSection from '@/components/home/HouseNameSection.vue'
import CalculatorSection from '@/components/home/CalculatorSection.vue'
import CharacteristicsSection from '@/components/home/CharacteristicsSection.vue'
import ContactsSection from '@/components/home/ContactsSection.vue'

export default {
  name: 'HomeView',
  components: {
    HeroSection,
    GrowingHouse,
    ModularBanner,
    InteriorSection,
    InsulationSection,
    SipSection,
    FoundationSection,
    WindowsSection,
    EnergyHubSection,
    HouseNameSection,
    CalculatorSection,
    CharacteristicsSection,
    ContactsSection,
  },
}
</script>
