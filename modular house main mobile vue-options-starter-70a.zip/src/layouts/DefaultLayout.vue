<template>
  <div class="layout">
    <app-header />
    <v-main class="layout__main">
      <router-view />
    </v-main>
    <app-footer />
  </div>
</template>

<script>
import AppHeader from '@/components/common/AppHeader.vue'
import AppFooter from '@/components/common/AppFooter.vue'

export default {
  name: 'DefaultLayout',
  components: { AppHeader, AppFooter },
}
</script>

<style lang="scss" scoped>
.layout {
  position: relative;
  overflow-x: clip;

  &__main { padding: 0 !important; }
}
</style>
