import 'vuetify/styles'
import { createVuetify } from 'vuetify'

export default createVuetify({
  theme: {
    defaultTheme: 'servionica',
    themes: {
      servionica: {
        dark: false,
        colors: {
          primary: '#273947',
          secondary: '#476587',
          accent: '#45E5FF',
          background: '#FFFFFF',
          surface: '#FFFFFF',
        },
      },
    },
  },
  defaults: {
    VBtn: { elevation: 0 },
  },
})
