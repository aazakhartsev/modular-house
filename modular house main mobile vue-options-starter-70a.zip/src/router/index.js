import { createRouter, createWebHistory } from 'vue-router'
import DefaultLayout from '@/layouts/DefaultLayout.vue'
import HomeView from '@/views/HomeView.vue'
import PlaceholderView from '@/views/PlaceholderView.vue'

const routes = [
  {
    path: '/',
    component: DefaultLayout,
    children: [
      { path: '', name: 'home', component: HomeView, meta: { transparentHeader: true } },
      {
        path: 'generation',
        name: 'generation',
        component: PlaceholderView,
        meta: { title: 'Генерація' },
      },
      {
        path: 'utilization',
        name: 'utilization',
        component: PlaceholderView,
        meta: { title: 'Утилізація' },
      },
      {
        path: ':pathMatch(.*)*',
        name: 'not-found',
        component: PlaceholderView,
        meta: { title: 'Сторінку не знайдено' },
      },
    ],
  },
]

export default createRouter({
  history: createWebHistory(),
  routes,
  scrollBehavior(to) {
    if (to.hash) return { el: to.hash, behavior: 'smooth' }
    return { top: 0 }
  },
})
