<template>
  <section id="contacts" class="contacts">
    <section-title>Контакти</section-title>

    <ul class="contacts__list">
      <li v-for="item in items" :key="item.text" class="contacts__item">
        <v-icon :icon="item.icon" size="40" class="contacts__icon" />
        <a v-if="item.href" :href="item.href" :target="item.external ? '_blank' : undefined" rel="noopener">{{ item.text }}</a>
        <span v-else>{{ item.text }}</span>
      </li>
    </ul>
  </section>
</template>

<script>
import SectionTitle from '@/components/common/SectionTitle.vue'

export default {
  name: 'ContactsSection',
  components: { SectionTitle },
  data() {
    return {
      items: [
        { icon: 'mdi-phone-outline', text: '+38 (044) 502 2888', href: 'tel:+380445022888' },
        { icon: 'mdi-email-outline', text: 'info@servionica.com', href: 'mailto:info@servionica.com' },
        { icon: 'mdi-map-marker-outline', text: 'вул. Ігоря Сікорського 1, м. Київ, 04112' },
        { icon: 'mdi-web', text: 'www.servionica.com', href: 'https://www.servionica.com', external: true },
      ],
    }
  },
}
</script>

<style lang="scss" scoped>
@use '@/styles/variables' as *;
@use '@/styles/mixins' as *;

.contacts {
  @include stage;
  max-width: 560px;
  padding: 80px 20px 60px;

  :deep(.section-title__line) { max-width: 107px; }

  &__list {
    display: flex;
    flex-direction: column;
    gap: 20px;
    margin: 36px 0 0;
    padding: 0 0 0 4px;
    list-style: none;
  }

  &__item {
    display: flex;
    align-items: center;
    gap: 20px;
    font-size: 20px;
    letter-spacing: -0.03em;
    line-height: 1.2;

    a { color: inherit; text-decoration: none; }
  }

  &__icon { flex: none; width: 40px; color: $navy; }
}
</style>
