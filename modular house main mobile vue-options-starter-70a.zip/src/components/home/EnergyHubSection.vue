<template>
  <section id="generation" class="hub">
    <section-title subtitle="Повна автономність у Вашому будинку. Сонячне світло перетворюється на цілодобову електроенергію.">
      Сучасний енергетиний хаб
    </section-title>

    <div class="hub__scene">
      <img class="hub__house" :src="images.solarHouse" alt="Будинок з сонячними панелями" />

      <svg class="hub__lines" viewBox="0 0 390 272" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M96 99L169 8M255 87L294 97" stroke="#fff" />
        <circle cx="169" cy="8" r="2" fill="#fff" />
        <circle cx="294" cy="97" r="2" fill="#fff" />
      </svg>

      <div class="hub__node hub__node--inverter">
        <span class="hub__glow" />
        <img class="hub__pedestal" :src="images.postamentInverter" alt="" />
        <img class="hub__product hub__product--accum" :src="images.accumulator" alt="" />
        <img class="hub__product hub__product--inverter" :src="images.inverter" alt="" />
        <span class="hub__node-label">Інвертор з системою накопичення</span>
      </div>

      <div class="hub__node hub__node--sun">
        <span class="hub__glow" />
        <img class="hub__pedestal" :src="images.postamentSun" alt="" />
        <img class="hub__product hub__product--panel2" :src="images.sunPanel2" alt="" />
        <img class="hub__product hub__product--panel1" :src="images.sunPanel1" alt="" />
        <span class="hub__node-label">Сонячні панелі</span>
      </div>
    </div>

    <ul class="hub__stats">
      <li v-for="s in stats" :key="s.label">
        <strong>{{ s.value }}</strong>
        <span>{{ s.label }}</span>
      </li>
    </ul>
  </section>
</template>

<script>
import images from '@/assets/images'
import SectionTitle from '@/components/common/SectionTitle.vue'

export default {
  name: 'EnergyHubSection',
  components: { SectionTitle },
  data() {
    return {
      images,
      stats: [
        { value: '12 кВТ', label: 'Потужність гібридного інвертора' },
        { value: '112.5 кВт/год', label: 'Ємність акумуляторних батарей' },
        { value: '12 кВт', label: 'пікова потужність сонячних панелей' },
      ],
    }
  },
}
</script>

<style lang="scss" scoped>
@use '@/styles/variables' as *;
@use '@/styles/mixins' as *;

.hub {
  @include stage;
  max-width: 560px;
  padding: 50px 20px 40px;

  :deep(.section-title__text) { max-width: 229px; }
  :deep(.section-title__subtitle) { max-width: 303px; }

  &__scene {
    position: relative;
    margin: 18px -20px 0;
    aspect-ratio: 390 / 272;
    overflow: hidden;
    background: #0e1e28;
  }

  &__house {
    position: absolute;
    top: 0;
    left: -11%;
    width: 121.5%;
    height: 100%;
    object-fit: cover;
  }

  &__lines { position: absolute; inset: 0; width: 100%; height: 100%; }

  &__node {
    position: absolute;
    top: 0;
    width: 26.2%;
    aspect-ratio: 1;
    border: 0.5px solid #fff;
    border-radius: 50%;
    background: #0e1e28;
    overflow: hidden;
    color: #000;
    text-align: center;

    &--inverter { left: 13.8%; top: 2.2%; }
    &--sun { left: 55.4%; top: -1.5%; }
  }

  &__glow {
    position: absolute;
    inset: 17%;
    border-radius: 50%;
    background: #d9d9d9;
    filter: blur(7px);
  }

  &__pedestal { position: absolute; left: 10%; bottom: -3%; width: 82%; height: auto; }
  &__product { position: absolute; height: auto; }
  &__product--accum { width: 43%; left: 36%; top: 6%; }
  &__product--inverter { width: 36%; left: 20%; top: 12%; }
  &__product--panel2 { width: 38%; left: 38%; top: 10%; }
  &__product--panel1 { width: 38%; left: 18%; top: 16%; }

  &__node-label {
    position: absolute;
    left: 50%;
    bottom: 14%;
    width: 70%;
    transform: translateX(-50%);
    font-size: 8px;
    line-height: 0.9;
    letter-spacing: -0.03em;
  }

  &__stats {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 18px;
    margin: -66px -20px 0;
    padding: 0 20px;
    position: relative;
    list-style: none;
    color: #fff;

    li {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 62px;
      padding: 8px 5px;
      border-radius: 9px;
      background: rgba(255, 255, 255, 0.1);
      backdrop-filter: blur(2px);
      font-size: 12px;
      line-height: 0.9;
      letter-spacing: -0.03em;
      text-align: center;
    }
    strong { margin-bottom: 6px; font-weight: 600; }
  }
}
</style>
