<template>
  <section class="sip">
    <section-title subtitle="По тепловтраті дорівнює 1,5 м цегляної стіни">Переваги СІП-панелей</section-title>

    <div class="sip__frame">
      <svg class="sip__border" viewBox="0 0 372 331" fill="none" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M332.5 0H352C363.046 0 372 8.95431 372 20V311C372 322.046 363.046 331 352 331H20C8.95431 331 0 322.046 0 311V20C0 8.9543 8.95431 0 20 0H38" stroke="url(#sipGrad)" vector-effect="non-scaling-stroke" />
        <defs>
          <linearGradient id="sipGrad" x1="186" y1="0" x2="186" y2="331" gradientUnits="userSpaceOnUse">
            <stop stop-color="#273947" />
            <stop offset="1" stop-color="#476587" />
          </linearGradient>
        </defs>
      </svg>
      <img class="sip__brick" :src="images.sipBrick" alt="" />

      <div class="sip__cards">
        <div class="sip__card">
          <svg width="16" height="21" viewBox="0 0 16 21" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M5 10.4987L7 12.5984L11 8.39906M16 11.5485C16 16.7977 12.5 19.4222 8.34 20.9445C8.12216 21.022 7.88554 21.0183 7.67 20.934C3.5 19.4222 0 16.7977 0 11.5485V4.19977C0 3.92134 0.105357 3.65431 0.292893 3.45743C0.48043 3.26055 0.734784 3.14994 1 3.14994C3 3.14994 5.5 1.89016 7.24 0.294423C7.45185 0.104403 7.72135 0 8 0C8.27865 0 8.54815 0.104403 8.76 0.294423C10.51 1.90065 13 3.14994 15 3.14994C15.2652 3.14994 15.5196 3.26055 15.7071 3.45743C15.8946 3.65431 16 3.92134 16 4.19977V11.5485Z" stroke="#273947" stroke-width="1.87" stroke-linecap="round" stroke-linejoin="round" />
          </svg>
          <div>
            <strong class="sip__value">220 мм</strong>
            <span class="sip__caption">Товщина панелі</span>
          </div>
        </div>
        <div class="sip__card sip__card--brown">
          <svg width="16" height="21" viewBox="0 0 16 21" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M5 10.4987L7 12.5984L11 8.39907M16 11.5485C16 16.7977 12.5 19.4222 8.34 20.9445C8.12216 21.022 7.88554 21.0183 7.67 20.934C3.5 19.4222 0 16.7977 0 11.5485V4.19977C0 3.92134 0.105357 3.65431 0.292893 3.45743C0.48043 3.26055 0.734784 3.14994 1 3.14994C3 3.14994 5.5 1.89016 7.24 0.294423C7.45185 0.104403 7.72135 0 8 0C8.27865 0 8.54815 0.104403 8.76 0.294423C10.51 1.90065 13 3.14994 15 3.14994C15.2652 3.14994 15.5196 3.26055 15.7071 3.45743C15.8946 3.65431 16 3.92134 16 4.19977V11.5485Z" stroke="#67351A" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
          </svg>
          <div>
            <strong class="sip__value">1540 мм</strong>
            <span class="sip__caption">Товщина цегляної стіни</span>
          </div>
        </div>
      </div>
    </div>

    <ul class="sip__badges">
      <li v-for="badge in badges" :key="badge.text" class="sip__badge">
        <span class="sip__badge-icon" :style="{ '--tone': badge.tone, '--border': badge.border }">
          <v-icon :icon="badge.icon" size="18" :color="badge.color" />
        </span>
        <span>{{ badge.text }}</span>
      </li>
    </ul>
  </section>
</template>

<script>
import images from '@/assets/images'
import SectionTitle from '@/components/common/SectionTitle.vue'

export default {
  name: 'SipSection',
  components: { SectionTitle },
  data() {
    return {
      images,
      badges: [
        {
          text: 'Зберігає тепло взимку',
          icon: 'mdi-home-outline',
          color: '#273947',
          tone: 'rgba(100, 168, 220, 0.2)',
          border: 'linear-gradient(180deg, #273947, #476587)',
        },
        {
          text: 'Екологічно та безпечно',
          icon: 'mdi-leaf',
          color: '#227259',
          tone: 'rgba(100, 220, 120, 0.2)',
          border: 'linear-gradient(180deg, #227259, #48DCB1)',
        },
        {
          text: 'Швидке будівництво',
          icon: 'mdi-timer-outline',
          color: '#67351A',
          tone: 'rgba(221, 130, 72, 0.2)',
          border: 'linear-gradient(180deg, #67351A, #DD8248)',
        },
      ],
    }
  },
}
</script>

<style lang="scss" scoped>
@use '@/styles/variables' as *;
@use '@/styles/mixins' as *;

.sip {
  @include stage;
  max-width: 560px;
  padding: 45px 9px 0;

  :deep(.section-title__line) { display: none; }

  &__frame {
    position: relative;
    height: 331px;
    margin-top: 12px;
  }

  &__border {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    stroke-width: 1px;
  }

  &__brick {
    position: absolute;
    top: 63px;
    left: -16px;
    width: calc(100% + 26px);
    max-width: 480px;
    height: auto;
    aspect-ratio: 399 / 180;
    object-fit: cover;
  }

  &__cards {
    position: absolute;
    bottom: 22px;
    left: 6px;
    right: 6px;
    display: flex;
    justify-content: space-between;
    gap: 8px;
  }

  &__card {
    display: flex;
    align-items: center;
    gap: 12px;
    width: 149px;
    height: 49px;
    padding: 0 8px 0 12px;
    border-radius: 11px;
    background: #fff;
    box-shadow: 2.5px 1.1px 1.1px rgba(0, 0, 0, 0.25);

    &--brown .sip__value { background: linear-gradient(180deg, #67351a, #dd8248); background-clip: text; -webkit-background-clip: text; }
  }

  &__value {
    display: block;
    font-size: 20px;
    font-weight: 600;
    line-height: 1.1;
    letter-spacing: -0.03em;
    background: $gradient;
    background-clip: text;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
  }

  &__caption {
    display: block;
    font-size: 10px;
    letter-spacing: -0.03em;
    line-height: 1.1;
  }

  &__badges {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    gap: 12px 8px;
    margin: 29px 0 0;
    padding: 0 0 0 7px;
    list-style: none;
  }

  &__badge {
    display: flex;
    align-items: center;
    gap: 5px;
    font-size: 12px;
    letter-spacing: -0.03em;
    line-height: 1.1;
    max-width: 120px;
  }

  &__badge-icon {
    display: grid;
    flex: none;
    place-items: center;
    width: 36px;
    height: 36px;
    border: 1px solid transparent;
    border-radius: 50%;
    background: linear-gradient(#fff, #fff) padding-box, var(--border) border-box;
    position: relative;

    &::after {
      content: '';
      position: absolute;
      inset: 3px;
      border-radius: 50%;
      background: var(--tone);
    }

    :deep(.v-icon) { position: relative; z-index: 1; }
  }
}
</style>
