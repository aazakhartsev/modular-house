<template>
  <section class="windows">
    <section-title subtitle="Технологія Rehau та Glas Trösch для затишку та економії.">
      Преміальні енергоефективні вікна
    </section-title>

    <div class="windows__visual">
      <img class="windows__img" :src="images.window" alt="Енергоефективне вікно" />
      <img class="windows__logo windows__logo--glas" :src="images.glasTrosch" alt="Glas Trösch" />
      <img class="windows__logo windows__logo--rehau" :src="images.rehau" alt="Rehau" />
      <img class="windows__argon" :src="images.argon" alt="" />
    </div>

    <ul class="windows__list">
      <li v-for="item in items" :key="item.text" class="windows__item">
        <span class="windows__icon" :style="{ '--ring': item.ring, '--tone': item.tone }">
          <v-icon :icon="item.icon" size="22" :color="item.color" />
        </span>
        <p>{{ item.text }}</p>
      </li>
    </ul>
  </section>
</template>

<script>
import images from '@/assets/images'
import SectionTitle from '@/components/common/SectionTitle.vue'

export default {
  name: 'WindowsSection',
  components: { SectionTitle },
  data() {
    return {
      images,
      items: [
        {
          text: 'Профіль Rehau Synego 86мм: 7-камерна система з терморозривом',
          icon: 'mdi-window-closed-variant',
          color: '#380091',
          ring: 'linear-gradient(180deg, #380091, #C09BFB)',
          tone: 'rgba(192, 155, 251, 0.2)',
        },
        {
          text: 'Система аргонопостачання: Постійне наповнення склопакетів аргоном.',
          icon: 'mdi-molecule',
          color: '#227259',
          ring: 'linear-gradient(180deg, #227259, #48DCB1)',
          tone: 'rgba(100, 220, 120, 0.2)',
        },
        {
          text: 'Склопакет Glas Trösch 50мм: Швейцарська якість',
          icon: 'mdi-layers-triple-outline',
          color: '#497EA8',
          ring: 'linear-gradient(180deg, #497EA8, #114D41)',
          tone: 'rgba(76, 129, 169, 0.2)',
        },
        {
          text: 'Економія тепла вдвічі: Зменшує тепловтрати, робить будинок теплішим.',
          icon: 'mdi-thermometer-low',
          color: '#EC7920',
          ring: 'linear-gradient(180deg, #EC7920, #EEBF9A)',
          tone: 'rgba(236, 121, 32, 0.2)',
        },
      ],
    }
  },
}
</script>

<style lang="scss" scoped>
@use '@/styles/variables' as *;
@use '@/styles/mixins' as *;

.windows {
  @include stage;
  max-width: 560px;
  padding: 30px 20px 40px;

  :deep(.section-title__text) { max-width: 213px; }
  :deep(.section-title__subtitle) { max-width: 249px; margin-top: 9px; }

  &__visual {
    position: relative;
    margin: 20px -2px 0;
    aspect-ratio: 355 / 222;
  }

  &__img { width: 100%; height: 100%; object-fit: cover; }

  &__logo { position: absolute; height: auto; }
  &__logo--glas { width: 34px; right: 7%; top: 11%; }
  &__logo--rehau { width: 33px; left: 7%; bottom: 8%; }

  &__argon {
    position: absolute;
    width: 26%;
    height: auto;
    left: 37%;
    bottom: -12%;
  }

  &__list {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 30px 20px;
    margin: 68px 0 0;
    padding: 0;
    list-style: none;
  }

  &__item {
    display: flex;
    flex-direction: column;
    gap: 6px;

    p { margin: 0; font-size: 16px; line-height: 1; letter-spacing: -0.05em; }
  }

  &__icon {
    position: relative;
    display: grid;
    place-items: center;
    width: 50px;
    height: 50px;
    border: 1px solid transparent;
    border-radius: 50%;
    background: linear-gradient(#fff, #fff) padding-box, var(--ring) border-box;

    &::after {
      content: '';
      position: absolute;
      inset: 5px;
      border-radius: 50%;
      background: var(--tone);
    }

    :deep(.v-icon) { position: relative; z-index: 1; }
  }
}
</style>
