<template>
  <section class="growing">
    <img class="growing__img" :src="images.growing" alt="Будинок який зростає" />
  </section>
</template>

<script>
import images from '@/assets/images'

export default {
  name: 'GrowingHouse',
  data() {
    return { images }
  },
}
</script>

<style lang="scss" scoped>
.growing {
  display: flex;
  justify-content: center;
  padding: 46px 15px 20px;

  &__img {
    width: 100%;
    max-width: 361px;
    height: auto;
    aspect-ratio: 361 / 577;
    object-fit: cover;
  }
}

@media (min-width: 700px) {
  .growing__img { max-width: 560px; }
}
</style>
