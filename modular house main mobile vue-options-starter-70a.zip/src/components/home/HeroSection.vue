<template>
  <section class="hero">
    <img class="hero__img" :src="images.hero" alt="Модульний енергонезалежний будинок Servionica" />
  </section>
</template>

<script>
import images from '@/assets/images'

export default {
  name: 'HeroSection',
  data() {
    return { images }
  },
}
</script>

<style lang="scss" scoped>
.hero {
  height: min(826px, calc(390px * 2.118));
  overflow: hidden;

  &__img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: center top;
  }
}

@media (min-width: 700px) {
  .hero { height: min(820px, 100vh); }
}
</style>
