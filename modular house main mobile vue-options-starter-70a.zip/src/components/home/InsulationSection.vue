<template>
  <section class="insulation">
    <section-title subtitle="Використовуємо виключно сертифіковані матеріали провідних європейських виробників">
      Супертеплий будинок
    </section-title>

    <div class="insulation__box">
      <img class="insulation__img" :src="images.cutaway" alt="Дім в розрізі" @error="$event.target.style.display = 'none'" />
      <div class="insulation__shade" />
      <img class="insulation__logo insulation__logo--egger" :src="images.egger" alt="" />
      <img class="insulation__logo insulation__logo--soft" :src="images.eggerSoft" alt="" />

      <div
        v-for="item in layers"
        :key="item.top"
        class="insulation__layer"
        :style="{ top: item.top }"
      >
        <span class="insulation__dot" :style="{ left: item.x }" />
        <span class="insulation__rule" :style="{ left: item.x, width: item.w }" />
        <span class="insulation__label">{{ item.label }}</span>
      </div>
    </div>
  </section>
</template>

<script>
import images from '@/assets/images'
import SectionTitle from '@/components/common/SectionTitle.vue'

const pct = (value) => `${(value / 390) * 100}%`
const boxH = 330

const rows = [
  { label: 'Зовнішнє оздоблення: Композитні панелі', y: 74, dot: 111 },
  { label: 'Гідробарʼєр', y: 113, dot: 131 },
  { label: 'Панель OSB-3 Egger 10 мм', y: 143, dot: 141 },
  { label: 'Базальтовий утеплювач Rotys 200 мм', y: 181, dot: 155 },
  { label: 'Панель OSB-3 Egger 10 мм', y: 219, dot: 174 },
  { label: 'Внутрішня обшивка', y: 257, dot: 194 },
]

export default {
  name: 'InsulationSection',
  components: { SectionTitle },
  data() {
    return {
      images,
      layers: rows.map((r) => ({
        label: r.label,
        top: `${(r.y / boxH) * 100}%`,
        x: pct(r.dot),
        w: pct(206 - r.dot),
      })),
    }
  },
}
</script>

<style lang="scss" scoped>
@use '@/styles/variables' as *;
@use '@/styles/mixins' as *;

.insulation {
  @include stage;
  max-width: 560px;
  padding: 28px 0 0;

  :deep(.section-title) { padding-inline: 20px; }
  :deep(.section-title__subtitle) { max-width: 277px; }

  &__box {
    position: relative;
    width: 100%;
    aspect-ratio: 390 / 330;
    margin-top: 14px;
    overflow: hidden;
    background: $gray;
    color: #fff;
    font-size: 14px;
    letter-spacing: -0.03em;
    line-height: 0.9;
  }

  &__img {
    position: absolute;
    top: 0;
    left: -11.3%;
    width: 111.8%;
    height: 100%;
    object-fit: cover;
  }

  &__shade {
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    left: 44.6%;
    background: rgba(0, 0, 0, 0.31);
  }

  &__logo {
    position: absolute;
    height: auto;
    transform: rotate(-90deg);
    &--egger { width: 28px; left: 221px; top: 241px; mix-blend-mode: darken; }
    &--soft { width: 33px; left: 200px; top: 220px; mix-blend-mode: soft-light; }
  }

  &__layer {
    position: absolute;
    inset-inline: 0;
    height: 0;
  }

  &__label {
    position: absolute;
    left: 54.4%;
    top: 0;
    max-width: 41%;
    transform: translateY(-4px);
  }

  &__dot {
    position: absolute;
    top: 7px;
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: #fff;
  }

  &__rule {
    position: absolute;
    top: 9.5px;
    height: 1px;
    margin-left: 3px;
    background: #fff;
  }
}
</style>
