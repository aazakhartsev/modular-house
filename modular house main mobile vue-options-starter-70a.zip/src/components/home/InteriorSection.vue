<template>
  <section class="interior">
    <section-title
      subtitle="Наші інженери продумали все: від розташування розеток та вимикачів до напрямку відкриття шаф. Ми поєднали функціональність і естетику, щоб кожна кімната відчувалась як продовження Вас"
    >
      Затишний та продуманий інтерʼєр
    </section-title>

    <div class="interior__card">
      <span class="interior__pill" />
      <h3 class="interior__heading">Сучасні матеріали</h3>
      <h4 class="interior__subheading">Широкий вибір фасадів</h4>
      <p class="interior__text">Кожен інтер'єр проектується індивідуально під замовника.</p>
      <img class="interior__img" :src="images.interior" alt="Інтерʼєр вітальні" />

      <div class="interior__dots">
        <button
          v-for="n in 4"
          :key="n"
          type="button"
          class="interior__dot"
          :class="{ 'interior__dot--active': active === n - 1 }"
          :aria-label="'Слайд ' + n"
          @click="active = n - 1"
        />
      </div>
    </div>
  </section>
</template>

<script>
import images from '@/assets/images'
import SectionTitle from '@/components/common/SectionTitle.vue'

export default {
  name: 'InteriorSection',
  components: { SectionTitle },
  data() {
    return { images, active: 0 }
  },
}
</script>

<style lang="scss" scoped>
@use '@/styles/variables' as *;
@use '@/styles/mixins' as *;

.interior {
  @include stage;
  max-width: 560px;
  padding: 45px 20px 40px;

  :deep(.section-title__subtitle) { max-width: 323px; font-size: 16px; line-height: 1.15; margin-top: 10px; }
  :deep(.section-title__text) { max-width: 267px; }
  :deep(.section-title__line) { display: none; }

  &__card {
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-top: 28px;
    padding: 36px 16px 20px;
    border-radius: 20px;
    background: $gray;
    text-align: center;
  }

  &__pill {
    position: absolute;
    top: 24px;
    left: 40px;
    right: 40px;
    height: 45px;
    border-radius: 14px;
    background: #fff;
  }

  &__heading, &__subheading, &__text { position: relative; margin: 0; }
  &__heading { font-size: 20px; font-weight: 400; letter-spacing: -0.04em; }
  &__subheading { margin-top: 28px; font-size: 16px; font-weight: 600; letter-spacing: -0.04em; }
  &__text { max-width: 242px; margin-top: 2px; font-size: 16px; letter-spacing: -0.04em; }

  &__img {
    width: 100%;
    max-width: 323px;
    aspect-ratio: 309 / 287;
    margin-top: 16px;
    border-radius: 20px;
    object-fit: cover;
  }

  &__dots {
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 208px;
    height: 39px;
    margin-top: 26px;
    padding: 0 22px;
    border-radius: 14px;
    background: #fff;
  }

  &__dot {
    width: 9px;
    height: 9px;
    padding: 0;
    border: 0;
    border-radius: 50%;
    background: #696868;
    cursor: pointer;
    transition: all 0.2s;
    &--active { width: 12px; height: 12px; background: #363636; }
  }
}
</style>
