<template>
  <section class="name">
    <section-title
      subtitle="Дайте вашому будинку імʼя, яке відображає вашу родину, мрію або місце. Табличка з іменем буде відрізняти ваш дім серед усіх сусідів."
    >
      Власне імʼя
    </section-title>

    <ul class="name__list">
      <li v-for="item in items" :key="item.title" class="name__item">
        <span class="name__check">✓</span>
        <div>
          <h3>{{ item.title }}</h3>
          <p>{{ item.text }}</p>
        </div>
      </li>
    </ul>

    <form class="name__form" @submit.prevent="apply">
      <v-text-field
        v-model="houseName"
        class="name__input"
        placeholder="Катруся"
        variant="solo-filled"
        flat
        hide-details
        density="comfortable"
        aria-label="Імʼя будинку"
      />
      <v-btn class="name__submit" type="submit" rounded="pill" height="37" color="primary">
        Дати імʼя
        <span class="name__circle">
          <svg width="6" height="6" viewBox="0 0 6 6" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0 0H6V6M6 0L0 6" stroke="#273947" stroke-width="0.9" />
          </svg>
        </span>
      </v-btn>
    </form>

    <div class="name__house">
      <img :src="images.katrusya" alt="Дім Катруся" />
      <span class="name__plate">{{ plate }}</span>
    </div>
  </section>
</template>

<script>
import images from '@/assets/images'
import SectionTitle from '@/components/common/SectionTitle.vue'

export default {
  name: 'HouseNameSection',
  components: { SectionTitle },
  data() {
    return {
      images,
      houseName: '',
      plate: 'Катруся',
      items: [
        { title: 'Металева табличка', text: 'Лазерне гравіювання на нержавіючій сталі. Входить у комплектацію.' },
        { title: 'Реєстрація імені', text: "Ім'я фіксується в нашій базі. Жоден інший будинок не матиме такого самого." },
        { title: 'Символ родини', text: "Передається разом з будинком. Ім'я живе стільки, скільки стоїть дім." },
      ],
    }
  },
  methods: {
    apply() {
      const value = this.houseName.trim()
      if (value) this.plate = value
    },
  },
}
</script>

<style lang="scss" scoped>
@use '@/styles/variables' as *;
@use '@/styles/mixins' as *;

.name {
  @include stage;
  max-width: 560px;
  padding: 50px 20px 0;

  :deep(.section-title__subtitle) { max-width: 323px; }

  &__list {
    display: flex;
    flex-direction: column;
    gap: 22px;
    margin: 22px 0 0;
    padding: 0 0 0 11px;
    list-style: none;
  }

  &__item {
    display: flex;
    gap: 10px;

    h3 { margin: 0 0 4px; font-size: 20px; font-weight: 600; line-height: 0.9; letter-spacing: -0.03em; }
    p { margin: 0; max-width: 210px; font-size: 16px; line-height: 0.9; letter-spacing: -0.03em; }
  }

  &__check {
    display: grid;
    flex: none;
    place-items: center;
    width: 36px;
    height: 36px;
    margin-top: 5px;
    border: 2.5px solid $navy;
    border-radius: 50%;
    color: $navy;
    font-size: 20px;
    font-weight: 600;
  }

  &__form {
    display: flex;
    gap: 14px;
    align-items: center;
    margin-top: 22px;
  }

  &__input {
    flex: 1;
    :deep(.v-field) { border-radius: 168px; background: $gray; min-height: 37px; }
    :deep(.v-field__input) { min-height: 37px; padding: 0 14px; font-size: 16px; color: $gray-text; }
  }

  &__submit {
    padding: 0 7px 0 14px !important;
    font-size: 16px;
    font-weight: 400;
  }

  &__circle {
    display: grid;
    place-items: center;
    width: 24px;
    height: 24px;
    margin-left: 6px;
    border-radius: 50%;
    background: #fff;
  }

  &__house {
    position: relative;
    margin: 12px -60px 0;
    overflow: hidden;

    img { width: 100%; min-width: 440px; height: auto; margin-inline: auto; aspect-ratio: 680 / 277; object-fit: cover; }
  }

  &__plate {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, 8%);
    color: #fff;
    font-size: 12px;
    font-weight: 500;
    letter-spacing: 0.05em;
    text-transform: uppercase;
    -webkit-text-stroke: 0.5px #ffbd54;
  }
}
</style>
