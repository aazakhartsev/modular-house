<template>
  <section class="chars">
    <section-title>Характеристики ідеального будинку</section-title>

    <div class="chars__panel">
      <img class="chars__bg" :src="images.characteristics" alt="" />
      <ul class="chars__grid">
        <li v-for="(t, i) in tiles" :key="i" class="chars__tile" :class="{ 'chars__tile--empty': !t }">
          <template v-if="t">
            <strong>{{ t.value }}</strong>
            <span>{{ t.label }}</span>
          </template>
        </li>
      </ul>
    </div>

    <form class="chars__form" @submit.prevent="submit">
      <v-text-field
        :model-value="name"
        placeholder="Імʼя"
        variant="solo-filled"
        flat
        hide-details
        class="chars__input"
        aria-label="Імʼя"
        @update:model-value="setField('name', $event)"
      />
      <v-text-field
        :model-value="phone"
        placeholder="+380 (__) ___-__-__"
        variant="solo-filled"
        flat
        hide-details
        class="chars__input chars__input--phone"
        type="tel"
        aria-label="Телефон"
        @update:model-value="setField('phone', $event)"
      />
      <arrow-button variant="dark" type="submit">Розрахувати вартість</arrow-button>
      <p v-if="submitted" class="chars__thanks">Дякуємо! Ми звʼяжемося з Вами найближчим часом.</p>
    </form>
  </section>
</template>

<script>
import { mapState } from 'vuex'
import images from '@/assets/images'
import SectionTitle from '@/components/common/SectionTitle.vue'
import ArrowButton from '@/components/common/ArrowButton.vue'

export default {
  name: 'CharacteristicsSection',
  components: { SectionTitle, ArrowButton },
  data() {
    return {
      images,
      tiles: [
        { value: '62.5 м2', label: 'стартова площа' },
        { value: '27 м2', label: 'кожен наступний модуль' },
        { value: '70%', label: 'житлова зона від загальної площі' },
        { value: '1 : 4', label: 'площа скління' },
        null,
        { value: '0', label: 'темних куточків' },
        { value: '27 м2', label: 'на одного дорослого' },
        { value: '18 м2', label: 'на одну дитину' },
        { value: '1', label: 'поверх' },
      ],
    }
  },
  computed: {
    ...mapState('contact', ['name', 'phone', 'submitted']),
  },
  methods: {
    setField(key, value) {
      this.$store.commit('contact/SET_FIELD', { key, value })
    },
    submit() {
      this.$store.dispatch('contact/submit')
    },
  },
}
</script>

<style lang="scss" scoped>
@use '@/styles/variables' as *;
@use '@/styles/mixins' as *;

.chars {
  @include stage;
  max-width: 560px;
  padding: 100px 0 0;

  :deep(.section-title) { padding-inline: 20px; }
  :deep(.section-title__text) { max-width: 243px; }

  &__panel {
    position: relative;
    margin-top: 28px;
    overflow: hidden;
    background: #0e1e28;
    padding: 18px 22px;
  }

  &__bg {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
  }

  &__grid {
    position: relative;
    display: grid;
    grid-template-columns: repeat(3, 93px);
    justify-content: space-between;
    gap: 39px 0;
    margin: 0;
    padding: 0;
    list-style: none;
  }

  &__tile {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 6px;
    height: 60px;
    padding: 0 4px;
    border: 0.34px solid #fff;
    border-radius: 10px;
    background: rgba(255, 255, 255, 0.1);
    color: #fff;
    font-size: 12px;
    line-height: 0.9;
    letter-spacing: -0.03em;
    text-align: center;

    strong { font-weight: 600; }
    &--empty { visibility: hidden; }
  }

  &__form {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 11px;
    margin-top: 28px;
    padding: 0 20px;
  }

  &__input {
    width: 260px;
    :deep(.v-field) { min-height: 53px; border-radius: 305px; background: $gray; }
    :deep(.v-field__input) { min-height: 53px; padding: 0 16px; font-size: 16px; color: $gray-text; }
    &--phone :deep(input) { letter-spacing: 0.09em; }
  }

  &__thanks { margin: 4px 0 0; font-size: 14px; text-align: center; color: $navy; }
}
</style>
