<template>
  <section id="calculator" class="calc">
    <section-title subtitle="Порахуйте приблизну ціну будинка-конструктора">Онлайн-калькулятор</section-title>

    <div class="calc__steps">
      <!-- 1 -->
      <div class="calc__step">
        <span class="calc__num">1</span>
        <h3 class="calc__step-title">Конфігурація простору</h3>
      </div>
      <div class="calc__card calc__card--area">
        <div class="calc__area-text">
          <p class="calc__caps">Площа будинку</p>
          <p class="calc__strong">Базовий модуль: 62,5м2</p>
          <p class="calc__strong">Додаткові модулі (мінімум 27м2)</p>
          <div class="calc__counter">
            <button type="button" class="calc__square" aria-label="Додати модуль" @click="changeModules(1)">+</button>
            <button type="button" class="calc__square" aria-label="Прибрати модуль" @click="changeModules(-1)">-</button>
            <span class="calc__square calc__square--value">{{ modules }}</span>
          </div>
          <p class="calc__total">Загальна площа: <b>{{ formattedArea }}м2</b></p>
        </div>
        <img class="calc__area-img" :src="images.extension" alt="Схема розширення" />
      </div>

      <!-- 2 -->
      <div class="calc__step">
        <span class="calc__num">2</span>
        <h3 class="calc__step-title">Енергетичне серце</h3>
      </div>
      <div class="calc__card calc__card--heart">
        <img class="calc__heart-img" :src="images.generation" alt="" />
        <p class="calc__caps">Гібридний інвертор</p>
        <div class="calc__row">
          <span class="calc__strong">Фази</span>
          <div class="calc__chips">
            <button
              v-for="p in [1, 3]"
              :key="p"
              type="button"
              class="calc__chip calc__chip--small"
              :class="{ 'calc__chip--active': phases === p }"
              @click="setField('phases', p)"
            >{{ p }}</button>
          </div>
        </div>
        <div class="calc__row calc__row--stack">
          <span class="calc__strong">Частота</span>
          <div class="calc__chips calc__chips--column">
            <button
              type="button"
              class="calc__chip"
              :class="{ 'calc__chip--active': voltage === 'low' }"
              @click="setField('voltage', 'low')"
            >низьковольтний</button>
            <button
              type="button"
              class="calc__chip"
              :class="{ 'calc__chip--active': voltage === 'high' }"
              @click="setField('voltage', 'high')"
            >високовольтний</button>
          </div>
        </div>
        <p class="calc__strong calc__strong--spaced">Потужність (кВт)</p>
        <v-slider
          :model-value="inverterPower"
          :min="6"
          :max="80"
          :step="1"
          hide-details
          class="calc__slider"
          @update:model-value="setField('inverterPower', $event)"
        />
        <div class="calc__ticks"><span>6</span><span>10</span><span>80</span></div>
      </div>

      <!-- 3 -->
      <div class="calc__step">
        <span class="calc__num">3</span>
        <h3 class="calc__step-title">Акумуляторна батарея</h3>
      </div>
      <div class="calc__card calc__card--device">
        <img class="calc__device-img" :src="images.battery" alt="" />
        <p class="calc__strong">Ємність: кВт-г</p>
        <v-slider
          :model-value="batteryCapacity"
          :min="5"
          :max="100"
          :step="1"
          hide-details
          class="calc__slider"
          @update:model-value="setField('batteryCapacity', $event)"
        />
        <div class="calc__ticks"><span>5 кВт-г</span><span>40 кВт-г</span><span>100 кВт-г</span></div>
      </div>

      <!-- 4 -->
      <div class="calc__step">
        <span class="calc__num">4</span>
        <h3 class="calc__step-title">Сонячні панелі</h3>
      </div>
      <div class="calc__card calc__card--device">
        <img class="calc__device-img calc__device-img--panels" :src="images.panels" alt="" />
        <p class="calc__strong">Ємність: кВт-г</p>
        <v-slider
          :model-value="panelsCapacity"
          :min="5.1"
          :max="102"
          :step="0.1"
          hide-details
          class="calc__slider"
          @update:model-value="setField('panelsCapacity', $event)"
        />
        <div class="calc__ticks"><span>5.1 кВт-г</span><span>51 кВт-г</span><span>102 кВт-г</span></div>
      </div>

      <div class="calc__price">
        <div class="calc__price-value">$ {{ formattedPrice }}</div>
        <p class="calc__price-caption">приблизна вартість будинку</p>
        <arrow-button class="calc__price-btn" variant="light" href="#contacts">Отримати консультацію</arrow-button>
      </div>
    </div>
  </section>
</template>

<script>
import { mapActions, mapGetters, mapState } from 'vuex'
import images from '@/assets/images'
import SectionTitle from '@/components/common/SectionTitle.vue'
import ArrowButton from '@/components/common/ArrowButton.vue'

export default {
  name: 'CalculatorSection',
  components: { SectionTitle, ArrowButton },
  data() {
    return { images }
  },
  computed: {
    ...mapState('calculator', ['modules', 'phases', 'voltage', 'inverterPower', 'batteryCapacity', 'panelsCapacity']),
    ...mapGetters('calculator', ['formattedPrice', 'formattedArea']),
  },
  methods: {
    ...mapActions('calculator', ['changeModules']),
    setField(key, value) {
      this.$store.dispatch('calculator/setField', { key, value })
    },
  },
}
</script>

<style lang="scss" scoped>
@use '@/styles/variables' as *;
@use '@/styles/mixins' as *;

.calc {
  @include stage;
  max-width: 560px;
  padding: 50px 20px 0;

  :deep(.section-title__text) { max-width: 259px; }
  :deep(.section-title__subtitle) { max-width: 216px; }

  &__steps {
    display: flex;
    flex-direction: column;
    max-width: 293px;
    margin: 28px auto 0;
  }

  &__step {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-top: 16px;
    &:first-child { margin-top: 0; }
  }

  &__num {
    display: grid;
    flex: none;
    place-items: center;
    width: 38px;
    height: 38px;
    border-radius: 50%;
    background: $gradient;
    color: #fff;
    font-size: 28px;
    letter-spacing: -0.03em;
  }

  &__step-title { margin: 0; font-size: 20px; font-weight: 600; letter-spacing: -0.03em; }

  &__card {
    position: relative;
    margin-top: 8px;
    padding: 12px 16px 14px;
    border: 1.9px solid $navy;
    border-radius: 16px;
    background: $gray;
  }

  &__caps, &__strong { margin: 0; font-size: 16px; font-weight: 600; letter-spacing: -0.03em; line-height: 1.2; }
  &__caps { text-transform: uppercase; }
  &__strong--spaced { margin-top: 10px; }

  &__card--area { min-height: 164px; }
  &__area-text { position: relative; z-index: 1; display: flex; flex-direction: column; gap: 9px; }
  &__area-img { position: absolute; top: 8px; right: 12px; width: 79px; height: auto; }

  &__counter { display: flex; gap: 3px; margin-top: 2px; }

  &__square {
    display: grid;
    place-items: center;
    width: 26px;
    height: 26px;
    padding: 0;
    border: 0.64px solid $navy;
    border-radius: 9.6px;
    background: $gray;
    color: #000;
    font-size: 24px;
    line-height: 1;
    cursor: pointer;
    &--value { font-size: 18px; cursor: default; }
  }

  &__total { margin: -2px 0 0 95px; font-size: 12px; letter-spacing: -0.03em; }

  &__card--heart { min-height: 165px; padding-bottom: 12px; }
  &__heart-img { position: absolute; top: 15px; right: 11px; width: 61px; height: auto; }

  &__row {
    display: flex;
    align-items: center;
    gap: 40px;
    margin-top: 8px;
    &--stack { align-items: flex-start; }
  }

  &__chips { display: flex; gap: 8px; &--column { flex-direction: column; gap: 3px; } }

  &__chip {
    min-width: 20px;
    padding: 0 6px;
    border: 0.65px solid $navy;
    border-radius: 6.5px;
    background: transparent;
    font-family: inherit;
    font-size: 16px;
    letter-spacing: -0.03em;
    cursor: pointer;
    &--small { width: 20px; padding: 0; background: $gray; }
    &--active { background: linear-gradient(90deg, $cyan, $cyan-dark); }
  }

  &__slider {
    margin: 4px 8px 0 0;
    max-width: 198px;
    :deep(.v-slider-track__background) { background: #3e3f3f; opacity: 1; height: 7px; border-radius: 3px; }
    :deep(.v-slider-track__fill) { background: linear-gradient(90deg, $cyan, $cyan-dark); height: 7px; border-radius: 3px; }
    :deep(.v-slider-thumb__surface) { width: 12px; height: 12px; background: $cyan-dark; border: 0.65px solid $navy; box-shadow: none; &::before, &::after { display: none; } }
    :deep(.v-slider-thumb) { color: $cyan-dark; }
  }

  &__card--device &__slider { max-width: 212px; }

  &__ticks {
    display: flex;
    justify-content: space-between;
    max-width: 212px;
    margin-top: -6px;
    font-size: 16px;
    letter-spacing: -0.03em;
  }

  &__card--device { min-height: 113px; padding-top: 20px; }
  &__device-img { position: absolute; top: 7px; right: 8px; width: 100px; height: auto; &--panels { width: 123px; } }

  &__price {
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-top: 28px;
    padding: 10px 0 32px;
    border-radius: 14px;
    background: $gradient;
    min-height: 159px;
  }

  &__price-value {
    background: linear-gradient(1deg, $cyan 25%, $cyan-dark 99%);
    background-clip: text;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    font-size: 47px;
    font-weight: 600;
    letter-spacing: -0.03em;
    line-height: 1.2;
  }

  &__price-caption { margin: -2px 0 0; color: #fff; font-size: 14px; letter-spacing: -0.03em; }
  &__price-btn { position: absolute; bottom: -26px; }
}
</style>
