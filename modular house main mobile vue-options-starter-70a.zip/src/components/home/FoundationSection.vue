<template>
  <section class="foundation">
    <section-title subtitle="Ми використовуємо оцинковані геошурупи в якості фундаменту">
      Надійний фундамент, який не псує землю
    </section-title>

    <div class="foundation__hero">
      <img class="foundation__hero-img" :src="images.screws" alt="" />
      <p class="foundation__hero-text">
        <b>Геошурупи</b> — це оцинковані металеві гвинтові палі, які вкручуються в ґрунт на глибину від 2 до 4,5 м.
        Завдяки гарячому цинкуванню їх термін служби скаладає від 50 до 100 років.
      </p>
    </div>

    <div class="foundation__stats">
      <img class="foundation__stats-img" :src="images.foundation" alt="Геошурупи фундамент" />
      <div class="foundation__tiles">
        <div v-for="tile in tiles" :key="tile.value" class="foundation__tile">
          <span class="foundation__tile-value">{{ tile.value }}</span>
          <span class="foundation__tile-label">{{ tile.label }}</span>
        </div>
      </div>
    </div>

    <ul class="foundation__features">
      <li v-for="f in features" :key="f.title">
        <h3>{{ f.title }}</h3>
        <p v-html="f.html" />
      </li>
    </ul>
  </section>
</template>

<script>
import images from '@/assets/images'
import SectionTitle from '@/components/common/SectionTitle.vue'

export default {
  name: 'FoundationSection',
  components: { SectionTitle },
  data() {
    return {
      images,
      tiles: [
        { value: '25 тонн', label: 'навантаження на один геошуруп' },
        { value: '50 - 100', label: 'років служби в ґрунті' },
        { value: '18 шт', label: 'геошурупів на один модуль 62,5 м2' },
        { value: '-30С°', label: 'стійкість до морозу' },
      ],
      features: [
        {
          title: 'Будь-який ґрунт',
          html: 'Геошурупи можна вмонтувати в будь-який ґрунт: пісок, глина, торф, схили, а також в дно водойомів',
        },
        {
          title: 'Швидкий монтаж',
          html: 'Встановлення за <b>1 робочий день</b> без бетону та опалубки',
        },
        {
          title: 'Демонтаж та перенос',
          html: 'На відміну від бетону — геошурупи можна викрутити та перенести на інше місце. Вони не псують землю. Їх можна використовувати на землях сільско-господарського призначення.',
        },
      ],
    }
  },
}
</script>

<style lang="scss" scoped>
@use '@/styles/variables' as *;
@use '@/styles/mixins' as *;

.foundation {
  @include stage;
  max-width: 560px;
  padding: 50px 20px 40px;

  :deep(.section-title__text) { max-width: 280px; }
  :deep(.section-title__subtitle) { max-width: 243px; }
  :deep(.section-title__line) { margin-top: 11px; }

  &__hero {
    position: relative;
    height: 385px;
    margin: 20px -20px 0;
    overflow: hidden;
  }

  &__hero-img {
    position: absolute;
    top: 0;
    left: 50%;
    width: 526px;
    height: 385px;
    transform: translateX(-50%);
    object-fit: cover;
  }

  &__hero-text {
    position: relative;
    max-width: 342px;
    margin: 12px auto 0;
    padding-inline: 19px;
    color: #fff;
    font-size: 16px;
    line-height: 1.1;
    letter-spacing: -0.05em;
  }

  &__stats {
    position: relative;
    margin-top: 12px;
  }

  &__stats-img {
    width: 100%;
    aspect-ratio: 107 / 71;
    border-radius: 22px;
    object-fit: cover;
  }

  &__tiles {
    position: absolute;
    inset: 8px 9px;
    display: grid;
    grid-template-columns: 1fr 1fr;
    align-content: space-between;
    gap: 8px;
  }

  &__tile {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    width: 107px;
    min-height: 66px;
    padding: 6px 4px;
    border-radius: 14px;
    background: rgba(248, 248, 248, 0.2);
    color: #fff;
    text-align: center;

    &:nth-child(even) { justify-self: end; width: 96px; }
  }

  &__tile-value { font-size: 18px; letter-spacing: -0.06em; line-height: 1.25; }
  &__tile-label { font-size: 12px; line-height: 0.9; letter-spacing: -0.05em; }

  &__features {
    display: flex;
    flex-direction: column;
    gap: 32px;
    margin: 28px 0 0;
    padding: 0 0 0 15px;
    color: #0b1926;
    list-style: none;

    h3 { margin: 0 0 4px; font-size: 20px; font-weight: 700; line-height: 1; letter-spacing: -0.05em; }
    p { margin: 0; font-size: 16px; line-height: 1; letter-spacing: -0.05em; }
  }
}
</style>
