<template>
  <section class="banner">
    <img class="banner__bg" :src="images.modular" alt="" />
    <div class="banner__content">
      <h2 class="banner__title">Модульні енергонезалежні будинки</h2>
      <ul class="banner__list">
        <li v-for="item in items" :key="item">✓ {{ item }}</li>
      </ul>
      <arrow-button variant="light" href="#calculator">Отримати консультацію</arrow-button>
    </div>
  </section>
</template>

<script>
import images from '@/assets/images'
import ArrowButton from '@/components/common/ArrowButton.vue'

export default {
  name: 'ModularBanner',
  components: { ArrowButton },
  data() {
    return {
      images,
      items: [
        'Генерують електроенергію та біогаз',
        'Збирають та очищують воду',
        'Перероблюють сміття та відходи',
        'Легко добудовувати',
        'Монтаж та демонтаж за 3 дні',
      ],
    }
  },
}
</script>

<style lang="scss" scoped>
.banner {
  position: relative;
  min-height: 319px;
  margin-top: 0;
  overflow: hidden;
  background: #0e1e28;
  color: #fff;

  &__bg {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
  }

  &__content {
    position: relative;
    max-width: 1100px;
    margin-inline: auto;
    padding: 37px 30px 33px;
  }

  &__title {
    max-width: 262px;
    margin: 0 0 18px;
    font-size: 20px;
    font-weight: 400;
    line-height: 0.9;
    letter-spacing: -0.03em;
  }

  &__list {
    display: flex;
    flex-direction: column;
    gap: 11px;
    margin: 0 0 19px;
    padding: 0;
    list-style: none;
    font-size: 16px;
    letter-spacing: -0.03em;
    line-height: 1;
  }
}

@media (min-width: 700px) {
  .banner {
    min-height: 420px;
    &__content { padding-top: 70px; }
    &__title { max-width: 420px; font-size: 32px; margin-bottom: 28px; }
    &__list { font-size: 20px; gap: 14px; margin-bottom: 30px; }
  }
}
</style>
