<template>
  <v-btn
    :class="['arrow-btn', 'arrow-btn--' + variant]"
    rounded="pill"
    height="53"
    :width="260"
    variant="flat"
    v-bind="$attrs"
  >
    <span class="arrow-btn__label"><slot /></span>
    <span class="arrow-btn__circle">
      <svg width="7" height="7" viewBox="0 0 7 7" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M0 0H6.10329V6.10329M6.10329 0L0 6.10329" stroke="currentColor" stroke-width="0.915493" />
      </svg>
    </span>
  </v-btn>
</template>

<script>
export default {
  name: 'ArrowButton',
  inheritAttrs: false,
  props: {
    variant: { type: String, default: 'light' },
  },
}
</script>

<style lang="scss" scoped>
@use '@/styles/variables' as *;

.arrow-btn {
  justify-content: space-between;
  padding: 0 8px 0 21px !important;
  font-size: 16px;
  font-weight: 400;

  &__label { letter-spacing: -0.03em; }

  &__circle {
    display: grid;
    place-items: center;
    width: 38px;
    height: 38px;
    margin-left: 16px;
    border-radius: 50%;
  }

  &--light {
    background: #fff !important;
    color: #000 !important;
    .arrow-btn__circle { background: $navy; color: #fff; }
  }

  &--dark {
    background: $navy !important;
    color: #fff !important;
    .arrow-btn__circle { background: #fff; color: $navy; }
  }
}
</style>
