<template>
  <footer class="footer">
    <img class="footer__bg" :src="images.footerWide" alt="" />
    <img class="footer__bg" :src="images.footerTall" alt="" />

    <div class="footer__content">
      <img :src="images.logo" alt="Servionica" class="footer__logo" width="161" height="32" />

      <nav class="footer__nav">
        <router-link v-for="link in links" :key="link.label" :to="link.to">{{ link.label }}</router-link>
      </nav>

      <a class="footer__phone" href="tel:+380445022888">
        <span>+38 (044) 502 2888</span>
        <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="15.8767" cy="15.8767" r="15.8767" fill="white" />
          <path d="M12.5 8.5c-1.9.3-3.1 1.9-3.1 3.8 0 6.1 4.7 11.3 10.5 11.3 1.7 0 3.1-1.2 3.3-3.3l-3.7-1.8-2 1.8c-1.6-.8-3.1-2.3-3.9-4l1.7-2.1-1.6-3.9z" fill="black" />
        </svg>
      </a>

      <div class="footer__socials">
        <a href="https://www.instagram.com/" target="_blank" rel="noopener" aria-label="Instagram">
          <svg width="56" height="56" viewBox="0 0 56 56" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="28" cy="28" r="28" fill="#F1F1F1" />
            <rect x="20" y="20" width="16" height="16" rx="4.5" stroke="#1b2a38" stroke-width="1.6" />
            <circle cx="28" cy="28" r="3.8" stroke="#1b2a38" stroke-width="1.6" />
            <circle cx="32.4" cy="23.6" r="1.05" fill="#1b2a38" />
          </svg>
        </a>
        <a href="https://www.facebook.com/" target="_blank" rel="noopener" aria-label="Facebook">
          <svg width="56" height="56" viewBox="0 0 56 56" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="28" cy="28" r="28" fill="#F1F1F1" />
            <path d="M26.06 37.8h3.77v-7.67h3.4l.37-3.81h-3.77v-1.93c0-.25.1-.5.28-.68.18-.18.42-.28.67-.28h2.83V19.6h-2.83c-1.25 0-2.45.5-3.33 1.4-.88.9-1.38 2.12-1.38 3.39v1.93h-1.89l-.37 3.81h2.26v7.67z" fill="#1b2a38" />
          </svg>
        </a>
      </div>

      <p class="footer__copy">Servionica © 2026. Всі права захищені.</p>
    </div>
  </footer>
</template>

<script>
import images from '@/assets/images'
import { navLinks } from '@/components/common/navLinks'

export default {
  name: 'AppFooter',
  data() {
    return { images, links: navLinks }
  },
}
</script>

<style lang="scss" scoped>
@use '@/styles/variables' as *;

.footer {
  position: relative;
  overflow: hidden;
  min-height: 561px;
  background: #0e1e28;
  color: #fff;

  &__bg {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
  }

  &__content {
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 31px 20px 24px;
  }

  &__logo { height: 32px; width: auto; }

  &__nav {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 45px;
    margin-top: 40px;

    a {
      color: #fff;
      font-size: 16px;
      letter-spacing: -0.04em;
      text-decoration: none;
      text-transform: uppercase;
    }
  }

  &__phone {
    display: flex;
    align-items: center;
    gap: 14px;
    margin-top: 40px;
    padding: 12px 10px 12px 24px;
    border: 1px solid #fff;
    border-radius: 93px;
    color: #fff;
    font-size: 20px;
    letter-spacing: -0.03em;
    text-decoration: none;
  }

  &__socials {
    display: flex;
    gap: 80px;
    margin-top: 30px;
    a { display: block; }
  }

  &__copy {
    margin: 38px 0 0;
    font-size: 14px;
    letter-spacing: -0.04em;
    text-align: center;
  }
}

@media (min-width: 900px) {
  .footer__nav { flex-direction: row; gap: 48px; }
}
</style>
