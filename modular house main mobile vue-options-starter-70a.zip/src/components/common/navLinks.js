export const navLinks = [
  { label: 'Будинки', to: '/' },
  { label: 'Генерація', to: '/generation' },
  { label: 'Утилізація', to: '/utilization' },
  { label: 'Контакти', to: { path: '/', hash: '#contacts' } },
]
