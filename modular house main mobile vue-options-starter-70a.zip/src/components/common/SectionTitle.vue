<template>
  <div class="section-title">
    <div class="section-title__row">
      <span class="section-title__line" />
      <h2 class="section-title__text"><slot /></h2>
      <span class="section-title__line" />
    </div>
    <p v-if="subtitle" class="section-title__subtitle">{{ subtitle }}</p>
  </div>
</template>

<script>
export default {
  name: 'SectionTitle',
  props: {
    subtitle: { type: String, default: '' },
  },
}
</script>

<style lang="scss" scoped>
@use '@/styles/variables' as *;
@use '@/styles/mixins' as *;

.section-title {
  text-align: center;

  &__row {
    display: flex;
    align-items: flex-start;
    justify-content: center;
    gap: 16px;
  }

  &__line {
    flex: 1 1 0;
    max-width: 160px;
    min-width: 20px;
    height: 1px;
    margin-top: 11px;
    &:first-child { background: linear-gradient(90deg, $navy, $blue); }
    &:last-child { background: linear-gradient(90deg, $blue, $navy); }
  }

  &__text {
    @include gradient-text;
    flex: 0 1 auto;
    max-width: 300px;
    margin: 0;
    font-size: 26px;
    font-weight: 600;
    line-height: 0.9;
    letter-spacing: -0.03em;
    text-wrap: balance;
  }

  &__subtitle {
    max-width: 260px;
    margin: 10px auto 0;
    font-size: 16px;
    line-height: 1.2;
    letter-spacing: -0.03em;
    text-wrap: balance;
  }
}
</style>
