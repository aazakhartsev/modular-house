<template>
  <header class="app-header" :class="{ 'app-header--solid': solid }">
    <div class="app-header__inner">
      <router-link to="/" class="app-header__logo" @click="closeMenu">
        <img :src="logo" alt="Servionica" width="161" height="32" />
      </router-link>

      <nav class="app-header__nav">
        <router-link v-for="link in links" :key="link.label" :to="link.to">{{ link.label }}</router-link>
      </nav>

      <v-btn
        class="app-header__burger"
        icon="mdi-menu"
        variant="text"
        color="white"
        aria-label="Меню"
        @click="toggleMenu"
      />
    </div>

    <v-navigation-drawer v-model="drawer" location="right" temporary>
      <nav class="app-header__drawer-nav">
        <router-link v-for="link in links" :key="link.label" :to="link.to" @click="closeMenu">
          {{ link.label }}
        </router-link>
      </nav>
    </v-navigation-drawer>
  </header>
</template>

<script>
import { mapActions, mapState } from 'vuex'
import images from '@/assets/images'
import { navLinks } from '@/components/common/navLinks'

export default {
  name: 'AppHeader',
  data() {
    return { logo: images.logo, links: navLinks }
  },
  computed: {
    ...mapState('ui', ['menuOpen']),
    solid() {
      return !this.$route.meta.transparentHeader
    },
    drawer: {
      get() {
        return this.menuOpen
      },
      set(value) {
        this.$store.commit('ui/SET_MENU', value)
      },
    },
  },
  methods: {
    ...mapActions('ui', ['toggleMenu', 'closeMenu']),
  },
}
</script>

<style lang="scss" scoped>
@use '@/styles/variables' as *;

.app-header {
  position: absolute;
  inset: 0 0 auto 0;
  z-index: 10;

  &--solid {
    position: relative;
    background: $gradient;
  }

  &__inner {
    display: flex;
    align-items: center;
    justify-content: space-between;
    max-width: 1240px;
    margin-inline: auto;
    padding: 16px 20px;
  }

  &__logo img { height: 32px; width: auto; }

  &__nav {
    display: none;
    gap: 40px;

    a {
      color: #fff;
      font-size: 16px;
      letter-spacing: -0.04em;
      text-decoration: none;
      text-transform: uppercase;
      &:hover { opacity: 0.75; }
    }
  }

  &__drawer-nav {
    display: flex;
    flex-direction: column;
    gap: 28px;
    padding: 40px 24px;

    a {
      color: $navy;
      font-size: 18px;
      text-decoration: none;
      text-transform: uppercase;
    }
  }
}

@media (min-width: 900px) {
  .app-header {
    &__nav { display: flex; }
    &__burger { display: none; }
  }
}
</style>
